import asyncio
from hfc.fabric import Client
import os 
import json

loop = asyncio.get_event_loop()

cli = Client(net_profile="testnetwork/network.json")

org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
org3_user = cli.get_user(org_name='org3.example.com', name='User1')
org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org2_user = cli.get_user(org_name='org2.example.com', name='User1')
cli.new_channel('channel1')
cli.new_channel('centre')

#检查管理员身份

response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org2.example.com'],
			   fcn = 'CheckAdmin',
			   args=['Admin@org2.example.com'],
			   cc_name='CheckUser',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#添加管理员身份
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org2.example.com'],
			   fcn = 'UpdateAdmin',
			   args=['Admin@org3.example.com'],
			   cc_name='CheckUser',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#检查管理员身份
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'CheckAdmin',
			   args=['Admin@org3.example.com'],
			   cc_name='CheckUser',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#授予链内用户添加文件权限
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org2.example.com'],
			   fcn = 'AddPolicy',
			   args=['channel1','add','role1','Admin@org2.example.com'],
			   cc_name='Policy',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#用户添加文件
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'chainAuditRecord',
			   args=['hashdata','channel1','Admin@org2.example.com','data1','add'],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#二次上链
payload_add = json.loads(response)
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_user,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'chainSyncRecord',
			   args= [payload_add['hash_data'],payload_add['src_chain'],payload_add['user'],payload_add['data_id'],payload_add['type_tx'],payload_add['this_tx_id']],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#访问失败案例（系统bug）
try:
	response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_user,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'chainAuditRecord',
			   args=['hashdata','channel1','User1@org3.example.com','data1','read'],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
	print(response)
except Exception as e:
	print(str(e))

#增加读权限
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'AddPolicy',
			   args=['data1','read','role1','Admin@org3.example.com','Admin@org2.example.com','User1@org3.example.com'],
			   cc_name='Policy',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#用户读取
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_user,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'chainAuditRecord',
			   args=['hashdata','channel1','User1@org3.example.com','data1','read'],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#二次上链
payload_read = json.loads(response)
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_user,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'chainSyncRecord',
			   args= [payload_read['hash_data'],payload_read['src_chain'],payload_read['user'],payload_read['data_id'],payload_read['type_tx'],payload_read['this_tx_id']],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#修改读权限
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'UpdatePolicy',
			   args=['data1','read','deleteuser','role1','User1@org3.example.com'],
			   cc_name='Policy',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#访问失败案例（系统bug）
try:
	response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_user,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'chainAuditRecord',
			   args=['hashdata','channel1','User1@org3.example.com','data1','read'],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
	print(response)
except Exception as e:
	print(str(e))	

#删除权限
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'DelPolicy',
			   args=['data1','read'],
			   cc_name='Policy',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#访问失败案例
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'chainAuditRecord',
			   args=['hashdata','channel1','Admin@org3.example.com','data1','read'],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#追踪
print('start trace forward')
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'traceForward',
			   args=['data1', payload_add['this_tx_id']],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#追踪
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'traceForward',
			   args=['data1', payload_read['this_tx_id']],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print('trace forward')
print(response)

#溯源
print('trace backward')
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'traceBackward',
			   args=['data1', payload_add['this_tx_id']],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

#溯源
print('trace backward')

response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com'],
			   fcn = 'traceBackward',
			   args=['data1', payload_read['this_tx_id']],
			   cc_name='record',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

