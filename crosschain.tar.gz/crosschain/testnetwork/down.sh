rm ../tmp -rf
docker rm $(docker stop $(docker ps -aq) ) 
docker network prune
docker volume prune
docker rmi $(docker images | grep dev-peer* | awk '{print $3}')
rm crypto-config -rf
rm channel-artifacts/* -rf
rm /tmp/hfc-kvs/* -rf
