export ordererAdminCert="testnetwork/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/signcerts/*.pem)
export ordererAdminPriv="testnetwork/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/keystore/*sk)
export org1AdminCert="testnetwork/"$(ls crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/*.pem)
export org1AdminPriv="testnetwork/"$(ls crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore/*sk)
export org1User1Cert="testnetwork/"$(ls crypto-config/peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/signcerts/*.pem)
export org1User1Priv="testnetwork/"$(ls crypto-config/peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/keystore/*sk)

export org2AdminCert="testnetwork/"$(ls crypto-config/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp/signcerts/*.pem)
export org2AdminPriv="testnetwork/"$(ls crypto-config/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp/keystore/*sk)
export org2User1Cert="testnetwork/"$(ls crypto-config/peerOrganizations/org2.example.com/users/User1@org2.example.com/msp/signcerts/*.pem)
export org2User1Priv="testnetwork/"$(ls crypto-config/peerOrganizations/org2.example.com/users/User1@org2.example.com/msp/keystore/*sk)

export org3AdminCert="testnetwork/"$(ls crypto-config/peerOrganizations/org3.example.com/users/Admin@org3.example.com/msp/signcerts/*.pem)
export org3AdminPriv="testnetwork/"$(ls crypto-config/peerOrganizations/org3.example.com/users/Admin@org3.example.com/msp/keystore/*sk)
export org3User1Cert="testnetwork/"$(ls crypto-config/peerOrganizations/org3.example.com/users/User1@org3.example.com/msp/signcerts/*.pem)
export org3User1Priv="testnetwork/"$(ls crypto-config/peerOrganizations/org3.example.com/users/User1@org3.example.com/msp/keystore/*sk)

export org4AdminCert="testnetwork/"$(ls crypto-config/peerOrganizations/org4.example.com/users/Admin@org4.example.com/msp/signcerts/*.pem)
export org4AdminPriv="testnetwork/"$(ls crypto-config/peerOrganizations/org4.example.com/users/Admin@org4.example.com/msp/keystore/*sk)
export org4User1Cert="testnetwork/"$(ls crypto-config/peerOrganizations/org4.example.com/users/User1@org4.example.com/msp/signcerts/*.pem)
export org4User1Priv="testnetwork/"$(ls crypto-config/peerOrganizations/org4.example.com/users/User1@org4.example.com/msp/keystore/*sk)

export org5AdminCert="testnetwork/"$(ls crypto-config/peerOrganizations/org5.example.com/users/Admin@org5.example.com/msp/signcerts/*.pem)
export org5AdminPriv="testnetwork/"$(ls crypto-config/peerOrganizations/org5.example.com/users/Admin@org5.example.com/msp/keystore/*sk)
export org5User1Cert="testnetwork/"$(ls crypto-config/peerOrganizations/org5.example.com/users/User1@org5.example.com/msp/signcerts/*.pem)
export org5User1Priv="testnetwork/"$(ls crypto-config/peerOrganizations/org5.example.com/users/User1@org5.example.com/msp/keystore/*sk)

export ordererTlsCACert="testnetwork/"$(ls crypto-config/ordererOrganizations/example.com/tlsca/*.pem)
export peer0org1TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/msp/tlscacerts/*.pem)

export peer0org2TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/msp/tlscacerts/*.pem)
export peer0org3TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org3.example.com/peers/peer0.org3.example.com/msp/tlscacerts/*.pem)

export peer0org4TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org4.example.com/peers/peer0.org4.example.com/msp/tlscacerts/*.pem)
export peer0org5TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org5.example.com/peers/peer0.org5.example.com/msp/tlscacerts/*.pem)


export caorg1TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org1.example.com/ca/*pem)
export caorg2TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org2.example.com/ca/*pem)
export caorg3TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org3.example.com/ca/*pem)
export caorg2TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org4.example.com/ca/*pem)
export caorg3TlsCACert="testnetwork/"$(ls crypto-config/peerOrganizations/org5.example.com/ca/*pem)
echo $caorg1TlsCACert


sed -e "s|\${ordererAdminCert}|$ordererAdminCert|g" \
-e "s|\${ordererAdminPriv}|$ordererAdminPriv|g" \
-e "s|\${org1AdminCert}|$org1AdminCert|g" \
-e "s|\${org1AdminPriv}|$org1AdminPriv|g" \
-e "s|\${org1User1Cert}|$org1User1Cert|g" \
-e "s|\${org1User1Priv}|$org1User1Priv|g" \
-e "s|\${org2AdminCert}|$org2AdminCert|g" \
-e "s|\${org2AdminPriv}|$org2AdminPriv|g" \
-e "s|\${org2User1Cert}|$org2User1Cert|g" \
-e "s|\${org2User1Priv}|$org2User1Priv|g" \
-e "s|\${org3AdminCert}|$org3AdminCert|g" \
-e "s|\${org3AdminPriv}|$org3AdminPriv|g" \
-e "s|\${org3User1Cert}|$org3User1Cert|g" \
-e "s|\${org3User1Priv}|$org3User1Priv|g" \
-e "s|\${org4AdminCert}|$org4AdminCert|g" \
-e "s|\${org4AdminPriv}|$org4AdminPriv|g" \
-e "s|\${org4User1Cert}|$org4User1Cert|g" \
-e "s|\${org4User1Priv}|$org4User1Priv|g" \
-e "s|\${org5AdminCert}|$org5AdminCert|g" \
-e "s|\${org5AdminPriv}|$org5AdminPriv|g" \
-e "s|\${org5User1Cert}|$org5User1Cert|g" \
-e "s|\${org5User1Priv}|$org5User1Priv|g" \
-e "s|\${ordererTlsCACert}|$ordererTlsCACert|g" \
-e "s|\${peer0org1TlsCACert}|$peer0org1TlsCACert|g" \
-e "s|\${peer0org2TlsCACert}|$peer0org2TlsCACert|g" \
-e "s|\${peer0org3TlsCACert}|$peer0org3TlsCACert|g" \
-e "s|\${peer0org4TlsCACert}|$peer0org4TlsCACert|g" \
-e "s|\${peer0org5TlsCACert}|$peer0org5TlsCACert|g" \
-e "s|\${caorg1TlsCACert}|$caorg1TlsCACert|g" \
-e "s|\${caorg2TlsCACert}|$caorg2TlsCACert|g" \
-e "s|\${caorg3TlsCACert}|$caorg3TlsCACert|g" \
	network.json.bak >  network.json
