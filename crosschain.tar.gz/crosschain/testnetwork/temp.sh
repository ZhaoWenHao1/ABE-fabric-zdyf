



export SYS_CHANNEL='sys-channel'
IMAGETAG=1.4
cryptogen generate --config=./crypto-config.yaml
configtxgen -profile OrgsOrdererGenesis -channelID ${SYS_CHANNEL} -outputBlock ./channel-artifacts/genesis.block

