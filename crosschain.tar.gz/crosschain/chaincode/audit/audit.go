package main

import (
	"encoding/json"
	"fmt"
	"encoding/pem"
	"crypto/x509"
	"bytes"
	"math/big"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

type polManageChaincode struct {
}

func (t *polManageChaincode) Init(stub shim.ChaincodeStubInterface) peer.Response {

	return shim.Success(nil)
}

func (t *polManageChaincode) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	// 获取用户意图
	req, args := stub.GetFunctionAndParameters()

	if req == "AddPolicy" {
		return t.AddPolicy(stub, args) // 添加信息
	}  else if req == "DelPolicy" {
		return t.DelPolicy(stub, args) // 删除信息
	} else if req == "UpdatePolicy" {
		return t.UpdatePolicy(stub, args) // 更新信息
	}else 	if req == "CrossChannelJudgement" {
		return t.CrossChannelJudgement(stub, args) // 跨链权限判断
	}else 	if req == "ResultJudgement" {
		return t.ResultJudgement(stub, args) // 跨链权限判断
	}else 	if req == "GetJudge" {
		return t.GetJudge(stub, args) // 跨链权限判断
	}else   if req == "GetPol" {
		return t.GetPol(stub, args)
	}else   if req == "GetDataRecord" {
		return t.GetDataRecord(stub, args)
	}else   if req == "Confirm" {
		return t.Confirm(stub, args)
	}else   if req == "SrcToDes" {
		return t.SrcToDes(stub, args)
	}else   if req == "DesToSrc" {
		return t.DesToSrc(stub, args)
	}
	return shim.Error("指定的函数名称错误")

}

func main(){
	err := shim.Start(new(polManageChaincode))
	if err != nil{
		fmt.Printf("starting chaincode go wrong: %s", err)
	}
}

type Policy struct {
	Obj		 string	 `json:"obj"`		  // target data
	Sub		map[string][]string   `json:"role"`  // role and user group
	Opt		 string	 `json:"opt"`		  // query, add, delete, update
	Vernumber   int		`json:"vernumber"`	// policy version
	Iden	 string	 `json:"Iden"`		 // key
	PolHistory  map[string][]int  `json:"user_history"`  //  [user]{vernumber1, vernumber2}
}

type UpChain struct {
	HashData	string	  `json:"hash_data"`
	SrcChain	string	  `json:"src_chain"`   //源链标识
	User		string	  `json:"user"`		//用户标识
	DstChain	string	  `json:"dst_chain"`   //目标链标识
	DataId	  string	  `json:"data_id"`	 //目标数据标识
	TypeOp	  string	  `json:"type_op"`	 //操作类型
	OptIden	 string	  `json:"tx_id"`		//操作号
}
type ErrMassage struct {
	Result   bool			`json:"result"`
	ErrKinds string			`json:"err_kinds"`
	OptId	string			`json:"tx_id"`
}

type JudgeOption struct {
	Req		UpChain		   `json:"upchain"`	// Upchain struct
	Pol		Policy				  `json:"policy"`	 // Policy struct 
	Result	 ErrMassage   `json:"result"` // judgement result
}

type DateRecord struct{
	DateRecordMap   map[string][]string  
}

type Trace struct {
	Record			UpChain   `json:"upchain"`	// Upchain struct
	Tarce_fw_tx_id	string   `json:"trace_fw_tx_id"`  //trace id
}

func GetJudgement(stub shim.ChaincodeStubInterface, Iden string) (JudgeOption, bool) {
	var judge JudgeOption
	//调取策略信息
	b, err := stub.GetState(Iden)
	if err != nil {
		return judge, false
	}
	if b == nil {
		return judge, false
	}

	// 对查询到的状态进行反序列化
	err = json.Unmarshal(b, &judge)
	if err != nil {
		return judge, false
	}

	return judge, true
}

// 保存pol
// args: policy
func PutPolicy(stub shim.ChaincodeStubInterface, pol Policy) (bool) {
	//将策略信息序列化
	b, err := json.Marshal(pol)
	if err != nil {
		return  false
	}

	// 保存策略信息
	err = stub.PutState(pol.Iden, b)
	if err != nil {
		return  false
	}

	return true
}

func GetPolicy(stub shim.ChaincodeStubInterface, Iden string) (Policy, bool) {
	var pol Policy
	//调取策略信息
	b, err := stub.GetState(Iden)
	if err != nil {
		return pol, false
	}
	if b == nil {
		return pol, false
	}

	// 对查询到的状态进行反序列化
	err = json.Unmarshal(b, &pol)
	if err != nil {
		return pol, false
	}

	return pol, true
}

func SaveJudgement(stub shim.ChaincodeStubInterface, req UpChain, pol Policy, result ErrMassage) bool {
	var judge JudgeOption
	judge.Req = req
	judge.Pol = pol
	judge.Result = result

	bl, err := json.Marshal(judge)
	if err != nil {
		return false
	}

	err = stub.PutState(judge.Req.OptIden, bl)
	if err != nil {
		return false
	}

	return true
}

// 异常报告
func ErrMake(stub shim.ChaincodeStubInterface, KindNumber int) ErrMassage {
	var errResult ErrMassage
	errResult.Result = false
	if KindNumber == 3 {
		errResult.Result =  true
	}
	var i int
	i = 0
	var tips = [4]string{"NotCrossChain", "NotFindPolicy", "NotSatifyRoot", "success"}
	for i != KindNumber && i < 4 {
		i = i + 1
	}
	errResult.ErrKinds = tips[i]
	return errResult
}

func  GetUser(stub shim.ChaincodeStubInterface) (string, *big.Int){
	creatorByte,_:= stub.GetCreator()
	certStart := bytes.IndexAny(creatorByte, "-----")
	if certStart == -1 {
	   fmt.Errorf("No certificate found")
	}
	certText := creatorByte[certStart:]
	bl, _ := pem.Decode(certText)
	if bl == nil {
	   fmt.Errorf("Could not decode the PEM structure")
	}
	fmt.Println(string(certText))
	cert, err := x509.ParseCertificate(bl.Bytes)
	if err != nil {
	   fmt.Errorf("ParseCertificate failed")
	}
	fmt.Println(cert)
	uname:=cert.Subject.CommonName
	serialNumber := cert.SerialNumber
	fmt.Println( serialNumber)
	fmt.Println("Name:"+uname)
	return uname, serialNumber
 }


func RecordMake(stub shim.ChaincodeStubInterface, dataid string, optid string) bool {
	b, err := stub.GetState(dataid)
	if err != nil {
		return false
	}
	if b == nil {
		record_DateRecordMap := make(map[string][]string)
		record_DateRecordMap[dataid] = append(record_DateRecordMap[dataid], optid)
		bl, err := json.Marshal(record_DateRecordMap[dataid])
		if err != nil {
			return false
		}

		err = stub.PutState(dataid, bl)
		if err != nil {
			return false
		}
		return true
	}
	
	record_DateRecordMap := make(map[string][]string)
	var strs  []string
	err = json.Unmarshal(b, &strs)
	if err != nil {
		return  false
	}
	record_DateRecordMap[dataid] = strs
	record_DateRecordMap[dataid] = append(record_DateRecordMap[dataid], optid)
	bl, err := json.Marshal(record_DateRecordMap[dataid])
	 if err != nil {
		return false
	}

	var logger = shim.NewLogger("audit_judge")
	logger.Info(bl)

	err = stub.PutState(dataid, bl) 
	if err != nil {
		return false
	}
		return true

}


//跨链审计
func (t *polManageChaincode) CrossChannelJudgement(stub shim.ChaincodeStubInterface, args []string) (peer.Response) {
	if len(args) != 7 {
		return shim.Error("Incorrect number of arguments")
	}
	var logger = shim.NewLogger("audit_judge")
	logger.Info("user: "+ args[2] + "  data_id:"+ args[4] + "  op_type"+args[5])
	var req UpChain
	req.HashData = args[0]
	req.SrcChain = args[1]
	req.User = args[2]
	req.DstChain = args[3]
	req.DataId = args[4]
	req.TypeOp = args[5]
	req.OptIden = args[6]

	Querystring := req.DataId + "share"
	pol, er := GetPolicy(stub, Querystring)
	if !er {
		err_massage := ErrMake(stub, 1)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		stub.SetEvent("Confirm"+ req.SrcChain, bl)
		return shim.Success([]byte(bl))
	}

	if req.SrcChain == req.DstChain {
		err_massage := ErrMake(stub, 0)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		stub.SetEvent("Confirm"+ req.SrcChain, bl)
		return shim.Success([]byte(bl))
	}

	if pol.Vernumber == -1 {
		err_massage := ErrMake(stub, 1)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		stub.SetEvent("Confirm"+ req.SrcChain, bl)
		return shim.Success([]byte(bl))
	}

	str, ok := pol.PolHistory[req.User]
	if  !ok || str[len(str)-1] < 0 {
		err_massage := ErrMake(stub, 2)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		stub.SetEvent("Confirm"+ req.SrcChain, bl)
		return shim.Success([]byte(bl))
	}
		
	exist := false
	for _, v := range pol.Sub {
		for i :=0; i < len(v); i++{
			if v[i] == req.User {
				exist = true
			}
		} 
	}
	if !exist {
		err_massage := ErrMake(stub, 2)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		stub.SetEvent("Confirm"+ req.SrcChain, bl)
		return shim.Success([]byte(bl))
	}

	err_massage := ErrMake(stub, 3)
	err_massage.OptId = req.OptIden 
	SaveJudgement(stub, req, pol, err_massage)
	RecordMake(stub, req.DataId, req.OptIden)
	bl, _ := json.Marshal(err_massage)
	serialNumber,  username := GetUser(stub)
	var logger1 = shim.NewLogger("username")
	logger1.Info(username)
	var logger2 = shim.NewLogger("serialnumber")
	logger2.Info(serialNumber)
	stub.SetEvent("Judge"+ req.DstChain, bl)
	return shim.Success([]byte(bl))
}

// 添加新策略
// 按顺序args: obj, opt, sub
func (s *polManageChaincode) AddPolicy(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) < 3 {
		return shim.Error("need more args")
	}
	var logger = shim.NewLogger("audit_Addpolicy")
	logger.Info(args[0] + "   "+ args[1] + "   "+args[2] + "  "+ args[3])
	var pol Policy
	pol.Obj = args[0]
	pol.Opt = args[1]
	pol.Sub = make(map[string][]string)
	pol.PolHistory = make(map[string][]int)
	if len(args) >= 4 {
		for i := 3; i < len(args); i++ {
			pol.Sub[args[2]] = append(pol.Sub[args[2]], args[i])
			pol.PolHistory[args[i]] = []int{1}
		} //策略权限生成只允许授予一个角色，添加角色需要upgradepolicy
	}else {
		pol.Sub[args[2]] = []string{ }
	}

	pol.Vernumber = 1
	pol.Iden = pol.Obj + pol.Opt

	// 查重: 避免重复权限信息
	_, exist := GetPolicy(stub, pol.Iden)
	if exist {
		return shim.Error("Privilege already exists")
	}
	 
	bl := PutPolicy(stub, pol)
	if !bl {
		return shim.Error("Saving privilege go wrong")
	}

	return shim.Success([]byte("Success in saving privilege"))
}

// 根据策略信息删除信息
// 按顺序args:  obj, sub, opt
func (t *polManageChaincode) DelPolicy(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments")
	}

	var pol Policy
	QueryString := args[0] + args[1]
	pol, bl := GetPolicy(stub, QueryString)
	if !bl {
		return shim.Error("Getting policy go wrong")
	}
	if pol.Iden != QueryString {
		return shim.Error("Cannot get specified policy")
	}

	pol.Vernumber = -1
	err := PutPolicy(stub, pol)
	if !err {
		return shim.Error("Saving privilege go wrong")
	}

	return shim.Success([]byte("Success in deleting privilege"))
}

//更新链码，updatefunc= {addrole, deleterole, adduser, deleteuser}
//args： obj，opt，updata, sub
func (t *polManageChaincode) UpdatePolicy(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) < 3 {
		return shim.Error("need more args")
	}

	QueryString := args[0] + args[1]
	pol, bl := GetPolicy(stub, QueryString)
	if !bl {
		return shim.Error("Getting policy go wrong")
	}
	if pol.Iden != QueryString {
		return shim.Error("Cannot get specified policy")
	}
	
	pol.Vernumber += 1
	if args[2] == "addrole" {
			pol.Sub[args[3]] = []string{ }
		for i := 4; i < len(args); i++ {
			pol.Sub[args[3]] = append(pol.Sub[args[3]], args[i])
			pol.PolHistory[args[i]] = append(pol.PolHistory[args[i]], pol.Vernumber)
		}
	}else if args[2] == "deleterole" {
		for j := 0; j < len(pol.Sub[args[3]]); j++{
			pol.PolHistory[pol.Sub[args[3]][j]] = append(pol.PolHistory[pol.Sub[args[3]][j]], -pol.Vernumber)
		}
		delete(pol.Sub, args[3])
	}else if args[2] == "adduser" {
				for i := 4; i < len(args); i++ {
			pol.Sub[args[3]] = append(pol.Sub[args[3]], args[i])
			pol.PolHistory[args[i]] = append(pol.PolHistory[args[i]], pol.Vernumber)
		}
	}else if args[2] == "deleteuser" {
		for i := 4; i < len(args); i++ {
			for j := 0; j < len(pol.Sub[args[3]]); j++ {
				if pol.Sub[args[3]][j] == args[i] {
					pol.PolHistory[args[i]] = append(pol.PolHistory[args[i]], -pol.Vernumber)
					pol.Sub[args[3]] = append(pol.Sub[args[3]][:j], pol.Sub[args[3]][j+1:]...)
					}
			}
		}
	}

	err := PutPolicy(stub, pol)
	if !err {
		return shim.Error("Saving the old privilege go wrong")
	}
		return shim.Success([]byte("Success in updating privilege"))
}

func (t *polManageChaincode) ResultJudgement(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments")
	}

	judge, err := GetJudgement(stub, args[0])
	if !err {
		return shim.Error("Getting judgementResult go wrong")
	}

	_, ok := judge.Pol.PolHistory[judge.Req.User]
	if  !ok || len(judge.Pol.PolHistory[judge.Req.User])%2 == 0{
		return shim.Error("error")
	}

	exist := false
	for _, v := range judge.Pol.Sub {
		for i :=0; i < len(v); i++{
			if v[i] == judge.Req.User {
				exist = true
			}
		} 
	}
	if !exist {
		return shim.Error("error")
	}
	
	return shim.Success([]byte("Access to resultjudgement"))
}

func (t *polManageChaincode) GetJudge(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments")
	}

	judge, err := GetJudgement(stub, args[0])
	if !err {
		return shim.Error("Getting judgementResult go wrong")
	}
	
	getjudge, _ := json.Marshal(judge)
	return shim.Success([]byte(getjudge))
}

func (t *polManageChaincode) GetPol(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	   if len(args) != 2{
				return shim.Error("Incorrect number of arguments")
	   }

	   pol, err := GetPolicy(stub, args[0] + args[1])
	if !err {
		return shim.Error("Getting Policy go wrong")
	}
		
		getpol, frr := json.Marshal(pol)
		if frr != nil {
				return shim.Error("Getting Policy go wrong")
		}
		var logger = shim.NewLogger("getpol")
		logger.Info(string(getpol))
		return shim.Success([]byte(getpol))
		
}

func (t *polManageChaincode) GetDataRecord(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments")
	}

	b, err := stub.GetState(args[0])
	if err != nil {
		return shim.Error("not exist this record")
	}
	if b == nil {
		return shim.Error("not exist this record")
	}

	return shim.Success([]byte(b))
}

func (t *polManageChaincode) Confirm(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 4 {
		return shim.Error("Incorrect number of arguments")
	}
	var err_massage ErrMassage
	err_massage.OptId = args[2]
	err_massage.ErrKinds =  args[1]
	if args[0] == "0" {
		err_massage.Result =  false
	}else if args[0] == "1" {
		err_massage.Result =  true
	}

	bl, _ := json.Marshal(err_massage)
	stub.SetEvent("Confirm" + args[3], bl)
	return shim.Success([]byte(bl))
}

func (t *polManageChaincode) SrcToDes(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	 des_channel := args[0]
	 tx_id := args[1]
	 trace_fw_tx_id := args[2]
	 src_channel := args[3]
	//  tx_id_byte,_ := json.Marshal(tx_id)
	 b, _ := json.Marshal([]string{des_channel, tx_id, trace_fw_tx_id, src_channel})
	 stub.SetEvent("SrctoDes" + des_channel,  b)
	//  b, _ := json.Marshal([]string{des_channel, tx_id, trace_fw_tx_id, src_channel})
	 return shim.Success([]byte(b))
}

func (t *polManageChaincode) DesToSrc(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	var req UpChain
	req.HashData = args[0]
	req.SrcChain = args[1]
	req.User = args[2]
	req.DstChain = args[3]
	req.DataId = args[4]
	req.TypeOp = args[5]
	req.OptIden = args[6]

	des_channel := args[7]
	
	var trace Trace 
	trace.Record = req
	trace.Tarce_fw_tx_id = args[8]
	tx_id_byte,_ := json.Marshal(trace)
	b, _ := json.Marshal(trace)

	stub.SetEvent("DesToSrc" + des_channel,  tx_id_byte)

	// b, _ := json.Marshal(trace)
	return shim.Success([]byte(b))
}
