package main

import(
	"encoding/json"
	"encoding/hex"
	"encoding/pem"
	"fmt"
	"crypto/sha256"
	"crypto/x509"
	"strconv"
	"time"
	"bytes"
	
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

//声明名为RecordChaincode的结构体
type RecordChaincode struct{
}

//声明跨链记录(Record)结构体
type Record struct{
	HashData	string		`json:"hash_data"`	//数据密文hash
	SrcChain	string		`json:"src_chain"`	//源链标识
	User		string		`json:"user"`		 //用户标识
	DstChain	string		`json:"dst_chain"`	//目标链标识
	DataId		string		`json:"data_id"`	  //目标数据标识
	TypeTx		string		`json:"type_tx"`	  //事务的操作类型
	ThisTxId	string		`json:"this_tx_id"`   //本次事务号
	LastTxId	string		`json:"last_tx_id"`   //上次事务号
}

//声明链内记录(ChainRecord)结构体
type ChainRecord struct{
	HashData	string		`json:"hash_data"`	//数据密文hash
	SrcChain	string		`json:"src_chain"`	//源链标识
	User		string		`json:"user"`		 //用户标识
	DataId		string		`json:"data_id"`	  //目标数据标识
	TypeTx		string		`json:"type_tx"`	  //事务的操作类型
	ThisTxId	string		`json:"this_tx_id"`   //本次事务号
	LastTxId	string		`json:"last_tx_id"`   //上次事务号
}

type ErrMassage struct {
	Result   	bool		`json:"result"`
	ErrKinds 	string		`json:"err_kinds"`
	OptId		string		`json:"tx_id"`
}

type ErrMessage struct{
	Result   	bool		`json:"result"`
	ErrKinds 	string		`json:"err_kinds"`
	OptId		string		`json:"tx_id"`
	SrcChain	string		`json:"src_chain"`
}

//声明跨链追踪(CrossTrace)结构体
type CrossTrace struct{
	TxId		string		`json:"txid"`		  //追踪事务的事务号
	ThisTxId	string		`json:"this_tx_id"`   //本次事物号
	DstChain	string		`json:"dst_chain"`	  //文件副本所在链
}

func (t *RecordChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response{
	return shim.Success(nil)
}

func (t *RecordChaincode) Invoke(stub shim.ChaincodeStubInterface) pb.Response{
	function,args := stub.GetFunctionAndParameters()
	// fmt.Println("invoke is running " + function)

	if function == "srcAuditRecord"{
		return t.srcAuditRecord(stub, args)
	} else if function == "dstAuditRecord"{
		return t.dstAuditRecord(stub, args)
	} else if function == "srcSyncRecord"{
		return t.srcSyncRecord(stub, args)
	} else if function == "dstSyncRecord" {
		return t.dstSyncRecord(stub, args)
	} else if function == "chainAuditRecord"{
		return t.chainAuditRecord(stub, args)
	} else if function == "chainSyncRecord"{
		return t.chainSyncRecord(stub, args)
	} else if function == "Confirm"{
		return t.Confirm(stub, args)
	} else if function == "query"{
		return t.query(stub, args)
	} else if function == "queryDataid"{
		return t.queryDataid(stub, args)
	} else if function == "traceBackward"{
		return t.traceBackward(stub, args)
	} else if function == "traceForward"{
		return t.traceForward(stub, args)
	} else if function == "crossTraceForward"{
		return t.crossTraceForward(stub, args)
	} else if function == "TFComplete"{
		return t.TFComplete(stub, args)
	}

	// fmt.Println("invoke did not find func: " + function)
	return shim.Error("Received unknown function invocation")
}

//跨链中，操作链第一次上链，为权限审计提供链上数据支持
//args: hashdata, srcchain, user, dstchain, dataid, typetx
//注：send操作中user为目标链用户
func (t *RecordChaincode)srcAuditRecord(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 6 {
		return shim.Error("Incorrect number of arguments. Expecting 6")
	}

	hashdata := args[0]
	srcchain := args[1]	
	user := args[2]
	dstchain := args[3]
	dataid := args[4]
	typetx := args[5]

	//非send操作中验证合约调用者身份的合法性
	if (typetx == "pull" || typetx == "view"){
		username := getUser(stub)
		if username != user{
			return shim.Error("The requesting user does not match the actual user")
		}
	}

	timestamp := strconv.FormatInt(time.Now().UnixNano(), 10)	//获取string类型的时间戳

	txstr := srcchain + "_" + user + "_" + dstchain + "_" + dataid + "_" + typetx + "_" + timestamp
	thistxid := sha256Str(txstr)	//计算本次事务号

	var lasttxid string

	record := &Record{hashdata, srcchain, user, dstchain, dataid, typetx, thistxid, lasttxid}

	recordJSONasBytes,err := json.Marshal(record)
	if err != nil{
		return shim.Error(err.Error())
	}

	thistxid_order := thistxid+"_1"	//为事务号附加上链序号

	//保存状态
	err = stub.PutState(thistxid_order, recordJSONasBytes)
	if err != nil{
		return shim.Error(err.Error())
	}

	err = stub.SetEvent("srcAuditEvent", recordJSONasBytes)
	if err != nil{
		return shim.Error(err.Error())
	}

	fmt.Println("the transaction id of record first time: ", thistxid_order)
	return shim.Success(recordJSONasBytes)
}

//跨链中，目标链第一次上链，为权限审计提供链上数据支持
//args: hashdata, srcchain, user, dstchain, dataid, typetx, thistxid
func (t *RecordChaincode)dstAuditRecord(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 7 {
		return shim.Error("Incorrect number of arguments. Expecting 7")
	}

	hashdata := args[0]
	srcchain := args[1]	
	user := args[2]
	dstchain := args[3]
	dataid := args[4]
	typetx := args[5]
	thistxid := args[6]

	/*
	timestamp := strconv.FormatInt(time.Now().Unix(), 10)	//获取string类型的时间戳

	txstr := srcchain + "_" + user + "_" + dstchain + "_" + dataid + "_" + typetx + "_" + timestamp
	thistxid := sha256Str(txstr)	//计算本次事务号
	*/

	var lasttxid string

	record := &Record{hashdata, srcchain, user, dstchain, dataid, typetx, thistxid, lasttxid}

	recordJSONasBytes,err := json.Marshal(record)
	if err != nil{
		return shim.Error(err.Error())
	}

	thistxid_order := thistxid+"_1"	//为事务号附加上链序号

	//保存状态
	err = stub.PutState(thistxid_order, recordJSONasBytes)
	if err != nil{
		return shim.Error(err.Error())
	}

	errmessage := ErrMessage{}
	errmessage.OptId = thistxid
	errmessage.ErrKinds = ""
	errmessage.Result = true
	errmessage.SrcChain = srcchain

	bl, err := json.Marshal(errmessage)
	if err != nil{
		return shim.Error(err.Error())
	}
	err = stub.SetEvent("dstAuditEvent", bl)
	if err != nil{
		return shim.Error(err.Error())
	}

	fmt.Println("the transaction id of record first time: ", thistxid_order)
	return shim.Success(recordJSONasBytes)
}

//跨链中，操作链第二次上链，更新链上数据hash值，实现与链下数据的同步
//args: hashdata, srcchain, user, dstchain, dataid, typetx, thistxid
func (t *RecordChaincode)srcSyncRecord(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 7{
		return shim.Error("Incorrect number of arguments. Expecting 7")
	}

	hashdata := args[0]
	srcchain := args[1]	
	user := args[2]
	dstchain := args[3]
	dataid := args[4]
	typetx := args[5]
	thistxid := args[6]

	//获取本事务的上次事务号
	var lasttxid string
	if typetx == "pull"{
		lasttxid = "0"
	} else{
		recenttxid,err := stub.GetState(dataid)
		if err != nil{
			return shim.Error("Failed to get recent transaction_id for: " + dataid)
		}
		lasttxid = string(recenttxid)
	}

	record := &Record{hashdata, srcchain, user, dstchain, dataid, typetx, thistxid, lasttxid}

	recordJSONasBytes,err := json.Marshal(record)
	if err != nil{
		return shim.Error(err.Error())
	}

	thistxid_order := thistxid+"_2"	//本次事务号附加上链序号

	//保存状态
	err = stub.PutState(thistxid_order, recordJSONasBytes)
	if err != nil{
		return shim.Error(err.Error())
	}

	//创建数据追踪路径(key:上次事务号,value:本次事务号)
	if typetx == "pull"{
		err = stub.PutState(dataid+"_trace", []byte(thistxid))
		if err != nil{
			return shim.Error(err.Error())
		}
	} else{
		err = stub.PutState(lasttxid, []byte(thistxid))
		if err != nil{
			return shim.Error(err.Error())
		}
	}

	//在域内文件数组中增加该文件id
	if typetx == "pull"{
		var data_array []string
		dataarrayAsBytes,err := stub.GetState(srcchain)
		if err != nil{
			return shim.Error(err.Error())
		} else if dataarrayAsBytes != nil{
			err := json.Unmarshal(dataarrayAsBytes, &data_array)
			if err != nil{
				return shim.Error(err.Error())
			}
		}
		data_array = append(data_array, dataid)
		arrayAsBytes,err := json.Marshal(data_array)
		if err != nil{
			return shim.Error(err.Error())
		}
		err = stub.PutState(srcchain, arrayAsBytes)
		if err != nil{
			return shim.Error(err.Error())
		}
	}

	//更新数据的最近一次事务号
	err = stub.PutState(dataid, []byte(thistxid))
	if err != nil{
		return shim.Error(err.Error())
	}

	fmt.Println("the transaction id of record second time: ", thistxid_order)
	return shim.Success(recordJSONasBytes)
}

//跨链中，目标链第二次上链，更新链上数据hash值，实现与链下数据的同步
//args: hashdata, srcchain, user, dstchain, dataid, typetx, thistxid
func (t *RecordChaincode)dstSyncRecord(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 7{
		return shim.Error("Incorrect number of arguments. Expecting 7")
	}

	hashdata := args[0]
	srcchain := args[1]	
	user := args[2]
	dstchain := args[3]
	dataid := args[4]
	typetx := args[5]
	thistxid := args[6]

	//获取本事务的上次事务号
	var lasttxid string
	if typetx == "push"{
		lasttxid = "0"
	} else{
		fmt.Println("dstSyncRecord is .....",dataid)
		recenttxid,err := stub.GetState(dataid)
		if err != nil{			
			return shim.Error("Failed to get recent transaction_id for: " + dataid)
		}
		lasttxid = string(recenttxid)
	}
	fmt.Println("lasttxid",lasttxid)
	fmt.Println("thistxid",thistxid)
	record := &Record{hashdata, srcchain, user, dstchain, dataid, typetx, thistxid, lasttxid}

	recordJSONasBytes,err := json.Marshal(record)
	if err != nil{
		return shim.Error(err.Error())
	}

	thistxid_order := thistxid+"_2"	//本次事务号附加上链序号

	//保存状态
	err = stub.PutState(thistxid_order, recordJSONasBytes)
	if err != nil{
		return shim.Error(err.Error())
	}

	//创建数据追踪路径(key:上次事务号,value:本次事务号)
	if typetx == "push"{
		err = stub.PutState(dataid+"_trace", []byte(thistxid))
		if err != nil{
			return shim.Error(err.Error())
		}
	} else{
		err = stub.PutState(lasttxid, []byte(thistxid))
		if err != nil{
			return shim.Error(err.Error())
		}
	}

	//在域内文件数组中增加该文件id
	if typetx == "push"{
		var data_array []string
		dataarrayAsBytes,err := stub.GetState(dstchain)
		if err != nil{
			return shim.Error(err.Error())
		} else if dataarrayAsBytes != nil{
			err := json.Unmarshal(dataarrayAsBytes, &data_array)
			if err != nil{
				return shim.Error(err.Error())
			}
		}
		data_array = append(data_array, dataid)
		arrayAsBytes,err := json.Marshal(data_array)
		if err != nil{
			return shim.Error(err.Error())
		}
		err = stub.PutState(dstchain, arrayAsBytes)
		if err != nil{
			return shim.Error(err.Error())
		}
	}

	//更新数据的最近一次事务号
	err = stub.PutState(dataid, []byte(thistxid))
	if err != nil{
		return shim.Error(err.Error())
	}

	fmt.Println("the transaction id of record second time: ", thistxid_order)
	return shim.Success(recordJSONasBytes)
}

//链内操作第一次上链，为权限审计提供链上数据支持
//args: hashdata, srcchain, user, dataid, typetx
func (t *RecordChaincode)chainAuditRecord(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 5 {
		return shim.Error("Incorrect number of arguments. Expecting 4")
	}

	hashdata := args[0]
	srcchain := args[1]   
	user := args[2]
	dataid := args[3]
	typetx := args[4]

	//验证合约调用者身份的合法性
	username := getUser(stub)
	if username != user{
		return shim.Error("The requesting user does not match the actual user")
	}

	timestamp := strconv.FormatInt(time.Now().UnixNano(), 10)	//获取string类型的时间戳

	txstr := srcchain + "_" + user + "_" + dataid + "_" + typetx + "_" + timestamp
	thistxid := sha256Str(txstr)	//计算本次事务号

	var lasttxid string

	record := &ChainRecord{hashdata, srcchain, user, dataid, typetx, thistxid, lasttxid}

	recordJSONasBytes,err := json.Marshal(record)
	if err != nil{
		return shim.Error(err.Error())
	}

	thistxid_order := thistxid+"_1"	//为事务号附加上链序号

	//保存状态
	err = stub.PutState(thistxid_order, recordJSONasBytes)
	if err != nil{
		return shim.Error(err.Error())
	}

	//调用权限审计链码，判断操作请求是否被允许
	Arg := [][]byte{[]byte("Judgement"),[]byte(hashdata),[]byte(user),[]byte(srcchain),[]byte(dataid),[]byte(typetx),[]byte(thistxid)}
	respond := stub.InvokeChaincode("channel_audit", Arg, srcchain)
	if respond.Status != shim.OK{
		errmessage := ErrMessage{}
		errmessage.Result = false
		errmessage.OptId = thistxid
		errmessage.ErrKinds = "CallFailed"
		errmessage.SrcChain = srcchain

		bl, err := json.Marshal(errmessage)
		if err != nil{
			return shim.Error(err.Error())
		}
		err = stub.SetEvent("chainAuditEvent_CallFailed", bl)
		if err != nil{
			return shim.Error(err.Error())
		}
		return shim.Error(err.Error())
	}
	errmessage := ErrMassage{}
	err = json.Unmarshal(respond.Payload, &errmessage)
	if err != nil{
		return shim.Error(err.Error())
	}
	if errmessage.Result{
		err = stub.SetEvent("chainAuditEvent_pass", recordJSONasBytes)
		if err != nil{
			return shim.Error(err.Error())
		}
	} else{
		err_message := ErrMessage{}
		err_message.Result = false
		err_message.OptId = thistxid
		err_message.ErrKinds = "RequstDenied"
		err_message.SrcChain = srcchain

		bl, err := json.Marshal(err_message)
		if err != nil{
			return shim.Error(err.Error())
		}
		err = stub.SetEvent("chainAuditEvent_deny", bl)
		if err != nil{
			return shim.Error(err.Error())
		}
		return shim.Success(bl)
	}

	fmt.Println("the transaction id of record first time: ", thistxid_order)
	return shim.Success(recordJSONasBytes)
}

//链内操作第二次上链，更新链上数据hash值，实现与链下数据的同步
//args: hashdata, user, dataid, typetx, thistxid
func (t *RecordChaincode)chainSyncRecord(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 6{
		return shim.Error("Incorrect number of arguments. Expecting 5")
	}

	hashdata := args[0]
	srcchain := args[1]   
	user := args[2]
	dataid := args[3]
	typetx := args[4]
	thistxid := args[5]

	//获取本事务的上次事务号
	var lasttxid string
	if typetx == "add"{
		lasttxid = "0"
	} else{
		recenttxid,err := stub.GetState(dataid)
		if err != nil{
			return shim.Error("Failed to get recent transaction_id for: " + dataid)
		}
		lasttxid = string(recenttxid)
	}

	record := &ChainRecord{hashdata, srcchain, user, dataid, typetx, thistxid, lasttxid}

	recordJSONasBytes,err := json.Marshal(record)
	if err != nil{
		return shim.Error(err.Error())
	}

	thistxid_order := thistxid+"_2"	//本次事务号附加上链序号

	//保存状态
	err = stub.PutState(thistxid_order, recordJSONasBytes)
	if err != nil{
		return shim.Error(err.Error())
	}

	//创建数据追踪路径(key:上次事务号,value:本次事务号)
	if typetx == "add"{
		err = stub.PutState(dataid+"_trace", []byte(thistxid))
		if err != nil{
			return shim.Error(err.Error())
		}
	} else{
		err = stub.PutState(lasttxid, []byte(thistxid))
		if err != nil{
			return shim.Error(err.Error())
		}
	}

	//若是add操作，在域内文件数组中增加该文件id
	if typetx == "add"{
		var data_array []string
		dataarrayAsBytes,err := stub.GetState(srcchain)
		if err != nil{
			return shim.Error(err.Error())
		} else if dataarrayAsBytes != nil{
			err := json.Unmarshal(dataarrayAsBytes, &data_array)
			if err != nil{
				return shim.Error(err.Error())
			}
		}
		data_array = append(data_array, dataid)
		arrayAsBytes,err := json.Marshal(data_array)
		if err != nil{
			return shim.Error(err.Error())
		}
		err = stub.PutState(srcchain, arrayAsBytes)
		if err != nil{
			return shim.Error(err.Error())
		}
	}

	//若是delete操作，在域内文件数组中删除该文件id
	if typetx == "delete"{
		var data_array []string
		dataarrayAsBytes,err := stub.GetState(srcchain)
		if err != nil{
			return shim.Error(err.Error())
		}
		err = json.Unmarshal(dataarrayAsBytes, &data_array)
		if err != nil{
			return shim.Error(err.Error())
		}
		for k,v := range data_array{
			if v == dataid{
				data_array = append(data_array[:k], data_array[k+1:]...)
				break
			}
		}
		arrayAsBytes,err := json.Marshal(data_array)
		if err != nil{
			return shim.Error(err.Error())
		}
		err = stub.PutState(srcchain, arrayAsBytes)
		if err != nil{
			return shim.Error(err.Error())
		}
	}

	//更新数据的最近一次事务号
	fmt.Println("chain sync dataid is", dataid)
	err = stub.PutState(dataid, []byte(thistxid))
	if err != nil{
		return shim.Error(err.Error())
	}

	fmt.Println("the transaction id of record second time: ", thistxid_order)
	return shim.Success(recordJSONasBytes)
}

//域内审核结果上链
func (t *RecordChaincode)Confirm(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args)!=3{
		return shim.Error("Incorrect number of arguments. Expecting 3")
	}

	errmessage := ErrMassage{}
	errmessage.OptId = args[2]
	errmessage.ErrKinds = args[1]
	if args[0] == "0"{
		errmessage.Result = false
	} else if args[0] == "1"{
		errmessage.Result = true
	}

	bl, err := json.Marshal(errmessage)
	if err != nil{
		return shim.Error(err.Error())
	}
	err = stub.SetEvent("Confirm"+args[2], bl)
	if err != nil{
		return shim.Error(err.Error())
	}
	return shim.Success(bl)
}

//根据事务号查询结构体信息
//args: txid, order
func (t *RecordChaincode)query(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 2{
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}

	var queryString,jsonResp string

	txid := args[0]
	order := args[1]

	queryString = txid + "_" + order

	valAsBytes,err := stub.GetState(queryString)
	if err != nil{
		jsonResp = "{\"Error\":\"Failed to get state for " + queryString + "\"}"
		return shim.Error(jsonResp)
	}else if valAsBytes == nil{
		jsonResp = "{\"Error\":\"record struct does not exist: " + queryString + "\"}"
		return shim.Error(jsonResp)
	}

	return shim.Success(valAsBytes)
}

//根据链标识查询链中所有的dataid
//args: chain
func (t *RecordChaincode)queryDataid(stub shim.ChaincodeStubInterface,args []string)pb.Response{
	if len(args) != 1{
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	chain := args[0]

	dataarrayAsBytes,err := stub.GetState(chain)
	if err != nil{
		return shim.Error(err.Error())
	}
	
	return shim.Success(dataarrayAsBytes)
}

//数据溯源：溯源目标数据最新的事务或某事务前的一次事务
//args: dataid, txid(可选)
func (t *RecordChaincode)traceBackward(stub shim.ChaincodeStubInterface, args []string)pb.Response{
	if len(args) == 1{
		dataid := args[0]
		recenttxidAsBytes,err := stub.GetState(dataid)
		if err != nil{
			return shim.Error(err.Error())
		} else if recenttxidAsBytes == nil{	//目标数据不存在
			return shim.Error("Failed! data does not exist")
		}
		//return shim.Success(recenttxidAsBytes)
		recenttxid := string(recenttxidAsBytes)
		recordJsonAsBytes, err := stub.GetState(recenttxid+"_2")
		if err != nil{
			return shim.Error(err.Error())
		}
		return shim.Success(recordJsonAsBytes)
	} else if len(args) == 2{
		dataid := args[0]
		txid := args[1]
		recordAsBytes, err := stub.GetState(txid+"_2")
		if err != nil{
			return shim.Error(err.Error())
		} else if recordAsBytes == nil{
			return shim.Error(err.Error())
		}
		record := Record{}
		err = json.Unmarshal(recordAsBytes, &record)
		if err != nil{
			return shim.Error(err.Error())
		}
		if record.DataId != dataid{
			return shim.Error("Failed! " + txid + " is not the transaction of " + dataid)
		}
		if record.LastTxId == "0"{
			return shim.Success([]byte("0"))
		}
		//return shim.Success([]byte(record.LastTxId))
		recordJsonAsBytes,err := stub.GetState(record.LastTxId+"_2")
		if err != nil{
			return shim.Error(err.Error())
		}
		return shim.Success(recordJsonAsBytes)
	} else{
		return shim.Error("Incorrect number of arguments. Expecting 1 or 2")
	}
}

//数据追踪：追踪目标数据最初的事务或某事务后的一次事务
//args: dataid, txid(可选)
func (t *RecordChaincode)traceForward(stub shim.ChaincodeStubInterface, args []string)pb.Response{
	if len(args) == 1{
		dataid := args[0]
		nexttxidAsBytes, err := stub.GetState(dataid+"_trace")
		if err != nil{
			return shim.Error(err.Error())
		} else if nexttxidAsBytes == nil{	//目标数据不存在
			return shim.Error("Failed! data does not exist")
		}
		//return shim.Success(nexttxidAsBytes)
		nexttxid := string(nexttxidAsBytes)
		recordJsonAsBytes,err := stub.GetState(nexttxid+"_2")
		if err != nil{
			return shim.Error(err.Error())
		}
		return shim.Success(recordJsonAsBytes)
	} else if len(args) == 2{
		var logger = shim.NewLogger("record_forward")
		dataid := args[0]
		txid := args[1]

		recordAsBytes, err := stub.GetState(txid+"_2")
		if err != nil{
			return shim.Error(err.Error())
		} else if recordAsBytes == nil{
			return shim.Error(err.Error())
		}
		record := Record{}
		err = json.Unmarshal(recordAsBytes, &record)
		if err != nil{
			return shim.Error(err.Error())
		}
		if record.DataId != dataid{
			return shim.Error("Failed! " + txid + " is not the transaction of " + dataid)
		}

		nexttxidAsBytes, err := stub.GetState(txid)
		logger.Info(string(nexttxidAsBytes))
		if err != nil{
			return shim.Error(err.Error())
		} else if nexttxidAsBytes == nil{
			return shim.Success([]byte("0"))
		}
		//return shim.Success(nexttxidAsBytes)
		nexttxid := string(nexttxidAsBytes)
		recordJsonAsBytes,err := stub.GetState(nexttxid+"_2")
		if err != nil{
			return shim.Error(err.Error())
		}
		return shim.Success(recordJsonAsBytes)
	} else{
		return shim.Error("Incorrect number of arguments. Expecting 1 or 2")
	}
}

//数据跨链追踪：发送事件告知目标链代理节点待追踪的事务号
//args: thistxid, dstchain
func (t *RecordChaincode)crossTraceForward(stub shim.ChaincodeStubInterface, args []string)pb.Response{
	if len(args) != 2{
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}

	thistxid := args[0]
	dstchain := args[1]

	timestamp := strconv.FormatInt(time.Now().UnixNano(), 10)	//获取string类型的时间戳

	txstr := thistxid + "_" + dstchain + "_" + timestamp
	txid := sha256Str(txstr)	//计算追踪事务的事务号

	crosstrace := CrossTrace{}
	crosstrace.TxId = txid
	crosstrace.ThisTxId = thistxid
	crosstrace.DstChain = dstchain

	crosstraceAsBytes,err := json.Marshal(crosstrace)
	if err != nil{
		return shim.Error(err.Error())
	}
	err = stub.SetEvent("CrossTrace",crosstraceAsBytes)
	if err != nil{
		return shim.Error(err.Error())
	}
	return shim.Success(crosstraceAsBytes)
}

//数据跨域追踪返回
//args: txid, hashdata, srcchain, user, dstchain, dataid, typetx, thistxid, lasttxid
func (t *RecordChaincode)TFComplete(stub shim.ChaincodeStubInterface, args []string)pb.Response{
	if len(args) != 9{
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}

	txid := args[0]
	hashdata := args[1]
	srcchain := args[2]
	user := args[3]
	dstchain := args[4]
	dataid := args[5]
	typetx := args[6]
	thistxid := args[7]
	lasttxid := args[8]

	record := &Record{hashdata, srcchain, user, dstchain, dataid, typetx, thistxid, lasttxid}
	recordJsonAsBytes,err := json.Marshal(record)
	if err != nil{
		return shim.Error(err.Error())
	}
	err = stub.SetEvent("TFComplete"+txid, recordJsonAsBytes)
	if err != nil{
		return shim.Error(err.Error())
	}
	return shim.Success(recordJsonAsBytes)
}

//对字符串str计算sha256
func sha256Str(str string)string{
	hash := sha256.New()
	hash.Write([]byte(str))
	sum := hash.Sum(nil)
	result := hex.EncodeToString(sum)
	return result
}

//调取用户信息
func getUser(stub shim.ChaincodeStubInterface)string{
	creatorByte, _ := stub.GetCreator()
	certStart := bytes.IndexAny(creatorByte,"-----")
	if certStart == -1{
		fmt.Errorf("No certificate found")
	}
	certText := creatorByte[certStart:]
	bl, _ := pem.Decode(certText)
	if bl == nil{
		fmt.Errorf("Could not decode the PEM structure")
	}
	// fmt.Println(string(certText))
	cert, err:= x509.ParseCertificate(bl.Bytes)
	if err != nil{
		fmt.Errorf("ParseCertificate failed")
	}
	// fmt.Println(cert)
	uname := cert.Subject.CommonName
	// fmt.Println("Name: " + uname)
	return uname
}

func main(){
	err := shim.Start(new(RecordChaincode))
	if err != nil{
		fmt.Printf("Error starting Record Chaincode: %s", err)
	}
}

