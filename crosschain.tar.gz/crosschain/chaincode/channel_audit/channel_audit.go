package main

import (
	"encoding/json"
	"fmt"
	"encoding/pem"
	"crypto/x509"
	"bytes"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

type AuditChaincode struct {
}

type Audit interface {
}

func (t *AuditChaincode) Init(stub shim.ChaincodeStubInterface) peer.Response {

	return shim.Success(nil)
}

func (t *AuditChaincode) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	// 获取用户意图
	req, args := stub.GetFunctionAndParameters()

	if req == "Judgement" {
		return t.Judgement(stub, args) // 跨链权限判断
	}else 	if req == "GetJudge" {
		return t.GetJudge(stub, args) 
	}else   if req == "GetDataRecord" {
		return t.GetDataRecord(stub, args)
	}

	return shim.Error("指定的函数名称错误")

}

func main(){
	err := shim.Start(new(AuditChaincode))
	if err != nil{
		fmt.Printf("starting chaincode go wrong: %s", err)
	}
}

type Policy struct {
	Obj		 string	 `json:"obj"`		  // target data
	Sub		map[string][]string   `json:"role"`  // role and user group
	Opt		 string	 `json:"opt"`		  // query, add, delete, update
	Vernumber   int		`json:"vernumber"`	// policy version
	Iden	 string	 `json:"Iden"`		 // key
	PolHistory  map[string][]int  `json:"user_history"`  //  [user]{vernumber1, vernumber2}
}

type UpChain struct {
	HashData	string	  `json:"hash_data"`
	SrcChain	string	  `json:"src_chain"`   //源链标识
	User		string	  `json:"user"`		//用户标识
	DataId	  string	  `json:"data_id"`	 //目标数据标识
	TypeOp	  string	  `json:"type_op"`	 //操作类型
	OptIden	 string	  `json:"tx_id"`		//操作号
}
type ErrMassage struct {
	Result   bool			`json:"result"`
	ErrKinds string			`json:"err_kinds"`
	OptId	string			`json:"tx_id"`
}

type JudgeOption struct {
	Req		UpChain		   `json:"upchain"`	// Upchain struct
	Pol		Policy				  `json:"policy"`	 // Policy struct 
	Result	 ErrMassage   `json:"result"` // judgement result
}

type DateRecord struct{
	DateRecordMap   map[string][]string  
}

func GetJudgement(stub shim.ChaincodeStubInterface, Iden string) (JudgeOption, bool) {
	var judge JudgeOption
	//调取策略信息
	b, err := stub.GetState(Iden)
	if err != nil {
		return judge, false
	}
	if b == nil {
		return judge, false
	}

	// 对查询到的状态进行反序列化
	err = json.Unmarshal(b, &judge)
	if err != nil {
		return judge, false
	}

	return judge, true
}

func SaveJudgement(stub shim.ChaincodeStubInterface, req UpChain, pol Policy, result ErrMassage) bool {
	var judge JudgeOption
	judge.Req = req
	judge.Pol = pol
	judge.Result = result

	bl, err := json.Marshal(judge)
	if err != nil {
		return false
	}

	err = stub.PutState(judge.Req.OptIden, bl)
	if err != nil {
		return false
	}

	return true
}

// 异常报告
func ErrMake(stub shim.ChaincodeStubInterface, KindNumber int) ErrMassage {
	var errResult ErrMassage
	errResult.Result = false
	if KindNumber == 3 {
		errResult.Result =  true
	}
	var i int
	i = 0
	var tips = [4]string{"NotInvokeChaincode", "NotFindPolicy", "NotSatifyRoot", "success"}
	for i != KindNumber && i < 4 {
		i = i + 1
	}
	errResult.ErrKinds = tips[i]
	return errResult
}

func  GetUser(stub shim.ChaincodeStubInterface) string {
	creatorByte,_:= stub.GetCreator()
	certStart := bytes.IndexAny(creatorByte, "-----")
	if certStart == -1 {
	   fmt.Errorf("No certificate found")
	}
	certText := creatorByte[certStart:]
	bl, _ := pem.Decode(certText)
	if bl == nil {
	   fmt.Errorf("Could not decode the PEM structure")
	}
	fmt.Println(string(certText))
	cert, err := x509.ParseCertificate(bl.Bytes)
	if err != nil {
	   fmt.Errorf("ParseCertificate failed")
	}
	fmt.Println(cert)
	uname:=cert.Subject.CommonName
	fmt.Println("Name:"+uname)
	return uname
 }


func RecordMake(stub shim.ChaincodeStubInterface, dataid string, optid string) (bool) {
	b, err := stub.GetState(dataid)
	if err != nil {
		return false
	}
	if b == nil {
		record_DateRecordMap := make(map[string][]string)
		record_DateRecordMap[dataid] = append(record_DateRecordMap[dataid], optid)
		bl, err := json.Marshal(record_DateRecordMap[dataid])
		if err != nil {
			return false
		}

		err = stub.PutState(dataid, bl)
		if err != nil {
			return false
		}
		return true
	}
	
	record_DateRecordMap := make(map[string][]string)
	var strs  []string
	err = json.Unmarshal(b, &strs)
	if err != nil {
		return  false
	}
	record_DateRecordMap[dataid] = strs
	record_DateRecordMap[dataid] = append(record_DateRecordMap[dataid], optid)
	bl, err := json.Marshal(record_DateRecordMap[dataid])
	 if err != nil {
		return false
	}

	var logger = shim.NewLogger("audit_judge")
	logger.Info(bl)

	err = stub.PutState(dataid, bl) 
	if err != nil {
		return false
	}
		return true

}


//跨链审计
func (t *AuditChaincode) Judgement(stub shim.ChaincodeStubInterface, args []string) (peer.Response) {
	if len(args) != 6 {
		return shim.Error("Incorrect number of arguments")
	}
	username :=GetUser(stub)
	if username != args[1] {
		return shim.Error("user massage is wrong")
	}

	var req UpChain
	var pol Policy
	req.HashData = args[0]
	req.User = args[1]
	req.SrcChain = args[2]
	req.DataId = args[3]
	req.TypeOp = args[4]
	req.OptIden = args[5]

	var data_id string
	if req.TypeOp == "add" {
		data_id = req.SrcChain 
	} else  {
		data_id = req.DataId
	}

	Arg:=[][]byte{[]byte("QueryPolicy"),[]byte(data_id),[]byte(req.TypeOp)}
	respond := stub.InvokeChaincode("Policy", Arg , req.SrcChain)
	_ = json.Unmarshal(respond.Payload, &pol)
	fmt.Println(pol)
	if pol.Iden != data_id + req.TypeOp  {
		err_massage := ErrMake(stub, 0)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		return shim.Success([]byte(bl))
	}

	if pol.Vernumber == -1 {
		err_massage := ErrMake(stub, 1)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		return shim.Success([]byte(bl))
	}

	_, ok := pol.PolHistory[req.User]
	if  !ok || pol.PolHistory[req.User][len(pol.PolHistory[req.User])-1] < 0 {
		err_massage := ErrMake(stub, 2)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		return shim.Success([]byte(bl))
	}
	
		
	exist := false
	for _, v := range pol.Sub {
		for i :=0; i < len(v); i++{
			if v[i] == req.User {
				exist = true
			}
		} 
	}
	if !exist {
		err_massage := ErrMake(stub, 2)
		err_massage.OptId = req.OptIden 
		SaveJudgement(stub, req, pol, err_massage)
		RecordMake(stub, req.DataId, req.OptIden)
		bl, _ := json.Marshal(err_massage)
		return shim.Success([]byte(bl))
	}

	err_massage := ErrMake(stub, 3)
	err_massage.OptId = req.OptIden 
	SaveJudgement(stub, req, pol, err_massage)
	RecordMake(stub, req.DataId, req.OptIden)
	bl, _ := json.Marshal(err_massage)
	return shim.Success([]byte(bl))
}

func (t *AuditChaincode) GetJudge(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments")
	}

	judge, err := GetJudgement(stub, args[0])
	if !err {
		return shim.Error("Getting judgementResult go wrong")
	}
	
	getjudge, _ := json.Marshal(judge)
	return shim.Success([]byte(getjudge))
}

func (t *AuditChaincode) GetDataRecord(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments")
	}

	b, err := stub.GetState(args[0])
	if err != nil {
		return shim.Error("not exist this record")
	}
	if b == nil {
		return shim.Error("not exist this record")
	}

	return shim.Success([]byte(b))
}