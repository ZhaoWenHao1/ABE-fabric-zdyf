package main

import (
	"bytes"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

type PolicyCC interface {
}

type PolicyChaincode struct {
}


func (t *PolicyChaincode) Init(stub shim.ChaincodeStubInterface) peer.Response {
	_ , args :=  stub.GetFunctionAndParameters()
	b, _ := json.Marshal(args[0])
	_ = stub.PutState("channel_name", b)
	return shim.Success(nil)
}

func (t *PolicyChaincode) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	// 获取用户意图
	req, args := stub.GetFunctionAndParameters()

	if req == "AddPolicy" {
		return t.AddPolicy(stub, args) // 添加信息
	} else if req == "DelPolicy" {
		return t.DelPolicy(stub, args) // 删除信息
	} else if req == "UpdatePolicy" {
		return t.UpdatePolicy(stub, args)
	}else if req == "QueryPolicy" {
		return t.QueryPolicy(stub, args)
	}
	return shim.Error("指定的函数名称错误")
}

func main() {
	err := shim.Start(new(PolicyChaincode))
	if err != nil {
		fmt.Printf("starting chaincode go wrong: %s", err)
	}
}

type Policy struct {
	Obj		string			  `json:"obj"`		  // target data
	Sub		map[string][]string `json:"role"`		 // role and user group
	Opt		string			  `json:"opt"`		  // query, add, delete, update
	Vernumber  int				 `json:"vernumber"`	// policy version
	Iden	   string			  `json:"Iden"`		 // key
	PolHistory map[string][]int	`json:"user_history"` //  [user]{vernumber1, vernumber2}
}

func PutPolicy(stub shim.ChaincodeStubInterface, pol Policy) bool {
	//将策略信息序列化
	b, err := json.Marshal(pol)
	if err != nil {
		return false
	}

	// 保存策略信息
	err = stub.PutState(pol.Iden, b)
	if err != nil {
		return false
	}

	return true
}

func GetPolicy(stub shim.ChaincodeStubInterface, Iden string) (Policy, bool) {
	var pol Policy
	//调取策略信息
	b, err := stub.GetState(Iden)
	if err != nil {
		return pol, false
	}
	if b == nil {
		return pol, false
	}

	// 对查询到的状态进行反序列化
	err = json.Unmarshal(b, &pol)
	if err != nil {
		return pol, false
	}
	return pol, true
}

func CheckUser(stub shim.ChaincodeStubInterface) string {
	creatorByte, _ := stub.GetCreator()
	certStart := bytes.IndexAny(creatorByte, "-----")
	if certStart == -1 {
		return "false"
	}
	certText := creatorByte[certStart:]
	bl, _ := pem.Decode(certText)
	if bl == nil {
		return "false"
	}
	fmt.Println(string(certText))
	cert, err := x509.ParseCertificate(bl.Bytes)
	if err != nil {
		return "false"
	}
	username := cert.Subject.CommonName
	b, _ := stub.GetState("channel_name")
	var channelname string
	_ = json.Unmarshal(b, &channelname)
	Arg:=[][]byte{[]byte("CheckAdmin"),[]byte(username)}
	respond := stub.InvokeChaincode("CheckUser", Arg , channelname)
	var result string
	_ = json.Unmarshal(respond.Payload, &result)
	fmt.Println("the result is :", result)
	return result
}

func (t *PolicyChaincode) AddPolicy(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) <4 {
		return shim.Error("args_number is wrong")
	}
	resultbool1 := CheckUser(stub)
	if resultbool1 != "true" {
		return shim.Error("User masage is wrong")
	}

	var pol Policy
	pol.Obj = args[0]
	pol.Opt = args[1]
	pol.Sub = make(map[string][]string)
	pol.PolHistory = make(map[string][]int)
	if len(args) >= 4 {
		for i := 3; i < len(args); i++ {
			pol.Sub[args[2]] = append(pol.Sub[args[2]], args[i])
			pol.PolHistory[args[i]] = []int{1}
		} //策略权限生成只允许授予一个角色，添加角色需要upgradepolicy
	}else {
		pol.Sub[args[2]] = []string{ }
	}

	pol.Vernumber = 1
	pol.Iden = pol.Obj + pol.Opt

	// 查重: 避免重复权限信息
	_, exist := GetPolicy(stub, pol.Iden)
	if exist {
		return shim.Error("Privilege already exists")
	}
	 
	bl := PutPolicy(stub, pol)
	if !bl {
		return shim.Error("Saving privilege go wrong")
	}
	
	args1 := []string{"AddPolicy"}
	for i, _:= range args {
		args1 = append(args1, args[i])
	}
	args_req, _:=json.Marshal(args1)
	return shim.Success([]byte(args_req))
}

func (t *PolicyChaincode) DelPolicy(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 2 {
		return shim.Error("args' number is wrong")
	}
	resultbool1 := CheckUser(stub)
	if resultbool1 != "true"{
		return shim.Error("User masage is wrong")
	}

	var pol Policy
	QueryString := args[0] + args[1]
	pol, bl := GetPolicy(stub, QueryString)
	if !bl {
		return shim.Error("Getting policy go wrong")
	}
	if pol.Iden != QueryString {
		return shim.Error("Cannot get specified policy")
	}

	pol.Vernumber = -1
	err := PutPolicy(stub, pol)
	if !err {
		return shim.Error("Saving privilege go wrong")
	}

	args2 := []string{"DelPolicy", args[0], args[1]}
	args_req, _:=json.Marshal(args2)
	return shim.Success([]byte(args_req))
}

//更新链码，updatefunc= {addrole, deleterole, adduser, deleteuser}
//args： obj，opt，updata, sub
func (t *PolicyChaincode) UpdatePolicy(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) < 3 {
		return shim.Error("need more args")
	}
	resultbool1 := CheckUser(stub)
	if resultbool1 != "true" {
		return shim.Error("User masage is wrong")
	}

	QueryString := args[0] + args[1]
	pol, bl := GetPolicy(stub, QueryString)
	if !bl {
		return shim.Error("Getting policy go wrong")
	}
	if pol.Iden != QueryString {
		return shim.Error("Cannot get specified policy")
	}
	
	pol.Vernumber += 1
	if args[2] == "addrole" {
			pol.Sub[args[3]] = []string{ }
		for i := 4; i < len(args); i++ {
			pol.Sub[args[3]] = append(pol.Sub[args[3]], args[i])
			pol.PolHistory[args[i]] = append(pol.PolHistory[args[i]], pol.Vernumber)
		}
	}else if args[2] == "deleterole" {
		for j := 0; j < len(pol.Sub[args[3]]); j++{
			pol.PolHistory[pol.Sub[args[3]][j]] = append(pol.PolHistory[pol.Sub[args[3]][j]], -pol.Vernumber)
		}
		delete(pol.Sub, args[3])
	}else if args[2] == "adduser" {
				for i := 4; i < len(args); i++ {
			pol.Sub[args[3]] = append(pol.Sub[args[3]], args[i])
			pol.PolHistory[args[i]] = append(pol.PolHistory[args[i]], pol.Vernumber)
		}
	}else if args[2] == "deleteuser" {
		for i := 4; i < len(args); i++ {
			for j := 0; j < len(pol.Sub[args[3]]); j++ {
				if pol.Sub[args[3]][j] == args[i] {
					pol.PolHistory[args[i]] = append(pol.PolHistory[args[i]], -pol.Vernumber)
					pol.Sub[args[3]] = append(pol.Sub[args[3]][:j], pol.Sub[args[3]][j+1:]...)
					}
			}
		}
	}

	err := PutPolicy(stub, pol)
	if !err {
		return shim.Error("Saving the old privilege go wrong")
	}

	args1 := []string{"UpdatePolicy"}
	for i, _:= range args {
		args1 = append(args1, args[i])
	}
	args_req, _:=json.Marshal(args1)
	return shim.Success([]byte(args_req))
}

func (t *PolicyChaincode) QueryPolicy(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	QueryString := args[0] + args[1]
	pol, bl := GetPolicy(stub, QueryString)
	if !bl {
		return shim.Error("Getting policy go wrong")
	}
	if pol.Iden != QueryString {
		return shim.Error("Cannot get specified policy")
	}

	args_req, _:=json.Marshal(pol)
	return shim.Success([]byte(args_req))
}
