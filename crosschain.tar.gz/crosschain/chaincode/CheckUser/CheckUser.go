package main

import (
	"bytes"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"crypto/x509/pkix"
	"fmt"
	"math/big"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

type  CheckUser interface{

}

type CheckChaincode struct {
}

type CRL_List struct {
	CRL_SerislNumberList []*big.Int
	CRL_CertificateList  []pkix.RevokedCertificate
	CRL_Iden			 string
}

func (t *CheckChaincode) Init(stub shim.ChaincodeStubInterface) peer.Response {
	_ , args :=  stub.GetFunctionAndParameters()
	Admin_map := make(map[string][]string)
	Admin_map["Admin"] = []string{args[0]}
	b, _ := json.Marshal(Admin_map)
	_ = stub.PutState("Admin", b)
	return shim.Success(nil)
}

func (t *CheckChaincode) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	function, args := stub.GetFunctionAndParameters()
	fmt.Println("invoke is running " + function)

	if function == "CheckCertificate" {
		return t.CheckCertificate(stub, args)
	} else if function == "UpdateCRL" {
		return t.UpdateCRL(stub, args)
	}else if function == "UpdateAdmin" {
		return t.UpdateAdmin(stub, args)
	}else if function == "CheckAdmin" {
		return t.CheckAdmin(stub, args)
	}

	fmt.Println("invoke did not find func: " + function)
	return shim.Error("Received unknown function invocation")
}

func main() {
	err := shim.Start(new(CheckChaincode))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode: %s", err)
	}
}

func PutCRL(stub shim.ChaincodeStubInterface, crl_list CRL_List) bool {
	//将策略信息序列化
	b, err := json.Marshal(crl_list)
	if err != nil {
		return false
	}

	// 保存策略信息
	err = stub.PutState(crl_list.CRL_Iden, b)
	if err != nil {
		return false
	}
	return true
}

func GetUser(stub shim.ChaincodeStubInterface) string {
	creatorByte, _ := stub.GetCreator()
	certStart := bytes.IndexAny(creatorByte, "-----")
	if certStart == -1 {
		return "false"
	}
	certText := creatorByte[certStart:]
	bl, _ := pem.Decode(certText)
	if bl == nil {
		return "false"
	}
	fmt.Println(string(certText))
	cert, err := x509.ParseCertificate(bl.Bytes)
	if err != nil {
		return "false"
	}
	username := cert.Subject.CommonName
	return username
}

func GetCRL(stub shim.ChaincodeStubInterface, Iden string) (CRL_List, bool) {
	var crl_list CRL_List

	b, err := stub.GetState(Iden)
	if err != nil {
		return crl_list, false
	}
	if b == nil {
		crl_list.CRL_Iden = "CRL"
		return crl_list, true
	}

	err = json.Unmarshal(b, &crl_list)
	return crl_list, true
}

func (t *CheckChaincode) UpdateCRL(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	crl_base64 := args[0]
	crl_pem, err := base64.StdEncoding.DecodeString(crl_base64)
	if err != nil {
		fmt.Println("error:", err)
	}
	fmt.Printf("%q\n", crl_pem)
	bl, _ := pem.Decode(crl_pem)
	if bl == nil {
		fmt.Errorf("Could not decode the PEM structure")
	}
	fmt.Println(string(crl_pem))
	crl_cert, err := x509.ParseCRL(bl.Bytes)
	if err != nil {
		fmt.Errorf("ParseCertificate failed")
	}

	crl_now, bool1 := GetCRL(stub, "CRL")
	if !bool1 {
		return shim.Error("getcrl")
	}
	fmt.Printf("serial number len is %d\n",len(crl_now.CRL_SerislNumberList))
	fmt.Printf("parsed crl cert len is %d\n", len(crl_cert.TBSCertList.RevokedCertificates))
	var flag int
	for _, value := range crl_cert.TBSCertList.RevokedCertificates {
		for i := 0; i < len(crl_now.CRL_SerislNumberList); i++ {
			if value.SerialNumber == crl_now.CRL_SerislNumberList[i] {				
				flag = 1
			}
		}
		if flag == 0 {
			fmt.Println(value.SerialNumber.String())
			crl_now.CRL_SerislNumberList = append(crl_now.CRL_SerislNumberList, value.SerialNumber)
			crl_now.CRL_CertificateList = append(crl_now.CRL_CertificateList, value)
		}
	}
	crl_now.CRL_Iden = "CRL"
	bool2 := PutCRL(stub, crl_now)
	if !bool2 {
		return shim.Error("putcrl")
	}
	bbb, _ := json.Marshal(crl_now)
	return shim.Success([]byte(bbb))
}

func (t *CheckChaincode) CheckCertificate(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	cert_pem := args[0]
	bl, _ := pem.Decode([]byte(cert_pem))
	if bl == nil {
		fmt.Errorf("cert_pem")
	}
	fmt.Println(string(cert_pem))
	cert, err := x509.ParseCertificate(bl.Bytes)
	if err != nil {
		fmt.Errorf("ParseCertificate failed")
	}
	crl_now, _ := GetCRL(stub, "CRL")
	fmt.Println(crl_now)
	fmt.Println(cert.SerialNumber)
	for _, value := range crl_now.CRL_SerislNumberList {
		if cert.SerialNumber == value {
			return shim.Success([]byte("false"))
		}
	}
	return shim.Success([]byte("true"))
}

func (t *CheckChaincode) UpdateAdmin(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	Admin_map := make(map[string][]string)
	username := GetUser(stub)
	b, _ := stub.GetState("Admin")
	_ = json.Unmarshal(b, &Admin_map)

	flag := 0
	for _, admin := range Admin_map["Admin"] {
		if admin == username {
			flag = 1
		}
	}
	if flag == 0 {
		return shim.Error("please use admin role")
	}
	for _, arg := range args {
		Admin_map["Admin"] = append(Admin_map["Admin"], arg)
	}
	c, _ := json.Marshal(Admin_map)
	_ = stub.PutState("Admin", c)
	return shim.Success([]byte("success in updating admin_map"))
}

func (t *CheckChaincode) CheckAdmin(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	Admin_map := make(map[string][]string)
	b, _ := stub.GetState("Admin")
	_ = json.Unmarshal(b, &Admin_map)

	flag := 0
	for _, admin := range Admin_map["Admin"] {
		if args[0] == admin {
			flag = 1
		}
	}
	if flag == 0 {
		return shim.Error("false")
	}
	fmt.Println(flag)
	result, _ := json.Marshal("true")
	return shim.Success([]byte(result))
}
