export ordererAdminCert="tx2_network/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/signcerts/*.pem)
export ordererAdminPriv="tx2_network/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/keystore/*sk)
export org3AdminCert="tx2_network/"$(ls crypto-config/peerOrganizations/org3.example.com/users/Admin@org3.example.com/msp/signcerts/*.pem)
export org3AdminPriv="tx2_network/"$(ls crypto-config/peerOrganizations/org3.example.com/users/Admin@org3.example.com/msp/keystore/*sk)
export org3User1Cert="tx2_network/"$(ls crypto-config/peerOrganizations/org3.example.com/users/User1@org3.example.com/msp/signcerts/*.pem)
export org3User1Priv="tx2_network/"$(ls crypto-config/peerOrganizations/org3.example.com/users/User1@org3.example.com/msp/keystore/*sk)

export ordererTlsCACert="tx2_network/"$(ls crypto-config/ordererOrganizations/example.com/tlsca/*.pem)
export peer0org3TlsCACert="tx2_network/"$(ls crypto-config/peerOrganizations/org3.example.com/peers/peer0.org3.example.com/msp/tlscacerts/*.pem)

export caorg3TlsCACert="tx2_network/"$(ls crypto-config/peerOrganizations/org3.example.com/ca/*pem)
echo $caorg1TlsCACert


sed -e "s|\${ordererAdminCert}|$ordererAdminCert|g" \
-e "s|\${ordererAdminPriv}|$ordererAdminPriv|g" \
-e "s|\${org3AdminCert}|$org3AdminCert|g" \
-e "s|\${org3AdminPriv}|$org3AdminPriv|g" \
-e "s|\${org3User1Cert}|$org3User1Cert|g" \
-e "s|\${org3User1Priv}|$org3User1Priv|g" \
-e "s|\${ordererTlsCACert}|$ordererTlsCACert|g" \
-e "s|\${peer0org3TlsCACert}|$peer0org3TlsCACert|g" \
-e "s|\${caorg3TlsCACert}|$caorg3TlsCACert|g" \
	network.json.bak >  network.json
