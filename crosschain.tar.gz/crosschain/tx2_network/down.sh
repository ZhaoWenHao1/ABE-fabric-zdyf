rm ../tmp -rf
docker rm $(docker stop $(docker ps -a | grep hyperledger/fabric* | awk '{print $1}') )
docker network prune
docker volume prune
docker rmi $(docker images | grep dev-* | awk '{print $3}')
rm crypto-config -rf
rm channel-artifacts/* -rf
rm /tmp/hfc-kvs/* -rf
