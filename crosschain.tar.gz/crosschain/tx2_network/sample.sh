export SYS_CHANNEL='tx2-channel'
IMAGETAG=1.4
cryptogen generate --config=./crypto-config.yaml
configtxgen -profile OrgsOrdererGenesis -channelID ${SYS_CHANNEL} -outputBlock ./channel-artifacts/genesis.block

export BYFN_CA3_PRIVATE_KEY=$(cd crypto-config/peerOrganizations/org3.example.com/ca && ls *_sk)

IMAGE_TAG=$IMAGETAG


docker-compose -f docker-compose-cli.yaml  -f docker-compose-couch.yaml up -d
. ./test.sh

