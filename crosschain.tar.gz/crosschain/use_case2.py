import asyncio
from hfc.fabric import Client
import os 
import json
from new_type_cross import listener, user_confirm_handler
import sys
import time
loop = asyncio.get_event_loop()

cli = Client(net_profile="testnetwork/network.json")

org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
org3_user = cli.get_user(org_name='org3.example.com', name='User1')
org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org2_user = cli.get_user(org_name='org2.example.com', name='User1')
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org5_user = cli.get_user(org_name='org5.example.com', name='User1')
org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
cli.new_channel('channel1')
cli.new_channel('centre')
cli.new_channel('channel2')

dst_sync_fcn = "dstSyncRecord"
src_sync_fcn = "srcSyncRecord"
inner_trace_backward_fcn = "traceBackward"
inner_trace_forward_fcn = "traceForward"
cross_trace_forward_fcn = ""

def cross_access(cli, requestor, **kwargs):
		'''
		listen_peer
		invoke_peers
		fcn
		args
		cc_name
		src_channel
		'''
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		# print(result)
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "Confirm"+result['this_tx_id'], handle_times=1)
		pattern = "Cofirm"+result['this_tx_id']
		# print(f"listen pattern {pattern}")
		# print(f"listen at {next_block} block")
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])					
		
def trace_forward(cli, requestor, **kwargs):
		"dstchannel, tx_id"
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		tx_id = result['txid']
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "TFComplete"+tx_id, handle_times=1)
		pattern = "TFComplete"+tx_id
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])					

def chaincode_invoke(cli, requestor, **kwargs):
		"""
				channel:
				invoke_peers,
				fcn
				args,
				cc_name
		"""
		loop = asyncio.get_event_loop()
		response = loop.run_until_complete(
				cli.chaincode_invoke(
						requestor=requestor,
						channel_name=kwargs['channel'],
						peers=kwargs['invoke_peers'],
						fcn=kwargs['fcn'],
						args=kwargs['args'],
						cc_name=kwargs['cc_name'],
						wait_for_event=True
				)
		)
		return response

def chaincode_query(cli, requestor, **kwargs):
	loop = asyncio.get_event_loop()
	response = loop.run_until_complete(
		cli.chaincode_query(
			requestor = requestor,
			channel_name = kwargs['channel'],
			peers = kwargs['invoke_peers'],
			cc_name = kwargs['cc_name'],
			fcn = kwargs['fcn'],
			args=kwargs['args'],
		)
	)
	return response

# print 
print('channel1 上用户对 文件data1 进行追踪')
tx_id = ""
data_id = "data1"
target_id = []
while True:
		args = [data_id]
		if tx_id != "":
				args.append(tx_id)
		response = chaincode_query(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
								cc_name='record', fcn=inner_trace_forward_fcn,args=args)
		if response == "0":
				print("链内追踪结束")
				break
		else:
				print(f'当前追踪事务信息 {response}')
				payload = json.loads(response)
				if(payload['type_tx'] == 'pull' and payload['src_chain'] != 'channel1'):
						target_id.append([payload['this_tx_id'], payload['src_chain']])
				if(payload['type_tx'] == 'push' and payload['dst_chain'] != 'channel1'):
						target_id.append([payload['this_tx_id'], payload['dst_chain']])
				tx_id = payload['this_tx_id']
print('\n\n')
print('channel1 用户 对文件data1 进行溯源')
tx_id=""
while True:
		args = [data_id]
		if tx_id != "":
				args.append(tx_id)

		response = chaincode_query(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
								cc_name='record',fcn=inner_trace_backward_fcn,args=args)
		if response == "0":
				print("溯源结束")
				break
		else:
				print(f"当前溯源事务信息 {response}")
				payload = json.loads(response)
				tx_id = payload['this_tx_id']
				

data_id = "data1_copy"
tx_id=""
print('\n\n')
print('channel2 上用户对 文件副本data1_copy 进行追踪')
while True:
		args = [data_id]
		if tx_id != "":
				args.append(tx_id)
		response = chaincode_query(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
								cc_name='record', fcn=inner_trace_forward_fcn, args=args)
		if response == "0" :
				print("追踪结束")
				break
		else:
				print(f"当前追踪事务信息 {response}")
				payload = json.loads(response)
				tx_id = payload['this_tx_id']

tx_id = ""
print('\n\n')
print('channel2 用户 对文件data1_copy 进行溯源')
while True:
		args = [data_id]
		if tx_id != "":
				args.append(tx_id)

		response = chaincode_query(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
								cc_name='record', fcn=inner_trace_backward_fcn, args=args)
		if response == "0" :
				print("溯源结束")
				break
		else:
				print(f"当前溯源事务信息 {response}")
				payload = json.loads(response)
				tx_id = payload['this_tx_id']

print('\n\n')
print('channel1 用户对文件data1_copy 进行跨域追踪')
tx_id = ""
for op in target_id:
		print(op)

for args in  target_id:
		while True:
				response = trace_forward(cli, org2_admin, listen_peer=['peer0.org3.example.com'],invoke_peers=['peer0.org3.example.com'],
				fcn='crossTraceForward',cc_name='record', src_channel='channel1',
				args=args)
				payload = response
				if payload['src_chain'] == "":
						print("跨域追踪结束")
						break
				else:
						print(f"当前追踪事务信息 {response}")
						args[0] = payload['this_tx_id']
						args[1] = payload['src_chain']

						