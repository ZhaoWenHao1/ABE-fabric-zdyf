import deploy_tx1
import deploy_tx2
import deploy_centre
import multiprocessing
if __name__ == '__main__':
	deploy_tx1.init()
	deploy_tx2.init()
	deploy_centre.init()
