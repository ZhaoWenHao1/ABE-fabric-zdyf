export ordererAdminCert="tx1_network/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/signcerts/*.pem)
export ordererAdminPriv="tx1_network/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/keystore/*sk)
export org2AdminCert="tx1_network/"$(ls crypto-config/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp/signcerts/*.pem)
export org2AdminPriv="tx1_network/"$(ls crypto-config/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp/keystore/*sk)
export org2User1Cert="tx1_network/"$(ls crypto-config/peerOrganizations/org2.example.com/users/User1@org2.example.com/msp/signcerts/*.pem)
export org2User1Priv="tx1_network/"$(ls crypto-config/peerOrganizations/org2.example.com/users/User1@org2.example.com/msp/keystore/*sk)

export ordererTlsCACert="tx1_network/"$(ls crypto-config/ordererOrganizations/example.com/tlsca/*.pem)
export peer0org2TlsCACert="tx1_network/"$(ls crypto-config/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/msp/tlscacerts/*.pem)

export caorg2TlsCACert="tx1_network/"$(ls crypto-config/peerOrganizations/org2.example.com/ca/*pem)
echo $caorg1TlsCACert


sed -e "s|\${ordererAdminCert}|$ordererAdminCert|g" \
-e "s|\${ordererAdminPriv}|$ordererAdminPriv|g" \
-e "s|\${org2AdminCert}|$org2AdminCert|g" \
-e "s|\${org2AdminPriv}|$org2AdminPriv|g" \
-e "s|\${org2User1Cert}|$org2User1Cert|g" \
-e "s|\${org2User1Priv}|$org2User1Priv|g" \
-e "s|\${ordererTlsCACert}|$ordererTlsCACert|g" \
-e "s|\${peer0org2TlsCACert}|$peer0org2TlsCACert|g" \
-e "s|\${caorg2TlsCACert}|$caorg2TlsCACert|g" \
	network.json.bak >  network.json
