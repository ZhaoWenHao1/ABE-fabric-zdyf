import asyncio
from hfc.fabric import Client
import os 
import json
from new_type_cross import listener, user_confirm_handler
import sys
import time
loop = asyncio.get_event_loop()

cli = Client(net_profile="testnetwork/network.json")

org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
org3_user = cli.get_user(org_name='org3.example.com', name='User1')
org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org2_user = cli.get_user(org_name='org2.example.com', name='User1')
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org5_user = cli.get_user(org_name='org5.example.com', name='User1')
org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
cli.new_channel('channel1')
cli.new_channel('centre')
cli.new_channel('channel2')

dst_sync_fcn = "dstSyncRecord"
src_sync_fcn = "srcSyncRecord"

def cross_access(cli, requestor, **kwargs):
		'''
		listen_peer
		invoke_peers
		fcn
		args
		cc_name
		src_channel
		'''
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		# print(result)
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "Confirm"+result['this_tx_id'], handle_times=1)
		pattern = "Cofirm"+result['this_tx_id']
		# print(f"listen pattern {pattern}")
		# print(f"listen at {next_block} block")
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])					
		
def trace_forward(cli, requestor, **kwargs):
		"dstchannel, tx_id"
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		tx_id = result['txid']
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "TFComplete"+tx_id, handle_times=1)
		pattern = "TFComplete"+tx_id
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])					

def chaincode_invoke(cli, requestor, **kwargs):
		"""
				channel:
				invoke_peers,
				fcn
				args,
				cc_name
		"""
		loop = asyncio.get_event_loop()
		response = loop.run_until_complete(
				cli.chaincode_invoke(
						requestor=requestor,
						channel_name=kwargs['channel'],
						peers=kwargs['invoke_peers'],
						fcn=kwargs['fcn'],
						args=kwargs['args'],
						cc_name=kwargs['cc_name'],
						wait_for_event=True
				)
		)
		return response


# 默认配置下org{X}_admin的用户名为 Admin@org{X}.example.com
# channel1上 检查org2_admin是否为管理员
response = chaincode_invoke(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
							fcn="CheckAdmin", cc_name='CheckUser', args=['Admin@org2.example.com'],wait_for_event=True)
print(response)
# channel1 管理员赋予用户（自身）创建文件权限
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org2.example.com'],
			   fcn = 'AddPolicy',
			   args=['channel1','add','role1','Admin@org2.example.com'],
			   cc_name='Policy',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   ))
print(response)

# channel1 上org2_admin 创建文件data2
response = chaincode_invoke(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
							fcn='chainAuditRecord', cc_name='record', args=['hashdata', 'channel1', 'Admin@org2.example.com',
							'data2','add'],wait_for_event=True)
print(response)

payload_add = json.loads(response)
# 二次上链同步更新信息
response = chaincode_invoke(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
							fcn='chainSyncRecord', cc_name='record' ,wait_for_event=True,
							args= [payload_add['hash_data'],payload_add['src_chain'],payload_add['user'],payload_add['data_id'],payload_add['type_tx'],payload_add['this_tx_id']],
						   )


# 未授权用户 org5_user 跨域拉取 channel1 上的 data2 文件
response = cross_access(cli, org5_user, listen_peer=['peer0.org5.example.com'], invoke_peers=['peer0.org5.example.com'],
				fcn='srcAuditRecord',cc_name='record',src_channel='channel2',
				args=['hashdata','channel2','User1@org5.example.com',"channel1","data2","pull"])
# 审核结果一定为False, 失败
assert(response['result'] != True)
print(response)
# 中心域管理员 授予org5user 对channel1上data2的共享权限
response = chaincode_invoke(cli, org1_admin, channel='centre', invoke_peers=['peer0.org1.example.com'],
							fcn='AddPolicy', args=['data2', 'share', 'role1', 'User1@org5.example.com'], cc_name='audit'
							,wait_for_event=True)
# 打印授权结果
print(response)

# 授权后 发起域 channel1 的org2_user将 channel1 上文件 data2 push 给目标域 channel2的用户User1@org5.example.com
response = cross_access(cli, org2_user, listen_peer=['peer0.org2.example.com'], invoke_peers=['peer0.org2.example.com'],
				fcn='srcAuditRecord',cc_name='record',src_channel='channel1',
				args=['hashdata','channel1','User1@org5.example.com',"channel2","data2","push"])
# # 授权后
assert(response['result'] == True)
print(response)
# 发起(channel1)第二次上链, 
tx_id = response['tx_id']
print(tx_id)
response = chaincode_invoke(cli, org2_user, channel='channel1', invoke_peers=['peer0.org2.example.com'], fcn=src_sync_fcn, cc_name='record', 
							args=['hashdata','channel1','User1@org5.example.com',"channel2","data2",
							"push" ,tx_id],wait_for_event=True)
print(response)
# 目标域(channel2)第二次上链：生成对应文件副本data2_copy
response = chaincode_invoke(cli, org5_user, channel='channel2', invoke_peers=['peer0.org5.example.com'], fcn=dst_sync_fcn, cc_name='record',
							args=['hashdata','channel2','User1@org5.example.com',"channel1","data2_copy","push", tx_id],wait_for_event=True)
print(response)


# 检查channel2 
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
				fcn='CheckAdmin', args=['Admin@org4.example.com'], cc_name='CheckUser')
print(response)
# channel2 grant org4_admin 's read privilege
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
				fcn='AddPolicy', args=['data2_copy','read','role1','Admin@org4.example.com'],cc_name='Policy')
print(response)
# 读取文件
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
						fcn='chainAuditRecord', args=['hashdata', 'channel2', 'Admin@org4.example.com', 'data2_copy','read'],
						cc_name='record')
print(response)
payload_read = json.loads(response)
# 二次上链
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
						fcn='chainSyncRecord', args=[payload_read['hash_data'],payload_read['src_chain'],payload_read['user'],payload_read['data_id'],payload_read['type_tx'],payload_read['this_tx_id']],
						cc_name='record')
print(response)



# 对之前跨域事务进行追踪，应当给出对data2_copy的下一次事务即读取文件
start = time.time()
trace_tx_id = tx_id
trace_channel = 'channel2'
response = trace_forward(cli, org3_admin, listen_peer=['peer0.org3.example.com'], invoke_peers=['peer0.org3.example.com'],
				fcn='crossTraceForward', cc_name='record', src_channel='channel1', 
				args=[trace_tx_id, trace_channel])
end = time.time()
print(f'Trace forward cost time {end-start} s')
print(response)