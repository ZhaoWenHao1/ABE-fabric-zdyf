import listener
import time
import asyncio
import json
from hfc.fabric import Client
import argparse
import sys
import time
tx_cc = 'record'
centre_cc = 'audit'

src_audit_event_pattern = "srcAuditEvent"
dst_audit_event_pattern = "dstAuditEvent"
centre_audit_event_pattern = "Judge"
cetnre_confirm_event_pattern = "Confirm"
src_trace_forward_pattern = "CrossTrace"
centre_trace_forward_pattern = "SrctoDes" # TODO : remind append tx_channel
centre_trace_forward_complete_pattern = "DesToSrc" #TODO: append tx_channel

centre_audit_fcn = "CrossChannelJudgement"
dst_audit_fcn = "dstAuditRecord"
centre_confirm_fcn = "Confirm"
src_confirm_fcn = "Confirm"
centre_query_fcn = "GetJudge"
centre_trace_forward_fcn = "SrcToDes"
centre_trace_forward_complete_fcn = "DesToSrc"
src_trace_forward_fcn = "crossTraceForward"
src_trace_forward_complete_fcn = "TFComplete"
inner_trace_forward_fcn = "traceForward"

class ProxyNode:
	"""
	2 Listener: tx_channel, centre_channel

	4 event_handler, 
	src_audit,
	centre_audit,
	dst_audit,
	centre_confirm,
	"""
	class src_audit_event_handler():
		"""
			get srcAuditEvent+self.tx_channel
		"""
		def __init__(self, **kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()

		def _json2judge_args(self,tx_info):
			return [tx_info['hash_data'],tx_info['src_chain'], tx_info['user'], tx_info['dst_chain'],
			tx_info['data_id'], tx_info['type_tx'], tx_info['this_tx_id'] ]

		def __call__(self,event_info):
			payload = json.loads(event_info['payload'])
			print(f"at src_audit {self.tx_channel} {self.peers}, recv src_audit {event_info}")
			response = self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.centre_channel,
					peers=self.peers,
					cc_name=centre_cc,
					fcn=centre_audit_fcn,
					args=self._json2judge_args(payload),
					wait_for_event=False,
				)
			)
			print(f"at {self.tx_channel} {self.peers}, recv chaincode {response}")
	
	class dst_audit_event_handler():
		"""
			get dstAuditEvent 
		"""
		def __init__(self, **kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		def _json2confirm_args(self, message):
			return [str(int(message['result'])), message['err_kinds'], 
					message['tx_id'], message['src_chain']]

		def __call__(self,event_info):
			payload = json.loads(event_info['payload'])
			print(f"at dst_audit_event_handler {self.tx_channel} {self.peers}, recv dst audit {event_info}")

			response = self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.centre_channel,
					peers=self.peers,
					cc_name=centre_cc,
					fcn=centre_confirm_fcn,
					args=self._json2confirm_args(payload),
					wait_for_event=False
				)
			)
	
	class centre_confirm_event_handler():
		"""
			pattern Confirm+tx_channel
			get Confirm+srcChannel
		"""
		def __init__(self,**kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		def _json2confirm_args(self, info):
			args = [str(int(info['result'])), info['err_kinds'], info['tx_id']]  
			# print(args)
			return args
		  
			
		def __call__(self,event_info):
			print(f"at centre_confirm {self.tx_channel}:{self.peers}, receive centre confirm from {event_info},")  
			
			payload = json.loads(event_info['payload'])
			
			print(f"payload is {payload}")
			response = self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.tx_channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=src_confirm_fcn,
					args=self._json2confirm_args(payload),
					wait_for_event=False
				)
			)
			print(f"at {self.tx_channel} {self.peers}, recv centre confirm {event_info}")
	
	class centre_audit_event_handler():
		"""
		handle Judge+tx_channel event...
		"""
		def __init__(self,**kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		
		def _json2dst_audit_args(self, tx_info):
			return [tx_info['upchain']['hash_data'], tx_info['upchain']['src_chain'], tx_info['upchain']['user'],
			tx_info['upchain']['dst_chain'], tx_info['upchain']['data_id'], tx_info['upchain']['type_op'],
			tx_info['upchain']['tx_id']]

		def __call__(self,event_info):			
			print(f"{self.tx_channel}:{self.peers}, receive central audit event{event_info},")			  
			payload = json.loads(event_info['payload'])
			tx_id = payload['tx_id']
			response = self.loop.run_until_complete(
				self.cli.chaincode_query(
					requestor=self.requestor,
					peers=self.peers,
					channel_name = self.centre_channel,
					cc_name = centre_cc,
					fcn=centre_query_fcn,
					args=[tx_id]
				)
			)
			print(f"at {self.tx_channel} {self.peers}, recv query's {event_info}")

			payload = json.loads(response)
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.tx_channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=dst_audit_fcn,
					args=self._json2dst_audit_args(payload),
					wait_for_event=False
				)
			)
			print(f"at {self.tx_channel} {self.peers}, recv response {event_info}")


	# handle src chain's cross trace forward events
	class src_tf_event_handler():
		# handle cross trace forward pattern
		def __init__(self,**kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		def _json2_centretf_args(self, tf_info):
			# TODO 
			tx_id = tf_info['txid'] # trace_fw_txid
			tx_id_tobe_trace = tf_info['this_tx_id']
			dst_chain = tf_info['dst_chain']
			# TODO remind please
			return [dst_chain, tx_id_tobe_trace,
					tx_id, self.tx_channel]
			
		def __call__(self, event_info):
			payload = json.loads(event_info['payload'])						
			# args = self._json2_centretf_args(payload)			
			response = self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.centre_channel,
					peers=self.peers,
					cc_name=centre_cc,
					fcn=centre_trace_forward_fcn,
					args=self._json2_centretf_args(payload),
					wait_for_event=False
				)
			)
	
	# handle centre's trace forward complete's events
	# eg. des 2 source
	class centre_tf_complete_handler():
		def __init__(self,**kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		
		def _json2_src_tf_complete_args(self, tx_info):
			m = tx_info['upchain']
			return [tx_info['trace_fw_tx_id'], m['hash_data'], m['src_chain'],
					m['user'], m['dst_chain'], m['data_id'], m['type_op'],
					m['tx_id'],"0"]

		def __call__(self, event_info):
			payload = json.loads(event_info['payload'])
			args = self._json2_src_tf_complete_args(payload)
			print(f"\nat centre tfcomplete payload is {payload}")
			response = self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.tx_channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=src_trace_forward_complete_fcn,
					args=args,
					wait_for_event=False,
				)
			)

	class centre_tf_handler():
		def __init__(self,**kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()

		def _json2_centre_tf_complete_args(self, src,tx_id, tx_info):
			
			pass

		def __call__(self, event_info):
			payload = json.loads(event_info['payload'])
			"""
			payload:
			src_channel
			tx_id,
			tf_tx_id,
			"""
			_ = payload[0]
			target_tx_id = payload[1]
			this_tx_id = payload[2]
			src_channel = payload[3]
			print(f"\n at centre tf payload is {payload}")
			# first query, find the data_id
			try:
				response = self.loop.run_until_complete(
						self.cli.chaincode_query(
						requestor=self.requestor,
						peers=self.peers,
						channel_name=self.tx_channel,
						cc_name=tx_cc,
						fcn='query',
						args=[target_tx_id,"2"],
					)
				)
				record = json.loads(response)
			# second call inner chain TraceForward...
				
				data_id = record['data_id']
				print(f"query data_id is!!!{data_id}")
				response = self.loop.run_until_complete(
					self.cli.chaincode_query(
						requestor=self.requestor,
						peers=self.peers,
						channel_name=self.tx_channel,
						cc_name=tx_cc,
						fcn=inner_trace_forward_fcn,
						args=[data_id, target_tx_id],
					)
				)				
				result = json.loads(response)
				print(f"query tx is {result}")
				if 'dst_chain' not in result:
					dst_chain = ''
				else:
					dst_chain = result['dst_chain']
				args = [result['hash_data'], result['src_chain'], result['user'],
						dst_chain, result['data_id'], result['type_tx'],
						result['this_tx_id'], src_channel, this_tx_id]
			except Exception:
				args = ["","","","","","","", src_channel, this_tx_id]
			# third invoke chaincode on centre's chain....
			print(f"args is {args}")
			response = self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.centre_channel,
					peers=self.peers,
					cc_name=centre_cc,
					fcn=centre_trace_forward_complete_fcn,
					args=args,
					wait_for_event=False,
				)
			)

	def __init__(self,**kwargs):
		"""
		tx_channel   name
		centre_channel name

		"""
		self.tx_channel = kwargs['tx_channel']
		self.centre_channel = kwargs['centre_channel']
		self.cli = kwargs['cli']
		self.peers = kwargs['peers']
		self.requestor = kwargs['requestor']
		self.tx_channel_listener = listener.ChannelListener(self.cli, self.tx_channel,
															self.peers, self.requestor)
		self.centre_channel_listener = listener.ChannelListener(self.cli, self.centre_channel,
															self.peers, self.requestor)
		self.tx_channel_listener.add_listen_handler(self.src_audit_event_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel), 
													src_audit_event_pattern)
		self.tx_channel_listener.add_listen_handler(self.dst_audit_event_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel), 
													dst_audit_event_pattern)
		self.centre_channel_listener.add_listen_handler(self.centre_audit_event_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel), 
														centre_audit_event_pattern+self.tx_channel)
		self.centre_channel_listener.add_listen_handler(self.centre_confirm_event_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel), 
														cetnre_confirm_event_pattern+self.tx_channel)
		self.tx_channel_listener.add_listen_handler(self.src_tf_event_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel),
														src_trace_forward_pattern)

		self.centre_channel_listener.add_listen_handler(self.centre_tf_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel),
														centre_trace_forward_pattern+self.tx_channel)
		self.centre_channel_listener.add_listen_handler(self.centre_tf_complete_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel),
														centre_trace_forward_complete_pattern+self.tx_channel)




	def _do_listen(self):
		is_handle = self.tx_channel_listener._do_listen()

		is_handle = is_handle or self.centre_channel_listener._do_listen()
		return is_handle
	def listen(self):
		while(True):
			
			is_handle = self._do_listen()
			if is_handle:
				time.sleep(0.01)
			else :
				time.sleep(1)


if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument('--user', type=str, help="user_name eg. Admin")
	parser.add_argument('--org', type=str, help="org_name eg. org2.example.com")
	parser.add_argument('--channel', type=str, help="channel eg. channel1")
	parser.add_argument('--peers', type=str, help="peers eg. peer0.org3.example.com")
	args = parser.parse_args(sys.argv[1:])	
	cli = Client(net_profile="testnetwork/network.json")
	centre_channel = 'centre'
	tx_channel = args.channel
	peers = args.peers
	org_name = args.org
	user_name = args.user
	requestor = cli.get_user(org_name=org_name, name=user_name)
	proxy_node = ProxyNode(
		tx_channel=tx_channel,
		centre_channel=centre_channel,
		cli=cli,
		peers=[peers],
		requestor=requestor,
	)
	cli.new_channel(centre_channel)
	cli.new_channel(tx_channel)
	proxy_node.listen()