import grpc
import record_pb2
import record_pb2_grpc as record_service
from hfc.fabric import Client 
import asyncio
import json
from concurrent import futures
from multiprocessing import Queue, Manager

class RecordService(record_service.callServicer):
	centre_channel = "centre"
	centre_cc = "audit"
	centre_cc_fcn = ""
	centre_peers = ['peer0.org1.example.com']
	

	def __init__(self, cli, requestor, peers):
		self.cli = cli
		self.requestor = requestor
		self.peers = peers
		self.cli.new_channel('centre')
		self.loop = asyncio.get_event_loop()
		self.lock = multiprocessing.Manager().Lock()
 
	def record(self, request_header, tx_info):
		self.loop.run_until_complete(self.cli.invoke_chaindoe(
			requestor=self.requestor,
			channel_name=self.centre_channel,
			peers=self.peers,
			cc_name=centre_cc,
			
		))

	def record_call(self, request, context):
		tx_info = request.info 


