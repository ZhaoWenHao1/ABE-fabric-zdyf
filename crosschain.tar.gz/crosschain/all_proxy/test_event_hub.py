from hfc.fabric import Client
import asyncio
import os
import json
from collections import namedtuple
# from utils.user import Management
import json
import pprint
import queue
import re
import sys
import multiprocessing
cli = Client(net_profile="testnetwork/network.json")
# org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
# org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
# org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
cli.new_channel('channel2')
cli.new_channel('channel1')
cli.new_channel('centre')

loop = asyncio.get_event_loop()

blocks = []

def onEvent(block):
	blocks.append(block)

events = []

class listenChaincdoeEvent:
	def __init__():
		pass

		


def onChaincodeEvent(cc_event, block_number, tx_id, tx_status):
	events.append(cc_event)


async def test_blockevent():
	user = org4_admin
	channel = cli.get_channel('channel2')
	peer_info = cli.get_peer('peer0.org4.example.com')
	channel_event_hub = channel.newChannelEventHub(peer_info, user)
	stream = channel_event_hub.connect(start=0, stop=100, filtered=False)
	
	channel_event_hub.registerBlockEvent(unregister=False, onEvent=onEvent)
	await asyncio.shield(stream)
	channel_event_hub.disconnect()
	# print(blocks)


async def test_cc_event(queue, flag):
	# if flag 
	user = org4_admin
	channel = cli.get_channel('channel2')
	peer_info = cli.get_peer('peer0.org4.example.com')
	channel_event_hub = channel.newChannelEventHub(peer_info, user)
	stream = channel_event_hub.connect(start=, stop=sys.maxsize, filtered=False)
	# print(type(stream))
	channel_event_hub.registerChaincodeEvent(ccid='record', pattern='.*', onEvent=onChaincodeEvent)
	await asyncio.shield(stream)
	channel_event_hub.disconnect()


loop.run_until_complete(test_cc_event())
for x in events:
	print(json.loads(x['payload']))

def listen_process(lock, queue):
	lock.acquire()
	cli = Client(net_profile="testnetwork/network.json")
	lock.release()
	# org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
	org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
	# org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
	org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
	# org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
	cli.new_channel('channel2')
	cli.new_channel('channel1')
	cli.new_channel('centre')

	loop = asyncio.get_event_loop()
	flag=  False
	while True:
		loop.run_until_comple(test_cc_event(queue, flag))
