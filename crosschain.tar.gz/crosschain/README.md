## 一个不断轮询区块链的简单跨链后台



#### 系统跑起来

1. 进入testnetwork子目录`cd testnetwork`，运行`./down.sh`,这个shell会关闭删除全部docker容器，慎用，清理干净环境

2. 运行`./sample.sh`，shell脚本会搭建起 两条事务链:

3. 返回主目录`cd .. `, 在有对应的python支持下，运行`python deploy_new.py`，会实际搭起三条链，部署相关链码，链码介绍之后完成介绍.....

| 链名	 | 组织成员	   |
| -------- | -------------- |
| centre(中心链) | org1,org2,org4 |
|  channel1  | org2, org3|
| channel2 | org4,org5 |

4. 运行轮询区块的后台，`./new_type_cross/1.sh`, `./new_type_cross/2.sh`，这将分别创建两个后台进程，轮询channel1，channel2中的区块，在监听到跨域事件是，将会调用已注册的handler进行相应处理。最后两个中端运行吧，因为一些debug输出会混乱。
5. 尝试运行简单测试样例 `python temp.py`会完成链内创建文件，跨链创建文件，跨链追踪的简单示例。
