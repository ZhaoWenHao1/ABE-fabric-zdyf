from hfc.fabric import Client
import asyncio
import os


loop = asyncio.get_event_loop()

cli = Client(net_profile="tx1_network/network.json")
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
def create_tx1():
	response = loop.run_until_complete(cli.channel_create(
			orderer='orderer1.example.com',
			channel_name='channel1',
			requestor=org2_admin,
			config_yaml='tx1_network/',
			channel_profile='Channel1'
			))
	print(response)
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org2.example.com',],
			   orderer='orderer1.example.com'
			   ))  
	print(response)			 


# CheckUser, Policy, channel_audit, record
def init_tx1():
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/CheckUser',
				cc_name='CheckUser',
				cc_version='v1.0'
				))
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/Policy',
				cc_name='Policy',
				cc_version='v1.0'
	))
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/channel_audit',
				cc_name='channel_audit',
				cc_version='v1.0'
				))
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
	))



	print(response)
	policy = {
		'identities': [
			{'role': {'name': 'member', 'mspId': 'Org2MSP'}},
		],
		'policy': {
			'1-of': [
				{'signed-by': 0},
			]
		}
	}
	response = loop.run_until_complete(cli.chaincode_instantiate(
				requestor=org2_admin,
				channel_name='channel1',
				peers=['peer0.org2.example.com'],
				cc_name='CheckUser',
				args=['Admin@org2.example.com'],
				cc_version='v1.0',
				cc_endorsement_policy=policy, 
				collections_config=None, # optional, for private data policy
				transient_map=None,
				wait_for_event=True
				))
	response = loop.run_until_complete(cli.chaincode_instantiate(
				requestor=org2_admin,
				channel_name='channel1',
				peers=['peer0.org2.example.com'],
				cc_name='Policy',
				args=['channel1'],
				cc_version='v1.0',
				cc_endorsement_policy=policy, 
				collections_config=None, # optional, for private data policy
				transient_map=None,
				wait_for_event=True
				))
	response = loop.run_until_complete(cli.chaincode_instantiate(
				requestor=org2_admin,
				channel_name='channel1',
				peers=['peer0.org2.example.com'],
				cc_name='channel_audit',
				args=None,
				cc_version='v1.0',
				cc_endorsement_policy=policy, 
				collections_config=None, # optional, for private data policy
				transient_map=None,
				wait_for_event=True
				))
	response = loop.run_until_complete(cli.chaincode_instantiate(
				requestor=org2_admin,
				channel_name='channel1',
				peers=['peer0.org2.example.com'],
				cc_name='record',
				args=None,
				cc_version='v1.0',
				cc_endorsement_policy=policy, 
				collections_config=None, # optional, for private data policy
				transient_map=None,
				wait_for_event=True
				))
	loop.run_until_complete(cli.chaincode_invoke(
		requestor=org2_admin,
		channel_name='channel1',
		peers=['peer0.org2.example.com'],
		fcn='AddPolicy',
		args=['channel1', 'add', 'role1', 'Admin@org2.example.com', 'User1@org2.example.com'],
		cc_name='Policy',
		transient_map=None,
		wait_for_event=True,
	))	
	# print(response)

def init():
	create_tx1()
	init_tx1()

if __name__ == '__main__':
	init()