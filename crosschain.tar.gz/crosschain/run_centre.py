from hfc.fabric import Client
import asyncio
import os

loop = asyncio.get_event_loop()

cli = Client(net_profile="centre_network/network.json")
cli.new_channel('centre')
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')

def test_run():
	response =  loop.run_until_complete(cli.chaincode_invoke(
		requestor=org1_admin,
		channel_name='centre',
		peers=['peer0.org1.example.com'],
		fcn='AddPolicy',
		args=['data1','share','role1','User1@org1.example.com'],
		cc_name='audit'

	))
	print(response)

if __name__ == '__main__':
	test_run()