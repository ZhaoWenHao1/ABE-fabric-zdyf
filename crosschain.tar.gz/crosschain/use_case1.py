import asyncio
from hfc.fabric import Client
import os 
import json
from new_type_cross import listener, user_confirm_handler
import sys
import time
loop = asyncio.get_event_loop()

cli = Client(net_profile="testnetwork/network.json")

org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
org3_user = cli.get_user(org_name='org3.example.com', name='User1')
org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org2_user = cli.get_user(org_name='org2.example.com', name='User1')
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org5_user = cli.get_user(org_name='org5.example.com', name='User1')
org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
cli.new_channel('channel1')
cli.new_channel('centre')
cli.new_channel('channel2')

dst_sync_fcn = "dstSyncRecord"
src_sync_fcn = "srcSyncRecord"

def cross_access(cli, requestor, **kwargs):
		'''
		listen_peer
		invoke_peers
		fcn
		args
		cc_name
		src_channel
		'''
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		# print(result)
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "Confirm"+result['this_tx_id'], handle_times=1)
		pattern = "Cofirm"+result['this_tx_id']
		# print(f"listen pattern {pattern}")
		# print(f"listen at {next_block} block")
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])					
		
def trace_forward(cli, requestor, **kwargs):
		"dstchannel, tx_id"
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		tx_id = result['txid']
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "TFComplete"+tx_id, handle_times=1)
		pattern = "TFComplete"+tx_id
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])					

def chaincode_invoke(cli, requestor, **kwargs):
		"""
				channel:
				invoke_peers,
				fcn
				args,
				cc_name
		"""
		loop = asyncio.get_event_loop()
		response = loop.run_until_complete(
				cli.chaincode_invoke(
						requestor=requestor,
						channel_name=kwargs['channel'],
						peers=kwargs['invoke_peers'],
						fcn=kwargs['fcn'],
						args=kwargs['args'],
						cc_name=kwargs['cc_name'],
						wait_for_event=True
				)
		)
		return response



# channel1上 检查org2_admin是否为管理员
print("channel1上 检查org2_admin是否为管理员")
response = chaincode_invoke(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
							fcn="CheckAdmin", cc_name='CheckUser', args=['Admin@org2.example.com'],wait_for_event=True)

print(response)
# channel1 管理员赋予用户（自身）创建文件权限
print("channel1 管理员赋予用户 User1@org3.example.com 创建文件权限")
response = loop.run_until_complete(cli.chaincode_invoke(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org2.example.com'],
			   fcn = 'AddPolicy',
			   args=['channel1','add','role1','Admin@org2.example.com', 'User1@org3.example.com'],
			   cc_name='Policy',
			   transient_map=None, # optional, for private data
			   wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   ))
print(response)

print('\n')
# channel1 上org3_user 创建文件data1
print("授权用户org3_user 创建文件data1")
response = chaincode_invoke(cli, org3_user, channel='channel1', invoke_peers=['peer0.org3.example.com'],
							fcn='chainAuditRecord', cc_name='record', args=['hashdata', 'channel1', 'User1@org3.example.com',
							'data1','add'],wait_for_event=True)

payload_add = json.loads(response)
print(f"审核通过，生成事务信息{response}")
# 二次上链同步更新信息

print(f"第二次上链， 确保链上链下数据同步")
response = chaincode_invoke(cli, org3_user, channel='channel1', invoke_peers=['peer0.org3.example.com'],
							fcn='chainSyncRecord', cc_name='record' ,wait_for_event=True,
							args= [payload_add['hash_data'],payload_add['src_chain'],payload_add['user'],payload_add['data_id'],payload_add['type_tx'],payload_add['this_tx_id']],
						   )
print(f"第二次上链结果 {response}")						   
# 赋予读权限
print('\n')
print(f"赋予用户org3_user 对data1 文件读权限")
response = chaincode_invoke(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
							fcn='AddPolicy', args=['data1', 'read', 'role1', 'User1@org3.example.com'],
							cc_name='Policy')
print(f"授权结果 {response}")							
# 赋予写权限
print(f"赋予用户org3_user 对data1 文件写权限")
response = chaincode_invoke(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
							fcn='AddPolicy', args=['data1', 'write', 'role1', 'User1@org3.example.com'],
							cc_name='Policy')
print(f"授权结果 {response}")
print('\n')
print(f"授权用户 org3_user 对文件data1写入操作")
response = chaincode_invoke(cli, org3_user, channel='channel1', invoke_peers=['peer0.org3.example.com'],
							fcn='chainAuditRecord', cc_name='record', args=['hashdata2', 'channel1', 'User1@org3.example.com',
							'data1', 'write'], wait_for_event=True)
payload_write = json.loads(response)
print(f"审核通过， 生成事务信息{response}")
print(f"第二次上链， 确保链上链下数据同步")
response = chaincode_invoke(cli, org3_user, channel='channel1', invoke_peers=['peer0.org3.example.com'],
							fcn='chainSyncRecord', cc_name='record' ,wait_for_event=True,
							args= [payload_write['hash_data'],payload_write['src_chain'],payload_write['user'],payload_write['data_id'],payload_write['type_tx'],payload_write['this_tx_id']],
						   )
print(f"第二次上链结果 {response}")						   

print('')
print("channel2上的未授权用户 org5_usr 跨域拉取channel1 data1文件")

response = cross_access(cli, org5_user, listen_peer=['peer0.org5.example.com'], invoke_peers=['peer0.org5.example.com'],
				fcn='srcAuditRecord',cc_name='record',src_channel='channel2',
				args=['hashdata2','channel2','User1@org5.example.com',"channel1","data1","pull"])
assert(response['result'] != True)
print(f"审核失败 审核结果 {response}")
print('\n')
print(f"中心域 管理员赋予 org5_user 对文件data1的共享权限")
response = chaincode_invoke(cli, org1_admin, channel='centre', invoke_peers=['peer0.org1.example.com'],
							fcn='AddPolicy', args=['data1', 'share', 'role1', 'User1@org5.example.com'], cc_name='audit'
							,wait_for_event=True)
# 打印授权结果
print(response)
print('\n')
print(f"授权用户org5_user 跨域拉取channel1上的文件到channel2")
response = cross_access(cli, org5_user, listen_peer=['peer0.org5.example.com'], invoke_peers=['peer0.org5.example.com'],
				fcn='srcAuditRecord',cc_name='record',src_channel='channel2',
				args=['hashdata2','channel2','User1@org5.example.com',"channel1","data1","pull"])
assert(response['result'] == True)
print(f"审核通过 审核结果{response}")

# 目标域第二次上链
tx_id = response['tx_id']
print('目标链第二次上链')
response = chaincode_inchannel1	fcn=dst_sync_fcn, cc_name='record', args=['hashdata2','channel2','User1@org5.example.com',"channel1","data1","pull", tx_id])
print(f'目标链第二次上链结果 {response}')							

print('发起链第二次上链 链内生成data1文件副本data1_copy')
response = chaincode_invoke(cli, org5_user, channel='channel2', invoke_peers=['peer0.org5.example.com'],
							fcn=src_sync_fcn, cc_name='record',wait_for_event=True,
							args=['hashdata2','channel2','User1@org5.example.com',"channel1","data1_copy","pull", tx_id])
print(f'发起链第二次上链结果 {response}')
# channel2上用户赋予 对data1_copy 读取权限
print('\n')
print(f"channel2 管理员 Admin@org4.example.com 赋予用户org4Admin对data1_copy的读取权限")
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
				fcn='AddPolicy', args=['data1_copy','read','role1','Admin@org4.example.com'],cc_name='Policy')
print(response)
# channel2上用户赋予org5_user 对data1_copy 删除权限
print(f"channel2 管理员 Admin@org4.example.com 赋予用户org4Admin对data1_copy的读取权限")
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
				fcn='AddPolicy', args=['data1_copy','delete','role1','Admin@org4.example.com'],cc_name='Policy')
print('\n')
print(f"用户Admin@org4.example.com 读取文件 data1_copy")
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
						fcn='chainAuditRecord', args=['hashdata2', 'channel2', 'Admin@org4.example.com', 'data1_copy','read'],
						cc_name='record')
print(f"{response}")
payload_read = json.loads(response)
print(f"二次上链")
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
						fcn='chainSyncRecord', args=[payload_read['hash_data'],payload_read['src_chain'],payload_read['user'],payload_read['data_id'],payload_read['type_tx'],payload_read['this_tx_id']],
						cc_name='record')
print(f"{response}")
print('\n')
print(f"用户Admin@org4.example.com 删除文件 data1_copy")
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
						fcn='chainAuditRecord', args=['hashdata2', 'channel2', 'Admin@org4.example.com', 'data1_copy','delete'],
						cc_name='record')
print(f"{response}")
print(f"二次上链")
payload_delete = json.loads(response)
response = chaincode_invoke(cli, org4_admin, channel='channel2', invoke_peers=['peer0.org4.example.com'],
						fcn='chainSyncRecord', args=[payload_delete['hash_data'],payload_delete['src_chain'],payload_delete['user'],payload_delete['data_id'],payload_delete['type_tx'],payload_delete['this_tx_id']],
						cc_name='record')
print(f"{response}")
print('\n')