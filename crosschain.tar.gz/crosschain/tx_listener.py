from hfc.fabric import Client
import asyncio
import os
import json
from collections import namedtuple
# from utils.user import Management
import json
import pprint
import queue
import re
import sys
import multiprocessing
import argparse 
import time 

loop = asyncio.get_event_loop()
def onEvent(block):
	blocks.append(block)

events = []

class listenChaincdoeEvent:
	def __init__(self,):
		pass

		


def onChaincodeEvent(cc_event, block_number, tx_id, tx_status):
	print(cc_event)


async def test_blockevent():
	user = org4_admin
	channel = cli.get_channel('channel2')
	peer_info = cli.get_peer('peer0.org4.example.com')
	channel_event_hub = channel.newChannelEventHub(peer_info, user)
	stream = channel_event_hub.connect(start=0, stop=100, filtered=False)
	
	channel_event_hub.registerBlockEvent(unregister=False, onEvent=onEvent)
	await asyncio.shield(stream)
	channel_event_hub.disconnect()


def listen_cc_event(cli, requestor, peer_info, channel, start, stop):
	channel_event_hub = channel.newChannelEventHub(peer_info, requestor)
	stream = channel_event_hub.connect(start=start, stop=stop, filtered=False)
	channel_event_hub.registerChaincodeEvent(ccid='record', pattern='srcAudit', onEvent=onChaincodeEvent)
	loop.run_until_complete(asyncio.shield(stream))

async def test_cc_event(event_hub, start, stop):
	stream = event_hub.connect(start=start, stop=stop, filtered=False)
	event_hub.registerChaincodeEvent(ccid='record', pattern='srcAudit', onEvent=onChaincodeEvent)
	await asyncio.shield(stream)

if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('--user', type=str, help="user_name eg. Admin")
	parser.add_argument('--org', type=str, help="org_name eg. org2.example.com")
	parser.add_argument('--channel', type=str, help="channel eg. channel1")
	parser.add_argument('--peer', type=str, help="peer eg. peer0.org3.example.com")
	args = parser.parse_args(sys.argv[1:])	
	pattern = "srcAuditEvent"
	ccid = 'record'
	cli = Client(net_profile="tx1_network/network.json")
	cli.new_channel(args.channel)
	channel = cli.get_channel(args.channel)
	peer_info = cli.get_peer(args.peer)
	requestor = cli.get_user(org_name=args.org, name=args.user)	
	flag = False
	x = 0
	while True:
		stop=sys.maxsize
		if flag:
			start = 'last_seen'
		else:
			start = 0
		listen_cc_event(cli, requestor, peer_info, channel, start, stop)
		time.sleep(0.01)
		print(f"{x}")
		x += 1
		flag = True
