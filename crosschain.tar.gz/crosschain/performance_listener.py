import asyncio
from hfc.fabric import Client
import os 
import json
from new_type_cross import listener, user_confirm_handler, 
import sys
import time
loop = asyncio.get_event_loop()

cli = Client(net_profile="testnetwork/network.json")

org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
org3_user = cli.get_user(org_name='org3.example.com', name='User1')
org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org2_user = cli.get_user(org_name='org2.example.com', name='User1')
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org5_user = cli.get_user(org_name='org5.example.com', name='User1')
org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
cli.new_channel('channel1')
cli.new_channel('centre')
cli.new_channel('channel2')

dst_sync_fcn = "dstSyncRecord"
src_sync_fcn = "srcSyncRecord"
message_count = int(1e6)

handler = user_confirm_handler.numb_user_event_handler
tx_listener = listener.ChannelListener(cli, 'channel2', ['peer0.org4.example.com'], org4_admin, 0)
tx_listener.add_listen_handler(handler, "^chainAuditEvent*", handle_times=int(1e6))
start = time.time()
tx_listener.listen_until_complete()
end = time.time()

print(f"{int(1e6)} transaction cost {end - start}s")