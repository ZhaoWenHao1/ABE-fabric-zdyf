from hfc.fabric import Client
import asyncio
import os


loop = asyncio.get_event_loop()

cli = Client(net_profile="centre_network/network.json")
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
def create_centre():
	response = loop.run_until_complete(cli.channel_create(
			orderer='orderer0.example.com',
			channel_name='centre',
			requestor=org1_admin,
			config_yaml='centre_network/',
			channel_profile='CentralChannel'
			))
	print(response)
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org1_admin,
			   channel_name='centre',
			   peers=['peer0.org1.example.com',],
			   orderer='orderer0.example.com'
			   ))  
	print(response)			 

def init_centre():
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org1_admin,
				peers=['peer0.org1.example.com',],
				cc_path='github.com/chaincode/audit',
				cc_name='audit',
				cc_version='v1.0'
				))
	print(response)
	policy = {
		'identities': [
			{'role': {'name': 'member', 'mspId': 'Org1MSP'}},
		],
		'policy': {
			'1-of': [
				{'signed-by': 0},
			]
		}
	}
	response = loop.run_until_complete(cli.chaincode_instantiate(
				requestor=org1_admin,
				channel_name='centre',
				peers=['peer0.org1.example.com'],
				cc_name='audit',
				args=None,
				cc_version='v1.0',
				cc_endorsement_policy=policy, 
				collections_config=None, # optional, for private data policy
				transient_map=None,
				wait_for_event=True
				))
	print(response)

def init():
	create_centre()
	init_centre()
	print('over')
if __name__ == '__main__':
	init()