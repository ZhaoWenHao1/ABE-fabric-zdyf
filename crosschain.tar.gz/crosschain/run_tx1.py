from hfc.fabric import Client
import asyncio
import os


loop = asyncio.get_event_loop()

cli = Client(net_profile="tx1_network/network.json")
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
cli.new_channel('channel1')
def chaincode_invoke(cli, requestor, **kwargs):
		"""
				channel:
				invoke_peers,
				fcn
				args,
				cc_name
		"""
		loop = asyncio.get_event_loop()
		response = loop.run_until_complete(
				cli.chaincode_invoke(
						requestor=requestor,
						channel_name=kwargs['channel'],
						peers=kwargs['invoke_peers'],
						fcn=kwargs['fcn'],
						args=kwargs['args'],
						cc_name=kwargs['cc_name'],
						wait_for_event=True
				)
		)
		return response



def test_run():
	# channel1上 检查org2_admin是否为管理员
	print("channel1上 检查org2_admin是否为管理员")
	response = chaincode_invoke(cli, org2_admin, channel='channel1', invoke_peers=['peer0.org2.example.com'],
								fcn="CheckAdmin", cc_name='CheckUser', args=['Admin@org2.example.com'],wait_for_event=True)

	print(response)
	# channel1 管理员赋予用户（自身）创建文件权限
	print("channel1 管理员赋予用户 User1@org2.example.com 创建文件权限")
	response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=org2_admin,
				channel_name='channel1',
				peers=['peer0.org2.example.com'],
				fcn = 'AddPolicy',
				args=['channel1','add','role1','Admin@org2.example.com', 'User1@org2.example.com'],
				cc_name='Policy',
				transient_map=None, # optional, for private data
				wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
				#cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
				))
	print(response)



		response = loop.run_until_complete(cli.chaincode_invoke(
								requestor=org2_admin,
								channel_name='channel1',
								peers=['peer0.org2.example.com'],
								fcn = 'srcAuditRecord',
								args=['hashdata2','channel2','User1@org5.example.com',"channel1","data1","pull"],
								cc_name='record',
								transient_map=None, wait_for_event=True
		))
	print('\n')
	

if __name__ == '__main__':
	test_run()