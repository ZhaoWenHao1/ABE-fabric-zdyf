export ordererAdminCert="centre_network/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/signcerts/*.pem)
export ordererAdminPriv="centre_network/"$(ls crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/keystore/*sk)
export org1AdminCert="centre_network/"$(ls crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/*.pem)
export org1AdminPriv="centre_network/"$(ls crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore/*sk)
export org1User1Cert="centre_network/"$(ls crypto-config/peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/signcerts/*.pem)
export org1User1Priv="centre_network/"$(ls crypto-config/peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/keystore/*sk)

export ordererTlsCACert="centre_network/"$(ls crypto-config/ordererOrganizations/example.com/tlsca/*.pem)
export peer0org1TlsCACert="centre_network/"$(ls crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/msp/tlscacerts/*.pem)

export caorg1TlsCACert="centre_network/"$(ls crypto-config/peerOrganizations/org1.example.com/ca/*pem)
echo $ordererTlsCACert


sed -e "s|\${ordererAdminCert}|$ordererAdminCert|g" \
-e "s|\${ordererAdminPriv}|$ordererAdminPriv|g" \
-e "s|\${org1AdminCert}|$org1AdminCert|g" \
-e "s|\${org1AdminPriv}|$org1AdminPriv|g" \
-e "s|\${org1User1Cert}|$org1User1Cert|g" \
-e "s|\${org1User1Priv}|$org1User1Priv|g" \
-e "s|\${ordererTlsCACert}|$ordererTlsCACert|g" \
-e "s|\${peer0org1TlsCACert}|$peer0org1TlsCACert|g" \
-e "s|\${caorg1TlsCACert}|$caorg1TlsCACert|g" \
	network.json.bak >  network.json
