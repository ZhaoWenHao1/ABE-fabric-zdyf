from hfc.fabric import Client
import asyncio
import os


loop = asyncio.get_event_loop()

cli = Client(net_profile="tx2_network/network.json")
org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
cli.new_channel('channel2')
def chaincode_invoke(cli, requestor, **kwargs):
		"""
				channel:
				invoke_peers,
				fcn
				args,
				cc_name
		"""
		loop = asyncio.get_event_loop()
		response = loop.run_until_complete(
				cli.chaincode_invoke(
						requestor=requestor,
						channel_name=kwargs['channel'],
						peers=kwargs['invoke_peers'],
						fcn=kwargs['fcn'],
						args=kwargs['args'],
						cc_name=kwargs['cc_name'],
						wait_for_event=True
				)
		)
		return response


def test_run():
	# channel2上 检查org3_admin是否为管理员
	print("channel2上 检查org3_admin是否为管理员")
	response = chaincode_invoke(cli, org3_admin, channel='channel2', invoke_peers=['peer0.org3.example.com'],
								fcn="CheckAdmin", cc_name='CheckUser', args=['Admin@org3.example.com'],wait_for_event=True)

	print(response)
	# channel2 管理员赋予用户（自身）创建文件权限
	print("channel2 管理员赋予用户 User1@org3.example.com 创建文件权限")
	response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=org3_admin,
				channel_name='channel2',
				peers=['peer0.org3.example.com'],
				fcn = 'AddPolicy',
				args=['channel2','add','role1','Admin@org3.example.com', 'User1@org3.example.com'],
				cc_name='Policy',
				transient_map=None, # optional, for private data
				wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
				#cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
				))
	print(response)

	print('\n')
	

if __name__ == '__main__':
	test_run()