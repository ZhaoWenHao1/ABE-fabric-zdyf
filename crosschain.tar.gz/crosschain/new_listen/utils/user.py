from hfc.fabric_ca.caservice import ca_service
from hfc.fabric_network import wallet
import datetime
from hfc.fabric import Client
import asyncio


class Management(object):
	def init_casvc(self, url, cert):
		if cert == None:
			self.casvc=ca_service(target=url)
		else:
			self.casvc=ca_service(target=url, ca_certs_path=cert)
		self.certsvc = self.casvc.newCertificateService()
	
	def __init__(self, url="http://127.0.0.1:8054",admin="admin", adminpw="adminpw",cert=None):
		self.init_casvc(url,cert)
		# log in as admin...
		self.admin = self.casvc.enroll("admin","adminpw")
		self.wallet = wallet.FileSystenWallet()

	def create_user(self, user_name, org_name, msp):
		if not self.wallet.exists(user_name):
			user_secret = self.admin.register(user_name)
			user_enroll = self.casvc.enroll(user_name,user_secret)
			uesr_identity = wallet.Identity(user_name, user_enroll)
			uesr_identity.CreateIdentity(self.wallet)
		return self.wallet.create_user(user_name, org_name, msp)

	def revoke_user(self, user_name, reason="privilegewithdrawn",**kwargs):
		"""
		kwarg contain basic info to invoke chancode:
		cli, requesotr, channels, peers, cc_name, fcn, args,
		args is CRL
		"""


		loop = asyncio.get_event_loop()
		response = self.admin.revoke(user_name, gencrl=True, reason=reason)
		try:
			print(self.get_crl())		 
			response = loop.run_until_complete(kwargs['cli'].chaincode_invoke(
				requestor=kwargs['requestor'],
				channel_name=kwargs['channel_name'],
				peers=kwargs['peers'],
				cc_name=kwargs['cc_name'],
				fcn=kwargs['fcn'],
				args=[self.get_crl()],
				wait_for_event=True
			))
			print(response)
			return True
		except Exception as e:
			print(str(e))
			return False



	def get_certificate(self, id=None, aki=None, serial=None):
		revoked_before = datetime.datetime(2022,1,1).isoformat('T') + "Z"
		revoked_after = datetime.datetime(2020,1,1).isoformat('T') + "Z"
		expired_before = None
		expired_after = None
		# return self.certsvc.getCertificates(self.admin, id=user_id, aki=aki, serial=serial,
		# revoked_start=revoked_after, revoked_end=revoked_before, expired_start=expired_after, expired_end=expired_before)
		return self.certsvc.getCertificates(self.admin,id=id,aki=aki,serial=serial)

	def get_crl(self):
		revoked_before = None
		revoked_after = None
		expired_before = None
		expired_after = None
		return self.casvc.generateCRL(revoked_before, revoked_after,
									expired_before, expired_after, self.admin)