from collections import namedtuple
import json
from enum import Enum, unique
import enum
@unique
class ErrorCode(enum.IntEnum):
	#阶段成功
	OK = 0
	#遇上系统内部问题
	INNER_SYS_ERROR = 1
	#调用Judge链码失败
	JUDGE_FAIL = 2
	#找不到跨链必须的链上记录
	QUERY_FAIL = 3

error_details  = {
	ErrorCode.OK:"Success",
	ErrorCode.INNER_SYS_ERROR:"system inner error",
	ErrorCode.JUDGE_FAIL:"failed pass Priv check",
	ErrorCode.QUERY_FAIL:"failed get record on chain"
}
def Ok(errror_code):
	return errror_code == ErrorCode.OK
def err_detail(error_code):
	return error_details[error_code]

def bytes2json(data):
	return json.loads(data)

