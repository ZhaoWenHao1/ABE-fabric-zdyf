from kv import KV
import listener





class DBImpl(object):
	"""
	docstring
	"""
	def __init__(self, uri='db/kv.db'):
		self.db = KV(db_uri=uri)
	
	def set_data(self,  key, value):
		self.key=value
		
	def get_data(self, key):
		if key in self.db:
			return True, self.db[key]
		else :
			return False, "error"
		
	def del_data(self,  key):
		if key in self.db:
			del self.db[key]
			return True
		else:
			return False