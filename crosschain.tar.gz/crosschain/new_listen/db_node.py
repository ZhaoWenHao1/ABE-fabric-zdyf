from db import DBImpl
from listener import ChannelListener, EventHandler
import asyncio
import json
from multiprocessing import Manager, Pool
import time, random, os


db_inner_event_pattern = "^chainAuditEvent*"
db_cross_event_pattern = "^Confirm*"
inner_sync_fcn = "chainSyncRecord"
cross_src_sync_fcn = "srcSyncRecord"
cross_dst_sync_fcn = "dstSyncRecord"

tx_cc = 'record'

class DBNode():
	"""
		listener: 
		Handler:

		DBimplement
	"""
	class InnerEventHandler():
		def __init__(self,cli,channel,peers,requestor,db, queue):
			self.cli = cli
			self.channel = channel
			self.requestor = requestor
			self.peers = peers
			self.db = db
			self.loop = asyncio.get_event_loop()
			self.queue = queue
			# 
		def _inner_sync(self, **kwargs):		
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=inner_sync_fcn,
					args=kwargs['args'],
					wait_for_event=True,
				))

		def __call__(self, event_info):
			ev_name = event_info['event_name']
			message  = ev_name[ev_name.find('_')+1:]
			if "pass" != message:
				# inner chain audit failed, not pass...
				return			
			payload = json.loads(event_info['payload'])
			"""
			set queue, tx_info
			"""
			self.queue.set(payload)
			
	
	class CrossEventHandler():
		def __init__(self, cli, channel, peers, requestor, db, queue):
			self.cli = cli
			self.channel = channel
			self.requestor = requestor
			self.peers = peers
			self.loop = asyncio.get_event_loop()
			self.db = db
			self.queue = queue

		def __call__(self, event_info):
			ev_name = event_info['event_name']
			tx_id = ev_name[ev_name.find('Confirm')+len('Confirm'):]
			payload = json.loads(event_info['payload'])
			if payload['result'] != True:
				return
			else:
				print(f"tx:{tx_id}, pass, ready to cross access")
				resposne = self.loop.run_until_complete(self.cli.chaincode_query(
					requestor=self.requestor,
					peers=self.peers,
					channel_name=self.channel,
					cc_name=tx_cc,
					fcn='query',
					args=[tx_id,'1']
				))
				payload = json.loads(resposne)
				self.queue.set(payload)
		
		def _cross_src_sync(self, **kwargs):
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=cross_src_sync_fcn,
					args=kwargs['args'],
					wait_for_event=True,
				)
			)
		
		def _cross_dst_sync(self, **kwargs):
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=cross_dst_sync_fcn,
					args=kwargs['args'],
					wait_for_event=True
				)
			)


	class tcpserver:
		pass
	def __init__(self, cli, channel, peers, requestor,):
		self.db = DBImpl()
		self.cli = cli
		self.channel = channel
		self.requestor = requestor
		self.peers = peers
		self.tx_cc = tx_cc
		self.loop = asyncio.get_event_loop()
		# self.channel_listener = ChannelListener(self.cli, self.channel, self.peers,
		#										self.requestor, )
		# self.queue1 = Manager().Queue(maxsize=100)			 
		# self.queue2 = Manager().Queue(maxsize=100)						  
		# self.channel_listener.add_listen_handler(self.InnerEventHandler(self.cli, self.channel, self.peers, self.requestor,self.db,self.queue1),
		#										  event_pattern=db_inner_event_pattern)
		# self.channel_listener.add_listen_handler(self.CrossEventHandler(self.cli,self.channel,self.peers,self.requestor,self.db,self.queue2),
		#										  event_pattern=db_cross_event_pattern)
	def _inner_sync(self, **kwargs):		
		self.loop.run_until_complete(
			self.cli.chaincode_invoke(
				requestor=self.requestor,
				channel_name=self.channel,
				peers=self.peers,
				cc_name=tx_cc,
				fcn=inner_sync_fcn,
				args=kwargs['args'],
				wait_for_event=True,
			))
	def _cross_src_sync(self, **kwargs):
		self.loop.run_until_complete(
			self.cli.chaincode_invoke(
				requestor=self.requestor,
				channel_name=self.channel,
				peers=self.peers,
				cc_name=tx_cc,
				fcn=cross_src_sync_fcn,
				args=kwargs['args'],
				wait_for_event=True,
			)
		)
	
	def _cross_dst_sync(self, **kwargs):
		self.loop.run_until_complete(
			self.cli.chaincode_invoke(
				requestor=self.requestor,
				channel_name=self.channel,
				peers=self.peers,
				cc_name=tx_cc,
				fcn=cross_dst_sync_fcn,
				args=kwargs['args'],
				wait_for_event=True
			)
		)
