from hfc.fabric import Client
import asyncio
from collections import namedtuple
# from utils.user import Management
import json
import pprint
import queue
import re
import sys
import threading
import time
import grpc
import structs_pb2
import record_pb2 as record_struct
import record_pb2_grpc as record_service
import json
import multiprocessing as mp
import random
import os 
import logging
server_address = "127.0.0.1:10064"
cli = Client(net_profile="testnetwork/network.json")
# org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
# org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
# org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
cli.new_channel('channel2')
cli.new_channel('channel1')
cli.new_channel('centre')

loop = asyncio.get_event_loop()

blocks = []



def onEvent(block):
	blocks.append(block)

events = []

class listenChaincdoeEvent:
	def __init__():
		pass



		
class onChaincodeHandler:
	
	def __init__ (self, queue):
		# print('init')
		self.queue = queue
	def __call__(self, cc_event, block_number, tx_id, tx_status):
		# print(call)
		payload = json.loads(cc_event['payload'])
		print(f"read from block {block_number} ")
		# print(type(payload))
		queue.put(payload)
		# queue.put(payload)
		# request_header = random.randint(1, 1e8)
		# tx_info = structs_pb2.tx_info(hash_data='',src_chain='',
		# user='',dst_chain='',data_id=str(request_header),type_tx='',this_tx_id='',last_tx_id='')        
		# response =  self.stub.record_call(record_struct.request_info(
		# 	request_header=request_header,info=tx_info))
		# print(response)

		# queue.put(payload)




# def onChaincodeEvent(cc_event, block_number, tx_id, tx_status):
	# print(cc_event)
	# print(f"thread_id:{threading.get_ident()}")


# async def test_blockevent():	
# 	user = org4_admin
# 	channel = cli.get_channel('channel2')
# 	peer_info = cli.get_peer('peer0.org4.example.com')
# 	channel_event_hub = channel.newChannelEventHub(peer_info, user)
# 	stream = channel_event_hub.connect(start=0, stop=100, filtered=False)
# 	print(threading.get_ident() )
# 	channel_event_hub.registerBlockEvent(unr16
# 	channel_event_hub.disconnect()
	# print(blocks)


def test_cc_event(channel_event_hub, info, start):

	# channel_event_hub.disconnect()
	# print(m.height)
	# print(info.height)
	stream = channel_event_hub.connect(start=start, stop=info.height-1, filtered=False)
	# print(type(stream))
	loop.run_until_complete(asyncio.shield(stream))
	# await asyncio.wait(asyncio.shield(stream))


def listen_process(lock, queue):
	# print(123)
	lock.acquire()
	cli = Client(net_profile="testnetwork/network.json")
	# org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
	org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
	# org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
	org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
	# org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
	cli.new_channel('channel2')
	cli.new_channel('channel1')
	cli.new_channel('centre')
	lock.release()
	flag = True
	user = org2_admin
	channel = cli.get_channel('channel1')
	peers = ['peer0.org2.example.com']
	peer_info = cli.get_peer('peer0.org2.example.com')

	channel_event_hub = channel.newChannelEventHub(peer_info, user)
	handler = onChaincodeHandler(queue)
	# print(handler)
	channel_event_hub.registerChaincodeEvent(ccid='record', pattern='.*', onEvent=handler)
	print(cli)
	info = loop.run_until_complete(cli.query_info(user, 'channel1', ['peer0.org2.example.com']))
	test_cc_event(channel_event_hub, info, 0)
	while True:
		last_reach = info.height-1
		info = loop.run_until_complete(cli.query_info(user, 'channel1', ['peer0.org2.example.com']))
		if info.height - 1 == last_reach:
			time.sleep(1)
			continue
		test_cc_event(channel_event_hub, info, info.height-1)
		

def consume_process(queue):

	print("consume_process")
	channel = grpc.insecure_channel(target=server_address)       
	stub = record_service.callStub(channel)

	while True:
		payload = queue.get()
		request_header = random.randint(1, 1e8)
		tx_info = structs_pb2.tx_info(hash_data='',src_chain='',
		user='',dst_chain='',data_id=str(request_header),type_tx='',this_tx_id='',last_tx_id='')        
		response =  stub.record_call(record_struct.request_info(
			request_header=request_header,info=tx_info))

if __name__ == '__main__':
	lock = mp.Manager().Lock()
	queue = mp.Manager().Queue(100)
	pool = mp.Pool(10)
	# listen_process(lock,queue)
	# consume_process(queue)
	logger = mp.get_logger()
	logger.setLevel(logging.DEBUG)
	pool.apply_async(listen_process, (lock, queue))
	for i in range(9):
		pool.apply_async(consume_process, (queue,))
	pool.close()
	pool.join()

	# listen_process(lock, queue)
	# consume_process
	# m = loop.run_until_complete(cli.query_info(org2_admin, 'channel1', ['peer0.org2.example.com']))
	# print(m)
