import time
import grpc
import structs_pb2
import record_pb2 as record_struct
import record_pb2_grpc as record_service
import json
import multiprocessing as mp
import random
from concurrent import futures
import asyncio
import os 
import threading
from hfc.fabric import Client
import nest_asyncio
nest_asyncio.apply()
server_address = "[::]:10064"


# without record neither recovery, wait until complete version
class RecordServicer(record_service.callServicer):
    def __init__(self, lock, queue):
        print(f"{threading.get_ident()} init")
        self.lock = lock
        self.lock.acquire()
        self.cli = Client(net_profile='testnetwork/network.json')
        self.cli.new_channel('channel1')
        # self.loop = asyncio.get_event_loop()
        self.requestor = self.cli.get_user(org_name='org2.example.com', name='Admin')
        self.peers = ['peer0.org2.example.com']
        self.queue = queue
        self.lock.release()
        # self.loop_map = {}
        # self.loop_map[]
        # asyncio.new_event_loop()
        self.loop = asyncio.get_event_loop()
        

    def write_ledger(self, request):
        # self.lock.acquire()
        # self.lock.release()
        # self.loop.run_until_complete(asyncio.sleep(1))
        # print(f"thread id {futures.thread.threading.get_ident()}")
        # loop = asyncio.new_event_loop()
        # loop = self.loop
        # asyncio.set_event_loop(self.loop)
        # loop  = asyncio.get_event_loop()
        # asyncio.set_event_loop(loop)
        # print(loop)
        response = self.loop.run_until_complete(self.cli.chaincode_invoke(
                requestor=self.requestor,
                channel_name='channel1',
                peers=self.peers,
                fcn = 'chainAuditRecord',
                args=['hashdata', 'channel1', 'Admin@org2.example.com', request.info.data_id,'add'],
                cc_name='record',
                transient_map=None, # optional, for private data
                wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
        ))
        # print(response)
        # time.sleep(1)
        # loop = asyncio.get_event_loop()

        # self.queue.put(request)
        # time.sleep(1)
        # response = "ok"
        return response

    def record_call(self, request, context):
        try :
            # print(request)
            response = self.write_ledger(request)
        except Exception as e:
            print(str(e))
        return record_struct.response_info(error_code=0, content=response)


def serve():
    # server = grpc.server(mp.Pool(16))
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=40))
    lock = mp.Manager().Lock()
    queue = mp.Manager().Queue(1000)
    
    servicer = RecordServicer(lock, queue)
    record_service.add_callServicer_to_server(servicer, server)
    server.add_insecure_port('[::]:10064')
    server.start()
    print('start...')
    server.wait_for_termination()


if __name__ == '__main__':
    # lock = mp.Manager.Lock()
    # queue = mp.Manager().Queue(1000)
    # pool = mp.Pool(3)
    # pool.apply_async(serve)

    serve()