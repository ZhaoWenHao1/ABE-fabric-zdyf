import multiprocessing as mp
import os
import time


def write_queue(queue):
    i = 0
    print(123)
    while True:
        queue.put(i)
        time.sleep(0.5)
def read_queue(queue):
    while True:
        i = queue.get()
        print(i)
        time.sleep(0.5)


if __name__ == '__main__':
    queue = mp.Manager().Queue(10)
    pool = mp.Pool(4)
    queue.put(1234)
    pool.apply_async(write_queue, (queue,))
    
    pool.apply_async(read_queue, (queue,))
    pool.close()
    
    pool.join()