python new_type_cross/proxy_node.py --user Admin --org org4.example.com --channel channel2 --peers peer0.org4.example.com
