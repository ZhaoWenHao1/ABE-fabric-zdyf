from hfc.fabric import Client
import asyncio
import os
import json
from collections import namedtuple
# from utils.user import Management
import json
import pprint
import queue
import re
import json


def print_json(data):
    print(json.dumps(data, sort_keys=True, indent=4, separators=(', ', ': '), ensure_ascii=False))

loop = asyncio.get_event_loop()
def get_events(proposal_response):
	m = []
	status = True
	try:
		for x in proposal_response['data']['data']:
			try:
				m.append(x['payload']['data']['actions'][0]['payload']['action']['proposal_response_payload']['extension']['events'])
			except Exception as e:
				print("current don't have events")
			finally:
				pass
	except Exception as e:
		pass
	if len(m):
		return True, m
	else:
		return False, []



cli = Client(net_profile="testnetwork/network.json")
# org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
# org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
# org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
cli.new_channel('channel2')
cli.new_channel('channel1')
cli.new_channel('centre')
# ca_manage=Management()
# org2_user=ca_manage.create_user(user_name='user_ca',org_name='org2.example.com',msp="Org2MSP")
class MyEncoder(json.JSONEncoder):
 
    def default(self, obj):
        """
        只要检查到了是bytes类型的数据就把它转为str类型
        :param obj:
        :return:
        """
        if isinstance(obj, bytes):
            return str(obj, encoding='utf-8')
        return json.JSONEncoder.default(self, obj)

for i in range(14,16):
	response = loop.run_until_complete(cli.query_block(
				requestor=org4_admin,
				channel_name='channel2',
				peers=['peer0.org4.example.com'],
				block_number=str(i),
				decode=True
				))
	# print(response)
	# response = 
	print(response)
	# print(response)
# pprint.pprint(f"{response['data']}")
# m = print(response)
	# m = get_events(response)
	# print(m)


# 
# class EventHandler:
#	 def __init__(self, handle_function, event_pattern,handle_times = None,):
#		 self.handle_function = handle_function
#		 self.event_pattern = event_pattern
#		 if handle_times != None:
#			 self.handle_times = handle_times
#		 else:
#			 # means handler won't stop
#			 self.handle_times = -1
		
#	 def handle(self, event_info):
#		 print(self.event_pattern)
#		 print(event_info['event_name'])
#		 if self.handle_times != 0 and re.match(self.event_pattern, event_info['event_name']):
#			 # pattern match the event,
#			 if self.handle_times > 0:
#				 self.handle_times -= 1
#			 self.handle_function(event_info)

# class ChannelListener:
#	 queue_max_size = 100

#	 def __init__(self, cli, channel, peers, requestor,start_block=None):
#		 self.cli = cli
#		 self.listen_channel = channel
#		 self.peers = peers
#		 self.requestor = requestor
#		 self.loop = asyncio.get_event_loop()
#		 # self.queue = queue.Queue(max)
#		 if start_block == None:
#			 self.listen_block = 0
#		 else:
#			 self.listen_block = start_block
#		 self.call_back_handlers = []

#	 def add_listen_handler(self, function, event_pattern, handle_times=None):
#		 self.call_back_handlers.append(EventHandler(function, event_pattern, handle_times))


#	 def _do_listen(self,):
#		 # remove the finished listener
#		 self.call_back_handlers = list(filter(lambda handler: handler.handle_times != 0, 
#											   self.call_back_handlers))
#		 if not len(self.call_back_handlers):
#			 # all handlers' work finished
#			 return False
#		 status, events = self._get_event()
#		 if not status:
#			 return False
#		 for event in events:
#			 for handler in self.call_back_handlers:
#				 handler.handle(event)
#		 return True
						
#	 def _get_event(self):
#		 events = []
#		 status = False
#		 try:
#			 response = self.loop.run_until_complete(self.cli.query_block(
#					 requestor=self.requestor,
#					 channel_name=self.listen_channel,
#					 peers=self.peers,
#					 block_number=str(self.listen_block),
#					 decode=True
#					 ))
#			 if self.listen_block != 0 and response['header']['number'] == 0:
#				 return False, events
#			 status, events = get_events(response)			
#			 self.listen_block += 1
#		 except Exception as e:
#			 print(str(e))
#		 finally:
#			 return status, events


# def simple_handle_function(event_info):
#	 print(event_info)

# channel1_listener = ChannelListener(cli, 'channel1', ['peer0.org2.example.com'], org2_admin)
# channel1_listener.add_listen_handler(simple_handle_function, ".*")
# for _ in range(10):
#	 channel1_listener._do_listen()
# print(channel1_listener.listen_block)