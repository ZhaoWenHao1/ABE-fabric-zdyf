from hfc.fabric import Client
import asyncio
import os
import json
from collections import namedtuple
import json
import pprint
import queue
import re
from hfc.fabric.transaction.tx_proposal_request import create_tx_prop_req, \
	TXProposalRequest
from hfc.fabric.transaction.tx_context import create_tx_context
import time

def get_newest_block_number(channel, requestor, orderer):
	"""
	not name(str) , istance(object) please
	"""
	async def func(stream):
		m = []	   
		async for x in stream:
			m.append(x)
		return m[0]

	tx_context = create_tx_context(requestor,
								   requestor.cryptoSuite,
								   TXProposalRequest())
	response = channel.get_block_between(tx_context, orderer, None, None)
	loop = asyncio.get_event_loop()
	return loop.run_until_complete(func(response)).block.header.number


def get_events(proposal_response):
	m = []
	status = True
	try:
		for x in proposal_response['data']['data']:
			try:
				m.append(x['payload']['data']['actions'][0]['payload']['action']['proposal_response_payload']['extension']['events'])
			except Exception as e:
				# print("current don't have events")
				pass
			finally:
				pass
	except Exception as e:
		pass
	if len(m):
		return True, m
	else:
		return False, []

class EventHandler:
	def __init__(self, handle_function, event_pattern,handle_times = None,):
		self.handle_function = handle_function
		self.event_pattern = event_pattern
		self.result = []
		if handle_times != None:
			self.handle_times = handle_times
		else:
			# means handler won't stop
			self.handle_times = -1
		
	# return whether we handle something...
	def handle(self, event_info):
		# print(event_info['event_name'])
		if self.handle_times != 0 and re.match(self.event_pattern, event_info['event_name']):
			# pattern match the event,
			if self.handle_times > 0:
				self.handle_times -= 1
			result = self.handle_function(event_info)
			if result != None:
				self.result.append(result)
			return True
		return False


	


class ChannelListener:
	queue_max_size = 100

	def __init__(self, cli, channel, peers, requestor,start_block=None):
		self.cli = cli
		self.listen_channel = channel
		self.peers = peers
		self.requestor = requestor
		self.loop = asyncio.get_event_loop()
		# self.queue = queue.Queue(max)
		if start_block == None:
			self.listen_block = 0
		else:
			self.listen_block = start_block
		self.call_back_handlers = []

	def add_listen_handler(self, function, event_pattern, handle_times=None):
		self.call_back_handlers.append(EventHandler(function, event_pattern, handle_times))


	# return whether in this listen period, we handle some event?
	def _do_listen(self,):
		# not finished...
		# print("listener _do_listen")
		if self.is_listen_complete():
			#			 
			return False
		status, events = self._get_event()
		is_handle = False
		if not status:
			return False
		for event in events:
			if event['event_name'] == "":
				continue
			for handler in self.call_back_handlers:
				is_handle = is_handle or handler.handle(event)
		return is_handle
						
	def _get_event(self):
		events = []
		status = False
		# print("get_event")
		try:
			response = self.loop.run_until_complete(self.cli.query_block(
					requestor=self.requestor,
					channel_name=self.listen_channel,
					peers=self.peers,
					block_number=str(self.listen_block),
					decode=True
					))
			# print(response)
			if self.listen_block != 0 and response['header']['number'] == 0:
				return False, events
			# print("try_get_event")
			# print(f"now listen at {self.listen_channel} at {self.listen_block} block")
			status, events = get_events(response)			
			self.listen_block += 1
			# print("listen block +1")
		except Exception as e:
			# print(str(e))
			pass
		finally:
			return status, events

	def is_listen_complete(self):
		for handler in self.call_back_handlers:
			if handler.handle_times != 0:
				return False
		return True

	def listen_until_complete(self, sleep_time = None):
		if sleep_time == None:
			sleep_time = 0.2
		while not self.is_listen_complete():
			is_handle = self._do_listen()
			if sleep_time == 0:
				continue
			if is_handle:
				time.sleep(0.05)
			else:
				time.sleep(sleep_time)	

	def get_listen_block(self):
		return self.listen_block

