import grpc
import record_pb2 as record_struct
import record_pb2_grpc as record_service
from hfc.fabric import Client 
import asyncio
import json
from concurrent import futures
from multiprocessing import Queue, Manager
import time
class RecordService(record_service.callServicer):
	centre_channel = "centre"
	centre_cc = "audit"
	centre_cc_fcn = ""
	centre_peers = ['peer0.org1.example.com']
	

	def __init__(self, cli, requestor, peers):
		self.cli = cli
		self.requestor = requestor
		self.peers = peers
		self.cli.new_channel('centre')
		self.loop = asyncio.get_event_loop()
		self.lock = multiprocessing.Manager().Lock()
	
	

	def do_record(self, request_header, tx_info):
		# we can just call the invoke_chaincode, 
		# or we can just log it, and later call invoke chaincode...
		print('we are doing record')
		print(f'request_header: {request_header}, tx_info:{tx_info}')
		time.sleep(0.5)
		return
		# self.loop.run_until_complete(self.cli.invoke_chaindoe(
		#	 requestor=self.requestor,
		#	 channel_name=self.centre_channel,
		#	 peers=self.peers,
		#	 cc_name=centre_cc,			
		# ))

	def make_response(self, ):
		return record.struct.response_info(
			error_code='',
			content=''
		)
		
	def record_call(self, request, context):
		response = self.do_record(request, context)
		return self.make_response()
if __name__ == '__main__':
	# cli = Client(net_profile='centre_network/network.json')
	servicer = RecordService()
	server = grpc.server(futures.ThreadPoolExecutor(max_workers=1))
	record_service.add_callServicer_to_server(servicer, server)
	server.add_insecure_port('[::]:10061')
	server.start()
	print("start....")
	server.wait_for_termination()
	