import time
import grpc
import structs_pb2
import record_pb2 as record_struct
import record_pb2_grpc as record_service
import json
import multiprocessing as mp
import random
import os 
server_address = "127.0.0.1:10064"
def sub_process():
    with open("pool.out","a") as f:
        try:
            channel = grpc.insecure_channel(target=server_address)            
            stub = record_service.callStub(channel)
            for i in range(1):
                request_header = random.randint(1, 1e8)
                tx_info = structs_pb2.tx_info(hash_data='',src_chain='',
                user='',dst_chain='',data_id=str(request_header),type_tx='',this_tx_id='',last_tx_id='')        
                response =  stub.record_call(record_struct.request_info(
                    request_header=request_header,info=tx_info))
                print(response)
                f.write(f"pid {os.getpid()}, response {response}")
        except Exception as e:
            f.write(f"pid {os.getpid()}, exception {str(e)}")
        finally:
            f.close()
        # print(response)

if __name__ == '__main__':    
    pool = mp.Pool(200)
    # start = time.time()    
    # channel = grpc.insecure_channel(target=server_address)
    # sub_process(channel)
    # end = time.time()
    # print(f'one call cost {end- start}s')
    with open("pool.out","w") as f:
        f.close()
    
    # start = time.time()    
    
    # for i in range(1):
    #     sub_process()
    # end = time.time()

    # print(f"16 calls in seq cost {end - start}s")



    start = time.time()    
    for i in range(200): 
        
        pool.apply_async(sub_process)
    pool.close()
    pool.join()
    end = time.time()
    print(f'16 calls in pool cost {end - start}s')