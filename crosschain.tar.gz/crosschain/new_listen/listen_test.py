from hfc.fabric import Client
import asyncio
import os
import json
from collections import namedtuple
from utils.user import Management
import json
import pprint
import queue
import re
import timeit

def get_events(proposal_response):
	m = []
	status = True
	try:
		for x in proposal_response['data']['data']:
			try:
				m.append(x['payload']['data']['actions'][0]['payload']['action']['proposal_response_payload']['extension']['events'])
			except Exception as e:
				# print("current don't have events")
				pass
			finally:
				pass
	except Exception as e:
		pass
	if len(m):
		return True, m
	else:
		return False, []




class EventHandler:
	def __init__(self, handle_function, event_pattern,handle_times = None,):
		self.handle_function = handle_function
		self.event_pattern = event_pattern
		if handle_times != None:
			self.handle_times = handle_times
		else:
			# means handler won't stop
			self.handle_times = -1
		
	def handle(self, event_info):
		if self.handle_times != 0 and re.match(self.event_pattern, event_info['event_name']):
			# pattern match the event,
			if self.handle_times > 0:
				self.handle_times -= 1
			self.handle_function(event_info)

class ChannelListener:

	def __init__(self, cli, channel, peers, requestor,start_block=None):
		self.cli = cli
		self.listen_channel = channel
		self.peers = peers
		self.requestor = requestor
		self.loop = asyncio.get_event_loop()
		if start_block == None:
			self.listen_block = 0
		else:
			self.listen_block = start_block
		self.call_back_handlers = []

	def add_listen_handler(self, function, event_pattern, handle_times=None):
		self.call_back_handlers.append(EventHandler(function, event_pattern, handle_times))


	def _do_listen(self,):
		self.call_back_handlers = list(filter(lambda handler: handler.handle_times != 0, 
											  self.call_back_handlers))
		if not len(self.call_back_handlers):
			return False

		status, events = self._get_event()

		if not status:
			return False

		for event in events:
			for handler in self.call_back_handlers:
				handler.handle(event)
		return True
						
	def _get_event(self):
		events = []
		status = False
		try:

			response = self.loop.run_until_complete(self.cli.query_block(
					requestor=self.requestor,
					channel_name=self.listen_channel,
					peers=self.peers,
					block_number=str(self.listen_block),
					decode=True
					))

			if self.listen_block != 0 and response['header']['number'] == 0:
				return False, events
			status, events = get_events(response)			
			self.listen_block += 1
		except Exception as e:
			print(str(e))
		finally:
			return status, events


def simple_handle_function(event_info):
	print(event_info)
	pass



if __name__ == "__main__":		
	cli = Client(net_profile="testnetwork/network.json")
	org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
	cli.new_channel('channel2')
	cli.new_channel('channel1')
	cli.new_channel('centre')
	ca_manage=Management()
	org2_user=ca_manage.create_user(user_name='user_ca',org_name='org2.example.com',msp="Org2MSP")

	channel1_listener = ChannelListener(cli, 'channel1', ['peer0.org2.example.com'], org2_admin)
	channel1_listener.add_listen_handler(simple_handle_function, ".*")
#中间写代码块
	start=timeit.default_timer()

	for _ in range(4):
		channel1_listener._do_listen()
	end=timeit.default_timer()
	# print('Running time: %s Seconds'%(end-start))

	# print(channel1_listener.listen_block)