import listener
import time
import asyncio
import json
from hfc.fabric import Client
import argparse
import sys
tx_cc = 'record'
centre_cc = 'audit'

src_audit_event_pattern = "srcAuditEvent"
dst_audit_event_pattern = "dstAuditEvent"
centre_audit_event_pattern = "Judge"
cetnre_confirm_event_pattern = "centreConfirm"


centre_audit_fcn = "CrossChannelJudgement"
dst_audit_fcn = "dstAuditRecord"
centre_confirm_fcn = "Confirm"
src_confirm_fcn = "Confirm"
centre_query_fcn = "GetJudge"
class ProxyNode:
	"""
	2 Listener: tx_channel, centre_channel

	4 event_handler, 
	src_audit,
	centre_audit,
	dst_audit,
	centre_confirm,
	"""
	class src_audit_event_handler():
		"""
			get srcAuditEvent+self.tx_channel
		"""
		def __init__(self, **kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()

		def _json2judge_args(self,tx_info):
			return [tx_info['hash_data'],tx_info['src_chain'], tx_info['user'], tx_info['dst_chain'],
			tx_info['data_id'], tx_info['type_tx'], tx_info['this_tx_id'] ]

		def __call__(self,event_info):
			payload = json.loads(event_info['payload'])
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.centre_channel,
					peers=self.peers,
					cc_name=centre_cc,
					fcn=centre_audit_fcn,
					args=self._json2judge_args(payload),
					wait_for_event=False,
				)
			)

	class dst_audit_event_handler():
		"""
			get dstAuditEvent 
		"""
		def __init__(self, **kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		def _json2confirm_args(self, message):
			return [message['tx_id'], str(message['result']), 
					message['err_kinds'], message['src_chain']]

		def __call__(self,event_info):
			payload = json.loads(event_info['payload'])
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.centre_channel,
					peers=self.peers,
					cc_name=centre_cc,
					fcn=centre_confirm_fcn,
					args=self._json2confirm_args(payload),
					wait_for_event=False
				)
			)
			
	class centre_confirm_event_handler():
		"""
			pattern Confirm+tx_channel
			get Confirm+srcChannel
		"""
		def __init__(self,**kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		def _json2confirm_args(self, info):
			return [info['result'], info['err_kinds'], info['tx_id']]	
			
		def __call__(self,event_info):
			print(f"{self.tx_channel}:{self.peers}, receive confirm from centre chain,")			
			payload = json.loads(event_info['payload'])
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.tx_channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=src_confirm_fcn,
					args=self._json2confirm_args(payload),
					wait_for_event=False
				)
			)

	class centre_audit_event_handler():
		"""
		handle Judge+tx_channel event...
		"""
		def __init__(self,**kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()
		
		def _json2dst_audit_args(self, tx_info):
			return [tx_info['upchain']['hash_data'], tx_info['upchain']['src_chain'], tx_info['upchain']['user'],
			tx_info['upchain']['dst_chain'], tx_info['upchain']['data_id'], tx_info['upchain']['type_op'],
			tx_info['upchain']['tx_id']]

		def __call__(self,event_info):			
			payload = json.loads(event_info['payload'])
			tx_id = payload['tx_id']
			response = self.loop.run_until_complete(
				self.cli.chaincode_query(
					requestor=self.requestor,
					peers=self.peers,
					channel_name = self.centre_channel,
					cc_name = centre_cc,
					fcn=centre_query_fcn,
					args=[tx_id]
				)
			)
			payload = json.loads(response)
			self.loop.run_until_complete(
				self.cli.chaincode_invoke(
					requestor=self.requestor,
					channel_name=self.tx_channel,
					peers=self.peers,
					cc_name=tx_cc,
					fcn=dst_audit_fcn,
					args=self._json2dst_audit_args(payload),
					wait_for_event=False
				)
			)


	def __init__(self,**kwargs):
		"""
		tx_channel   name
		centre_channel name

		"""
		self.tx_channel = kwargs['tx_channel']
		self.centre_channel = kwargs['centre_channel']
		self.cli = kwargs['cli']
		self.peers = kwargs['peers']
		self.requestor = kwargs['requestor']
		self.tx_channel_listener = listener.ChannelListener(self.cli, self.tx_channel,
															self.peers, self.requestor)
		# self.centre_channel_listener = listener.ChannelListener(self.cli, self.centre_channel,
		#													 self.peers, self.requestor)
		self.tx_channel_listener.add_listen_handler(self.src_audit_event_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel), 
													src_audit_event_pattern)
		# self.tx_channel_listener.add_listen_handler(self.dst_audit_event_handler(
		#													 cli=self.cli, tx_channel=self.tx_channel,
		#													 requestor=self.requestor, peers=self.peers,
		#													 centre_channel=self.centre_channel), 
		#											 dst_audit_event_pattern)
		# self.centre_channel_listener.add_listen_handler(self.centre_audit_event_handler(
		#													 cli=self.cli, tx_channel=self.tx_channel,
		#													 requestor=self.requestor, peers=self.peers,
		#													 centre_channel=self.centre_channel), 
		#												 centre_audit_event_pattern+self.tx_channel)
		# self.centre_channel_listener.add_listen_handler(self.centre_confirm_event_handler(
		#													 cli=self.cli, tx_channel=self.tx_channel,
		#													 requestor=self.requestor, peers=self.peers,
		#													 centre_channel=self.centre_channel), 
		#												 cetnre_confirm_event_pattern+self.tx_channel)

	def _do_listen(self):
		is_handle = self.tx_channel_listener._do_listen()
		print(f"listen {self.tx_channel} at {self.tx_channel_listener.get_listen_block()}")		
		is_handle = is_handle or self.centre_channel_listener._do_listen()
		print(f"listen {self.centre_channel} at {self.centre_channel_listener.get_listen_block()}")		

		return is_handle
	def listen(self):
		while(True):
			
			is_handle = self._do_listen()
			if is_handle:
				time.sleep(0.01)
			else :
				time.sleep(1)


if __name__ == "__main__":
   
	cli = Client(net_profile="testnetwork/network.json")
	centre_channel = 'centre'
	tx_channel = 'channel1'
	peers = 'peer0.org2.example.com'
	org_name = args.org
	user_name = args.user
	requestor = cli.get_user(org_name='org2', name='Admin')
	proxy_node = ProxyNode(
		tx_channel='channel1',
		centre_channel='centre',
		cli=cli,
		peers=[peers],
		requestor=requestor,
	)
	cli.new_channel(centre_channel)
	cli.new_channel(tx_channel)
	proxy_node.listen()