import asyncio
from hfc.fabric import Client
import os
import json
import sys
import time
import multiprocessing
import random
loop = asyncio.get_event_loop()

# cli = Client(net_profile="testnetwork/network.json")

# cli.new_channel('channel1')
# cli.new_channel('centre')
# cli.new_channel('channel2')

dst_sync_fcn = "dstSyncRecord"
src_sync_fcn = "srcSyncRecord"


def chaincode_invoke(cli, requestor, **kwargs):
		"""
				channel:
				invoke_peers,
				fcn
				args,
				cc_name
		"""
		loop = asyncio.get_event_loop()
		response = loop.run_until_complete(
				cli.chaincode_invoke(
						requestor=requestor,
						channel_name=kwargs['channel'],
						peers=kwargs['invoke_peers'],
						fcn=kwargs['fcn'],
						args=kwargs['args'],
						cc_name=kwargs['cc_name'],
						wait_for_event=True
				)
		)
		return response

def test_invoke_chaincode(start, number):
	# print('here')
	print(f"{start},{start+number}")
	# for x in range(start, start+number):
	#	 print(x)
	cli = Client(net_profile="testnetwork/network.json")
	
	org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')

	cli.new_channel('channel2')
	loop = asyncio.get_event_loop()

	with open(f"process{int(start/number)}.output", "w") as file:
		for x in range(start, start+number):
			random_num = random.random()
			file_name = f"{start}+{random_num}"
			m = loop.run_until_complete(cli.chaincode_invoke(
					requestor=org4_admin,
					channel_name='channel2',
					peers=['peer0.org4.example.com'],
					fcn ='chainAuditRecord',
					args=['hashdata', 'channel2', 'Admin@org4.example.com', f'data{x}and{random_num}_copy','add'],
					cc_name='record',
					transient_map=None, # optional, for private data
					wait_for_event=False,
			))
			# print(f"{start}:",m)			
			# file.write(m)
			# print(m)
		# file.close()
	return number
def run_task(name):
	print('Task {0} pid {1} is running, parent id is {2}'.format(name, os.getpid(), os.getppid()))
	# time.sleep(1)
	print('Task {0} end.'.format(name))

def my_test(name):
	print('hello')
	asdf 
def measure_write_cost1(start, number, org, user_name, lock):
	lock.acquire()
	cli = Client(net_profile="testnetwork/network.json")
	lock.release()
	cli.new_channel('channel1')
	cli.new_channel('centre')
	cli.new_channel('channel2')
	# print(start)	
	user = cli.get_user(org_name=org, name=user_name)
	# print(user)
	loop = asyncio.get_event_loop()
	random_num = random.random()
	m = []
	for x in range(int(start), int(start) + int(number)):
		# print(f'[{start},{number})')
		# print('12344')				
		# print("file is ",file_name)	
		m.append(cli.chaincode_invoke(
			requestor=user,
			channel_name='channel1',
			peers=['peer0.org2.example.com'],
			fcn ='chainSyncRecord',
			args=['hashdata'+str(x), 'channel1', f"{user_name}@{org}", f'data1','write',str(x)],
			cc_name='record',
			transient_map=None, # optional, for private data
			wait_for_event=True,
		))
	task = loop.create_task(asyncio.wait(m))
	loop.run_until_complete(task)
	for x in task.result()[0]:
		print(x.result())
	return number

def measure_write_cost2(start, number, org, user_name, lock):
	lock.acquire()
	cli = Client(net_profile="testnetwork/network.json")
	lock.release()
	cli.new_channel('channel1')
	cli.new_channel('centre')
	cli.new_channel('channel2')
	# print(start)	
	user = cli.get_user(org_name=org, name=user_name)
	# print(user)
	loop = asyncio.get_event_loop()
	x = random.randint(10,100)
	response = loop.run_until_complete(cli.chaincode_invoke(
			requestor=user,
			channel_name='channel1',
			peers=['peer0.org3.example.com'],
			fcn ='chainSyncRecord',
			args=['hashdata', 'channel1', f"{user_name}@{org}", f'data1','write',str(x)],
			cc_name='record',
			transient_map=None, # optional, for private data
			wait_for_event=False,
    ))
	print(response)


print("start time")
start = time.time()
one_handle = 10
pool = multiprocessing.Pool(processes=1)
tmp_start = time.time()
lock = multiprocessing.Manager().Lock()
# for x in range(int(m)):
#	 random_num = random.random()
#	 response = loop.run_until_complete(cli.chaincode_invoke(
#		 requestor=org4_admin,
#		 channel_name='channel2',
#		 peers=['peer0.org4.example.com'],
#		 fcn ='chainAuditRecord',
#		 args=['hashdata', 'channel2', f"Admin@org4.example.com", f'data{x}and{random_num}_copy','add'],
#		 cc_name='record',
#		 transient_map=None, # optional, for private data
#		 wait_for_event=False,
#	 ))
measure_write_cost1(0*one_handle, one_handle,'org3.example.com','User1', lock)
# pool.close()
# pool.join()
random_number = random.random()
# response = loop.run_until_complete(cli.chaincode_invoke(
#			 requestor=org4_admin,
#			 channel_name='channel2',
#			 peers=['peer0.org4.example.com'],
#			 fcn ='chainAuditRecord',
#			 args=['hashdata', 'channel2', 'Admin@org4.example.com', f'databb{random_number}_copy','add'],
#			 cc_name='record',
#			 transient_map=None, # optional, for private data
#			 wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
# ))
# print(response)
end = time.time()
print(f'10 request upchain cost {end-start}s')