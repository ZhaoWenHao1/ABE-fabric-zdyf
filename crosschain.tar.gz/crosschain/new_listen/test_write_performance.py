import asyncio
from hfc.fabric import Client
import os
import json
# from new_type_cross import listener, user_confirm_handler
import sys
import time
import multiprocessing
import random
loop = asyncio.get_event_loop()

# cli = Client(net_profile="testnetwork/network.json")

# cli.new_channel('channel1')
# cli.new_channel('centre')
# cli.new_channel('channel2')

dst_sync_fcn = "dstSyncRecord"
src_sync_fcn = "srcSyncRecord"





def run_task(name):
	print('Task {0} pid {1} is running, parent id is {2}'.format(name, os.getpid(), os.getppid()))
	# time.sleep(1)
	print('Task {0} end.'.format(name))
def measure_tx1_write_cost(start, number, org, user_name, lock):
	lock.acquire()
	cli = Client(net_profile='tx1_network/network.json')
	lock.release()
	user = cli.get_user(org_name=org, name=user_name)
	cli.new_channel('channel1')
	# print(user)
	loop = asyncio.get_event_loop()
	random_num = random.random()
	m = []
	for x in range(int(start), int(start) + int(number)):
		# print(f'[{start},{number})')
		# print('12344')				
		random_num = random_num
		file_name = f"{start}+{random_num}"	
		# print("file is ",file_name)	
		m.append(cli.chaincode_invoke(
			requestor=user,
			channel_name='channel1',
			peers=['peer0.org2.example.com'],
			fcn ='chainAuditRecord',
			args=['hashdata', 'channel1', f"{user_name}@{org}", f'data{x}and{random_num}_copy','add'],
			cc_name='record',
			transient_map=None, # optional, for private data
			wait_for_event=False,
		))
	
	task = loop.create_task(asyncio.wait(m))
	loop.run_until_complete(task)

	# with open("write.out","a") as f:
	# 	for x in task.result()[0]:
	# 		f.write(x.result())
	# 		f.write('\n')

	# for x in task.result()[0]:
	# 	print(x.result())
	response = loop.run_until_complete(cli.chaincode_invoke(
			requestor=user,
			channel_name='channel1',
			peers=['peer0.org2.example.com'],
			fcn ='chainAuditRecord',
			args=['hashdata', 'channel1', f"{user_name}@{org}", f'data{int(start+1+random_num)}and.{random_num}','add'],
			cc_name='record',
			transient_map=None, # optional, for private data
			wait_for_event=True,
		))

	print(response)
	return number

def measure_tx2_write_cost(start, number, org, user_name, lock):
	lock.acquire()
	cli = Client(net_profile='tx2_network/network.json')
	lock.release()
	user = cli.get_user(org_name=org, name=user_name)
	# print(user)
	cli.new_channel('channel2')
	loop = asyncio.get_event_loop()
	random_num = random.random()
	m = []
	for x in range(int(start), int(start) + int(number)):
		# print(f'[{start},{number})')
		# print('12344')				
		random_num = random_num
		file_name = f"{start}+{random_num}"	
		# print("file is ",file_name)	
		m.append(cli.chaincode_invoke(
			requestor=user,
			channel_name='channel2',
			peers=['peer0.org3.example.com'],
			fcn ='chainAuditRecord',
			args=['hashdata', 'channel2', f"{user_name}@{org}", f'data{x}and{random_num}_copy','add'],
			cc_name='record',
			transient_map=None, # optional, for private data
			wait_for_event=False,
		))
	task = loop.create_task(asyncio.wait(m))
	loop.run_until_complete(task)
	# for x in task.result()[0]:
	# 	print(x.result())
	# with open("write.out","a") as f:
	# 	for x in task.result()[0]:
	# 		f.write(x.result())
	# 		f.write('\n')
	response = loop.run_until_complete(cli.chaincode_invoke(
			requestor=user,
			channel_name='channel2',
			peers=['peer0.org3.example.com'],
			fcn ='chainAuditRecord',
			args=['hashdata', 'channel2', f"{user_name}@{org}", f'data{int(start+1+random_num)}and.{random_num}','add'],
			cc_name='record',
			transient_map=None, # optional, for private data
			wait_for_event=True,
		))
	print(response)
	return number

f = open("write.out","w")
f.close()


print("start time")
start = time.time()
process_number = 4
m = 2000
all_handle = int(m)
one_handle = int(all_handle/ process_number)
pool = multiprocessing.Pool(processes=process_number)
tmp_start = time.time()
lock = multiprocessing.Manager().Lock()
# for x in range(int(m)):
#	 random_num = random.random()
#	 response = loop.run_until_complete(cli.chaincode_invoke(
#		 requestor=org4_admin,
#		 channel_name='channel2',
#		 peers=['peer0.org4.example.com'],
#		 fcn ='chainAuditRecord',
#		 args=['hashdata', 'channel2', f"Admin@org4.example.com", f'data{x}and{random_num}_copy','add'],
#		 cc_name='record',
#		 transient_map=None, # optional, for private data
#		 wait_for_event=False,
#	 ))
# measure_tx2_write_cost(0*one_handle, one_handle,'org3.example.com','User1', lock)
# pool.apply_async(measure_tx1_write_cost, (0*one_handle, one_handle,'org2.example.com','User1', lock))	
# pool.apply_async(measure_tx1_write_cost, (1*one_handle, one_handle,'org2.example.com','Admin', lock))
# pool.apply_async(measure_tx1_write_cost, (2*one_handle, one_handle,'org2.example.com','User1', lock))	
# pool.apply_async(measure_tx1_write_cost, (3*one_handle, one_handle,'org2.example.com','Admin', lock))
# pool.apply_async(measure_tx2_write_cost, (0*one_handle, one_handle,'org3.example.com','User1', lock))	
# pool.apply_async(measure_tx2_write_cost, (1*one_handle, one_handle,'org3.example.com','Admin', lock))
# pool.apply_async(measure_tx2_write_cost, (2*one_handle, one_handle,'org3.example.com','User1', lock))	
# pool.apply_async(measure_tx2_write_cost, (3*one_handle, one_handle,'org3.example.com','Admin', lock))
m = []

m.append(multiprocessing.Process(target=measure_tx1_write_cost, args=(0 * one_handle, one_handle,'org2.example.com','User1', lock))) 
# m.append(multiprocessing.Process(target=measure_tx1_write_cost, args=(1 * one_handle, one_handle,'org2.example.com','Admin', lock))) 
m.append(multiprocessing.Process(target=measure_tx2_write_cost, args=(0 * one_handle, one_handle,'org3.example.com','User1', lock))) 
# m.append(multiprocessing.Process(target=measure_tx2_write_cost, args=(1 * one_handle, one_handle,'org3.example.com','Admin', lock))) 
for task in m:
	task.start()
for task in m:
	task.join()
# pool.close()
# pool.join()
random_number = random.random()
# response = loop.run_until_complete(cli.chaincode_invoke(
#			 requestor=org4_admin,
#			 channel_name='channel2',
#			 peers=['peer0.org4.example.com'],
#			 fcn ='chainAuditRecord',
#			 args=['hashdata', 'channel2', 'Admin@org4.example.com', f'databb{random_number}_copy','add'],
#			 cc_name='record',
#			 transient_map=None, # optional, for private data
#			 wait_for_event=True, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
# ))
# print(response)
end = time.time()
print(f'{all_handle} request upchain cost {end-start}s')