import asyncio




class src_confirm_user_event_handler():
	"""
		handle srcEventHandler
	"""
	   
	def __call__(self,event_info):
		return event_info


class numb_user_event_handler():
	"""
		Do nothing
	"""
	def __call__(self,event_info):
		pass