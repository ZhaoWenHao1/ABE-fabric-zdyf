from kv import KV
from hfc.fabric import Client
import asyncio


def invoke_chaincode(cli, **kwargs):
	loop = asyncio.get_event_loop()

	response = loop.run_until_complete(cli.chaincode_invoke(
		requestor=kwargs['requestor'],
		channel_name=kwargs['channel'],
		peers=kwargs['peers'],
		args=kwargs['args'],
		cc_name=kwargs['cc_name'],
		fcn=kwargs['fcn'],
		wait_for_event=kwargs['wait_for_event']
	))
	return response


class DB(object):
	"""
	docstring
	"""
	def __init__(self, uri='db/kv.db'):
		self.db = KV(db_uri=uri)
	
	def set_data(self, key, value, **kwargs):
		response = kwargs['cli'].invoke_chaincode(**kwargs)
		if response :
			self.db[key] = value
			return True
		else:
			return False
	
	def get_data(self, key, **kwargs):
		response = kwargs['cli'].invoke_chaincode(**kwargs)
		if response:
			return self.db[key]
		else:
			return None

	def del_data(self,key, **kwargs):
		response = kwargs['cli'].invoke_chaincode(**kwargs)
		if response:
			del self.db[key]
			return True
		else:
			return None