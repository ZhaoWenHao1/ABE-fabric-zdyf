import listener
import time
import asyncio
import json
from hfc.fabric import Client
import argparse
import sys
import time
import grpc
import record_pb2 as record_struct
import record_pb2_grpc as record_service
import structs_pb2 as structs





tx_cc = 'record'
centre_cc = 'audit'

src_audit_event_pattern = "srcAuditEvent|dstAuditEvent"
dst_audit_event_pattern = "dstAuditEvent"
centre_audit_event_pattern = "Judge"
cetnre_confirm_event_pattern = "Confirm"
src_trace_forward_pattern = "CrossTrace"
centre_trace_forward_pattern = "SrctoDes" # TODO : remind append tx_channel
centre_trace_forward_complete_pattern = "DesToSrc" #TODO: append tx_channel

centre_audit_fcn = "CrossChannelJudgement"
dst_audit_fcn = "dstAuditRecord"
centre_confirm_fcn = "Confirm"
src_confirm_fcn = "Confirm"
centre_query_fcn = "GetJudge"
centre_trace_forward_fcn = "SrcToDes"
centre_trace_forward_complete_fcn = "DesToSrc"
src_trace_forward_fcn = "crossTraceForward"
src_trace_forward_complete_fcn = "TFComplete"
inner_trace_forward_fcn = "traceForward"
address = "serv_ip:serv_port"
class ProxyNode:
	"""
	2 Listener: tx_channel, centre_channel

	4 event_handler, 
	src_audit,
	centre_audit,
	dst_audit,
	centre_confirm,
	"""
	class src_audit_event_handler():
		"""
			get srcAuditEvent+self.tx_channel
		"""
		def __init__(self, **kwargs):
			self.tx_channel = kwargs['tx_channel']
			self.centre_channel = kwargs['centre_channel']
			self.cli = kwargs['cli']
			self.peers = kwargs['peers']
			self.requestor = kwargs['requestor']
			self.loop = asyncio.get_event_loop()

		def _json2judge_args(self,tx_info):
			return [tx_info['hash_data'],tx_info['src_chain'], tx_info['user'], tx_info['dst_chain'],
			tx_info['data_id'], tx_info['type_tx'], tx_info['this_tx_id'] ]

		def __call__(self,event_info):
			grpc_channel = grpc.insecure_channel(target='')
			print(f"event_info: {event_info}")
			stub = record_service.callStub(channel=grpc_channel)
			# resposne = stub.record_call(record_struct.request_info(
			# 	request_header=0,info=structs.tx_info(
			# 		hash_data=hash_data,
			# 		src_chain=src_chain,
			# 		user=user,
			# 		dst_chain=dst_chain,
			# 		data_id=data_id,
			# 		type_tx=type_tx,
			# 		last_tx_id=last_tx_id,
			# 		this_tx_id=this_txid)))

	def __init__(self,**kwargs):
		"""
		tx_channel   name
		centre_channel name

		"""
		t_start = time.time()
		self.tx_channel = kwargs['tx_channel']
		self.centre_channel = kwargs['centre_channel']
		self.cli = kwargs['cli']
		self.peers = kwargs['peers']
		self.requestor = kwargs['requestor']
		self.tx_channel_listener = listener.ChannelListener(self.cli, self.tx_channel,
															self.peers, self.requestor)
		self.tx_channel_listener.add_listen_handler(self.src_audit_event_handler(
															cli=self.cli, tx_channel=self.tx_channel,
															requestor=self.requestor, peers=self.peers,
															centre_channel=self.centre_channel), 
													src_audit_event_pattern)
		t_end = time.time()
		print(f'init cost {t_end - t_start}s')



	def _do_listen(self):
		t_start = time.time()
		is_handle = self.tx_channel_listener._do_listen()
		t_end = time.time()
		print(f"do_listen cost {t_end - t_start}s")
		return is_handle
	def listen(self):
		while(True):			
			is_handle = self._do_listen()
			if is_handle:
				time.sleep(0.01)
			else :
				time.sleep(0.1)


if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument('--user', type=str, help="user_name eg. Admin")
	parser.add_argument('--org', type=str, help="org_name eg. org2.example.com")
	parser.add_argument('--channel', type=str, help="channel eg. channel1")
	parser.add_argument('--peers', type=str, help="peers eg. peer0.org3.example.com")
	args = parser.parse_args(sys.argv[1:])	
	cli = Client(net_profile="testnetwork/network.json")
	centre_channel = 'centre'
	tx_channel = args.channel
	peers = args.peers
	org_name = args.org
	user_name = args.user
	requestor = cli.get_user(org_name=org_name, name=user_name)
	proxy_node = ProxyNode(
		tx_channel=tx_channel,
		centre_channel=centre_channel,
		cli=cli,
		peers=[peers],
		requestor=requestor,
	)
	cli.new_channel(centre_channel)
	cli.new_channel(tx_channel)
	proxy_node.listen()