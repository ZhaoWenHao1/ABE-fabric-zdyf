python new_type_cross/proxy_node.py --user Admin --org org2.example.com --channel channel1 --peers peer0.org2.example.com
