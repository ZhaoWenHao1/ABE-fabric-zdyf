from hfc.fabric import Client
import asyncio
import os
import json
from collections import namedtuple
# from utils.user import Management
import json
import pprint
import queue
import re
import sys
import threading
import multiprocessing as mp
import pprint
cli = Client(net_profile="testnetwork/network.json")
# org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
# org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
# org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
cli.new_channel('channel2')
cli.new_channel('channel1')
cli.new_channel('centre')

loop = asyncio.get_event_loop()

blocks = []

if __name__ == '__main__':
	m = loop.run_until_complete(cli.query_info(org2_admin, 'channel1', ['peer0.org2.example.com']))
	print(m)
	response = loop.run_until_complete(cli.query_block(
				requestor=org2_admin,
				channel_name='channel1',
				peers=['peer0.org2.example.com'],
				block_number=str(m.height-1),
				decode=True
				))
	print(response)
	response['data']['data']
	pp = pprint.PrettyPrinter(indent=2)
	pp.pprint(response['metadata']['metadata'][2])
	inputx = response['data']['data'][0]['payload']['data']['actions'][0]['payload']['chaincode_proposal_payload']['input']
	# print(inputx.decode('unicode'))
