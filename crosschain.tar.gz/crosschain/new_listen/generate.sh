python3 -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. ./structs.proto
python3 -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. ./record.proto
python3 -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. ./trace.proto