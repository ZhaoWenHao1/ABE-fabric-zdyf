from hfc.fabric import Client
import asyncio
import os


loop = asyncio.get_event_loop()

cli = Client(net_profile="testnetwork/network.json")
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')



def create_channel1():
	response = loop.run_until_complete(cli.channel_create(
			orderer='orderer.example.com',
			channel_name='channel1',
			requestor=org2_admin,
			config_yaml='testnetwork/',
			channel_profile='TwoOrgsChannel1'
			))
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org2_admin,
			   channel_name='channel1',
			   peers=['peer0.org2.example.com',],
			   orderer='orderer.example.com'
			   ))			   
	# response
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org3_admin,
			   channel_name='channel1',
			   peers=['peer0.org3.example.com',],
			   orderer='orderer.example.com'
			   ))			   





def init_channel1():
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/CheckUser',
				cc_name='CheckUser',
				cc_version='v1.0'
				))

	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org3_admin,
				peers=['peer0.org3.example.com',],
				cc_path='github.com/chaincode/CheckUser',
				cc_name='CheckUser',
				cc_version='v1.0'
				))

		
	policy = {
			'identities': [
				{'role': {'name': 'member', 'mspId': 'Org3MSP'}},
				{'role': {'name': 'member', 'mspId': 'Org2MSP'}}
			],
			'policy': {
				'1-of': [
					{'signed-by': 0},
					{'signed-by': 1}
				]
			}
		}

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org2_admin,
					channel_name='channel1',
					peers=['peer0.org2.example.com'],
					cc_name='CheckUser',
					args=['Admin@org2.example.com'],
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))


	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/Policy',
				cc_name='Policy',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org3_admin,
				peers=['peer0.org3.example.com',],
				cc_path='github.com/chaincode/Policy',
				cc_name='Policy',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org2_admin,
					channel_name='channel1',
					peers=['peer0.org2.example.com'],
					cc_name='Policy',
					args=['channel1'],
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))

	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/channel_audit',
				cc_name='channel_audit',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org3_admin,
				peers=['peer0.org3.example.com',],
				cc_path='github.com/chaincode/channel_audit',
				cc_name='channel_audit',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org2_admin,
					channel_name='channel1',
					peers=['peer0.org2.example.com'],
					cc_name='channel_audit',
					args=None,
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))

	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org3_admin,
				peers=['peer0.org3.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org2_admin,
					channel_name='channel1',
					peers=['peer0.org2.example.com'],
					cc_name='record',
					args=None,
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))
	
	print(response)


	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org3_admin,
				peers=['peer0.org3.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org2_admin,
					channel_name='channel1',
					peers=['peer0.org2.example.com'],
					cc_name='record',
					args=None,
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))



def create_channel2():
	response = loop.run_until_complete(cli.channel_create(
			orderer='orderer.example.com',
			channel_name='channel2',
			requestor=org4_admin,
			config_yaml='testnetwork/',
			channel_profile='TwoOrgsChannel2'
			))
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org4_admin,
			   channel_name='channel2',
			   peers=['peer0.org4.example.com',],
			   orderer='orderer.example.com'
			   ))			   
	response
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org5_admin,
			   channel_name='channel2',
			   peers=['peer0.org5.example.com',],
			   orderer='orderer.example.com'
			   ))			   





def init_channel2():
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org4_admin,
				peers=['peer0.org4.example.com',],
				cc_path='github.com/chaincode/CheckUser',
				cc_name='CheckUser',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org5_admin,
				peers=['peer0.org5.example.com',],
				cc_path='github.com/chaincode/CheckUser',
				cc_name='CheckUser',
				cc_version='v1.0'
				))



		
	policy = {
			'identities': [
				{'role': {'name': 'member', 'mspId': 'Org4MSP'}},
				{'role': {'name': 'member', 'mspId': 'Org5MSP'}}
			],
			'policy': {
				'1-of': [
					{'signed-by': 0},
					{'signed-by': 1}
				]
			}
		}

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org4_admin,
					channel_name='channel2',
					peers=['peer0.org4.example.com'],
					cc_name='CheckUser',
					args=['Admin@org4.example.com'],
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))


	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org4_admin,
				peers=['peer0.org4.example.com',],
				cc_path='github.com/chaincode/Policy',
				cc_name='Policy',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org5_admin,
				peers=['peer0.org5.example.com',],
				cc_path='github.com/chaincode/Policy',
				cc_name='Policy',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org5_admin,
					channel_name='channel2',
					peers=['peer0.org5.example.com'],
					cc_name='Policy',
					args=['channel2'],
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))
	print('\n\n\n\n\n\n\n\n policy instatniate')
	print(response)
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org4_admin,
				peers=['peer0.org4.example.com',],
				cc_path='github.com/chaincode/channel_audit',
				cc_name='channel_audit',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org5_admin,
				peers=['peer0.org5.example.com',],
				cc_path='github.com/chaincode/channel_audit',
				cc_name='channel_audit',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org5_admin,
					channel_name='channel2',
					peers=['peer0.org5.example.com'],
					cc_name='channel_audit',
					args=None,
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))

	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org4_admin,
				peers=['peer0.org4.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org5_admin,
				peers=['peer0.org5.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org5_admin,
					channel_name='channel2',
					peers=['peer0.org5.example.com'],
					cc_name='record',
					args=None,
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))

	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org4_admin,
				peers=['peer0.org4.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))
	

		
	responses = loop.run_until_complete(cli.chaincode_install(
				requestor=org5_admin,
				peers=['peer0.org5.example.com',],
				cc_path='github.com/chaincode/record',
				cc_name='record',
				cc_version='v1.0'
				))

	response = loop.run_until_complete(cli.chaincode_instantiate(
					requestor=org5_admin,
					channel_name='channel2',
					peers=['peer0.org5.example.com'],
					cc_name='record',
					args=None,
					cc_version='v1.0',
					cc_endorsement_policy=policy, 
					collections_config=None, # optional, for private data policy
					transient_map=None,
					wait_for_event=True
					))


def create_centre():
	response = loop.run_until_complete(cli.channel_create(
			orderer='orderer.example.com',
			channel_name='centre',
			requestor=org1_admin,
			config_yaml='testnetwork/',
			channel_profile='CentralChannel'
			))
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org1_admin,
			   channel_name='centre',
			   peers=['peer0.org1.example.com',],
			   orderer='orderer.example.com'
			   ))			   
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org2_admin,
			   channel_name='centre',
			   peers=['peer0.org2.example.com',],
			   orderer='orderer.example.com'
			   ))			   
	response = loop.run_until_complete(cli.channel_join(
			   requestor=org4_admin,
			   channel_name='centre',
			   peers=['peer0.org4.example.com',],
			   orderer='orderer.example.com'
			   ))			   



def init_centre():
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org1_admin,
				peers=['peer0.org1.example.com',],
				cc_path='github.com/chaincode/audit',
				cc_name='audit',
				cc_version='v1.0'
				))
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org2_admin,
				peers=['peer0.org2.example.com',],
				cc_path='github.com/chaincode/audit',
				cc_name='audit',
				cc_version='v1.0'
				))
	response = loop.run_until_complete(cli.chaincode_install(
				requestor=org4_admin,
				peers=['peer0.org4.example.com',],
				cc_path='github.com/chaincode/audit',
				cc_name='audit',
				cc_version='v1.0'
				))

	policy = {
		'identities': [
			{'role': {'name': 'member', 'mspId': 'Org1MSP'}},
			{'role': {'name': 'member', 'mspId': 'Org2MSP'}},
			{'role': {'name': 'member', 'mspId': 'Org4MSP'}}
		],
		'policy': {
			'1-of': [
				{'signed-by': 0},
				{'signed-by': 1},
				{'signed-by': 2}
			]
		}
	}
	response = loop.run_until_complete(cli.chaincode_instantiate(
				requestor=org1_admin,
				channel_name='centre',
				peers=['peer0.org1.example.com'],
				cc_name='audit',
				args=None,
				cc_version='v1.0',
				cc_endorsement_policy=policy, 
				collections_config=None, # optional, for private data policy
				transient_map=None,
				wait_for_event=True
				))
	print(response)

create_channel1()
init_channel1()
create_channel2()
init_channel2()
create_centre()
init_centre()

