import asyncio
from hfc.fabric import Client
import os
import json
from new_type_cross import listener, user_confirm_handler
import sys
import time
import multiprocessing
import random
loop = asyncio.get_event_loop()

cli = Client(net_profile="testnetwork/network.json")

# org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
# org3_user = cli.get_user(org_name='org3.example.com', name='User1')
# org3_admin = cli.get_user(org_name='org3.example.com', name='Admin')
# org2_user = cli.get_user(org_name='org2.example.com', name='User1')
# org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
# org5_user = cli.get_user(org_name='org5.example.com', name='User1')
# org5_admin = cli.get_user(org_name='org5.example.com', name='Admin')
# org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')
cli.new_channel('channel1')
cli.new_channel('centre')
cli.new_channel('channel2')

dst_sync_fcn = "dstSyncRecord"
src_sync_fcn = "srcSyncRecord"

def cross_access(cli, requestor, **kwargs):
		'''
		listen_peer
		invoke_peers
		fcn
		args
		cc_name
		src_channel
		'''
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		# print(result)
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "Confirm"+result['this_tx_id'], handle_times=1)
		pattern = "Cofirm"+result['this_tx_id']
		# print(f"listen pattern {pattern}")
		# print(f"listen at {next_block} block")
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])

def trace_forward(cli, requestor, **kwargs):
		"dstchannel, tx_id"
		listen_peer = kwargs['listen_peer']
		invoke_peers = kwargs['invoke_peers']
		fcn = kwargs['fcn']
		args = kwargs['args']
		cc = kwargs['cc_name']
		channel = kwargs['src_channel']
		next_block = listener.get_newest_block_number(cli.get_channel(channel), requestor, cli.get_orderer('orderer.example.com')) +1
		tx_listener = listener.ChannelListener(cli, channel, listen_peer, requestor, next_block)
		response = loop.run_until_complete(cli.chaincode_invoke(
				requestor=requestor,
				channel_name=channel,
				peers=invoke_peers,
				fcn =fcn,
				args=args,
				cc_name=cc,
				transient_map=None, # optional, for private data
				wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
		))
		result = json.loads(response)
		tx_id = result['txid']
		handler = user_confirm_handler.src_confirm_user_event_handler()
		tx_listener.add_listen_handler(handler, "TFComplete"+tx_id, handle_times=1)
		pattern = "TFComplete"+tx_id
		tx_listener.listen_until_complete()
		results = []
		for handler in tx_listener.call_back_handlers:
				if len(handler.result):
						results.extend(handler.result)
		return json.loads(results[0]['payload'])

def chaincode_invoke(cli, requestor, **kwargs):
		"""
				channel:
				invoke_peers,
				fcn
				args,
				cc_name
		"""
		loop = asyncio.get_event_loop()
		response = loop.run_until_complete(
				cli.chaincode_invoke(
						requestor=requestor,
						channel_name=kwargs['channel'],
						peers=kwargs['invoke_peers'],
						fcn=kwargs['fcn'],
						args=kwargs['args'],
						cc_name=kwargs['cc_name'],
						wait_for_event=True
				)
		)
		return response

def test_invoke_chaincode(start, number):
	# print('here')
	print(f"{start},{start+number}")
	# for x in range(start, start+number):
	#	 print(x)
	cli = Client(net_profile="testnetwork/network.json")
	
	org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')

	cli.new_channel('channel2')
	loop = asyncio.get_event_loop()

	with open(f"process{int(start/number)}.output", "w") as file:
		for x in range(start, start+number):
			random_num = random.random()
			file_name = f"{start}+{random_num}"
			m = loop.run_until_complete(cli.chaincode_invoke(
					requestor=org4_admin,
					channel_name='channel2',
					peers=['peer0.org4.example.com'],
					fcn ='chainAuditRecord',
					args=['hashdata', 'channel2', 'Admin@org4.example.com', f'data{x}and{random_num}_copy','add'],
					cc_name='record',
					transient_map=None, # optional, for private data
					wait_for_event=False,
			))
			# print(f"{start}:",m)			
			# file.write(m)
			# print(m)
		# file.close()
	return number
def run_task(name):
	print('Task {0} pid {1} is running, parent id is {2}'.format(name, os.getpid(), os.getppid()))
	# time.sleep(1)
	print('Task {0} end.'.format(name))

def my_test(name):
	print('hello')

def measure_write_cost(start, number, org, user_name):
	try:
		# print(start)	
		user = cli.get_user(org_name=org, name=user_name)
		print(user)
		loop = asyncio.get_event_loop()
		# print()
	except Exception as e:
		print(e)
		return
	with open(f"process{int(start/number)}.log","w") as file:
		# print(file)
		# print(start, number)
		random_num = random.random()
		try:
			
			for x in range(int(start), int(start) + int(number)):
				# print(f'[{start},{number})')
				print('12344')				
				random_num = random_num
				file_name = f"{start}+{random_num}"	
				print("file is ",file_name)	
				response = loop.run_until_complete(cli.chaincode_invoke(
					requestor=user,
					channel_name='channel2',
					peers=['peer0.org4.example.com'],
					fcn ='chainAuditRecord',
					args=['hashdata', 'channel2', f"{user_name}@{org}", f'data{x}and{random_num}_copy','add'],
					cc_name='record',
					transient_map=None, # optional, for private data
					wait_for_event=False,
				))
				print(response)
				file.write(response)
				file.write('\n')			
		except Exception as e:
			print(str(e))
			file.write(str(e))
			file.write('\n')
	return number

org4_admin = cli.get_user(org_name='org4.example.com', name='Admin')

x = cli.chaincode_invoke(
			   requestor=org4_admin,
			   channel_name='channel2',
			   peers=['peer0.org4.example.com'],
			   fcn = 'AddPolicy',
			   args=['channel2','add','role1','Admin@org4.example.com','Admin@org5.example.com','User1@org4.example.com','User1@org5.example.com',],
			   cc_name='Policy',
			   transient_map=None, # optional, for private data
			   wait_for_event=False, # for being sure chaincode invocation has been commited in the ledger, default is on tx event
			   #cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
			   )
print(type(x))

# for x in range(int(m)):
#	 random_num = random.random()
#	 response = loop.run_until_complete(cli.chaincode_invoke(
#		 requestor=org4_admin,
#		 channel_name='channel2',
#		 peers=['peer0.org4.example.com'],
#		 fcn ='chainAuditRecord',
#		 args=['hashdata', 'channel2', f"Admin@org4.example.com", f'data{x}and{random_num}_copy','add'],
#		 cc_name='record',
#		 transient_map=None, # optional, for private data
#		 wait_for_event=False,
#	 ))