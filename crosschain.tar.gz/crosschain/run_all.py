import run_tx1
import run_tx2
import run_centre
import multiprocessing
if __name__ == '__main__':
	run_tx1.init()
	run_tx2.init()
	run_centre.init()
