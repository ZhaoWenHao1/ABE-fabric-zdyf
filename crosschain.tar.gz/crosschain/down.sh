rm ../tmp -rf
docker rm $(docker stop $(docker ps -aq) ) 
docker network prune
docker volume prune
docker rmi $(docker images | grep dev-* | awk '{print $3}')
rm centre_network/crypto-config -rf
rm centre_network/channel-artifacts/* -rf
rm tx1_network/crypto-config -rf
rm tx1_network/channel-artifacts/* -rf
rm tx2_network/crypto-config -rf
rm tx2_network/channel-artifacts/* -rf
rm /tmp/hfc-kvs/* -rf
